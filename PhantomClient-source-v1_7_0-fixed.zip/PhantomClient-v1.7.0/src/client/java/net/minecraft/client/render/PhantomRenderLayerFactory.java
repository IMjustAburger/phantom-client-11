package net.minecraft.client.render;

import com.mojang.blaze3d.pipeline.RenderPipeline;

/**
 * Package-local bridge to RenderLayer's package-private factory, allowing Phantom to define
 * a RenderLayer backed by its registered through-walls render pipeline.
 */
public final class PhantomRenderLayerFactory {
    private PhantomRenderLayerFactory() {}

    public static RenderLayer create(String name, RenderPipeline pipeline) {
        return RenderLayer.of(name, RenderSetup.builder(pipeline).translucent().build());
    }
}
