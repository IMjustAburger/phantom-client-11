package dev.ratman.phantom.world;

import com.mojang.logging.LogUtils;
import dev.ratman.phantom.config.ConfigStore;
import dev.ratman.phantom.util.Notifier;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.registry.Registries;
import net.minecraft.util.WorldSavePath;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;
import org.slf4j.Logger;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;

/**
 * Client-side scanner for observed underground storage and redstone state in already-loaded
 * chunks. It never requests a chunk load. Storage positions and their real outline-shape boxes are
 * cached while chunks are unloaded, persisted per world/dimension, then reconciled against the real
 * block states when those chunks are loaded and scanned again.
 */
public final class SuspiciousChunkFinder {
    private static final Logger LOG = LogUtils.getLogger();
    private static final int MAX_REMEMBERED_STORAGE = 20_000;
    private static final int MAX_SHAPE_BOXES_PER_BLOCK = 16;
    private static final int MAX_PRIORITY_CHUNKS = 8_192;
    private static final int MAX_REDSTONE_SNAPSHOTS = 2_048;

    /** Settings snapshot handed in by the module every tick. */
    public static final class Params {
        public int radius = 3;
        public int depthCutoff = 0;
        public int threshold = 4;
        public boolean scanRedstone = true;
        public boolean requireRedstone = true;
        public boolean notifyChat = true;
        public boolean notifySound = true;
        public int scansPerTick = 2;
        public int minY = -64;
        public boolean hoppers = true;
        public boolean furnaces = true;
        public boolean dispensers = true;
        public boolean copyCoords = false;
    }

    public static final class ShapeBox {
        public static final ShapeBox FULL_BLOCK = new ShapeBox(0, 0, 0, 1, 1, 1);
        public final double minX, minY, minZ, maxX, maxY, maxZ;

        public ShapeBox(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
            this.minX = minX;
            this.minY = minY;
            this.minZ = minZ;
            this.maxX = maxX;
            this.maxY = maxY;
            this.maxZ = maxZ;
        }

        boolean isUsable() {
            return Double.isFinite(minX) && Double.isFinite(minY) && Double.isFinite(minZ)
                    && Double.isFinite(maxX) && Double.isFinite(maxY) && Double.isFinite(maxZ)
                    && minX >= -0.25 && minY >= -0.25 && minZ >= -0.25
                    && maxX <= 1.25 && maxY <= 1.25 && maxZ <= 1.25
                    && maxX > minX && maxY > minY && maxZ > minZ;
        }

        @Override public boolean equals(Object o) {
            if (!(o instanceof ShapeBox)) return false;
            ShapeBox b = (ShapeBox) o;
            return minX == b.minX && minY == b.minY && minZ == b.minZ && maxX == b.maxX && maxY == b.maxY && maxZ == b.maxZ;
        }

        @Override public int hashCode() {
            return java.util.Objects.hash(minX, minY, minZ, maxX, maxY, maxZ);
        }
    }

    private static final class StorageRecord {
        final String blockId;
        final List<ShapeBox> outline;

        StorageRecord(String blockId, List<ShapeBox> outline) {
            this.blockId = blockId;
            this.outline = List.copyOf(outline);
        }

        @Override public boolean equals(Object o) {
            if (!(o instanceof StorageRecord)) return false;
            StorageRecord r = (StorageRecord) o;
            return blockId.equals(r.blockId) && outline.equals(r.outline);
        }

        @Override public int hashCode() { return blockId.hashCode() * 31 + outline.hashCode(); }
    }

    public static final class StorageBlock {
        public final BlockPos position;
        public final String blockId;
        public final List<ShapeBox> outline;

        StorageBlock(BlockPos position, String blockId, List<ShapeBox> outline) {
            this.position = position;
            this.blockId = blockId;
            this.outline = outline;
        }
    }

    private static final class ChunkCoordinate {
        final int x;
        final int z;

        ChunkCoordinate(int x, int z) {
            this.x = x;
            this.z = z;
        }
    }

    private static final LinkedHashMap<Long, StorageRecord> STORAGE = new LinkedHashMap<Long, StorageRecord>();
    private static final Map<Long, Map<Long, String>> REDSTONE_SNAPSHOTS = new LinkedHashMap<Long, Map<Long, String>>();
    private static final Set<Long> REDSTONE_ACTIVE_CHUNKS = new HashSet<Long>();
    private static final Set<Long> NOTIFIED = new HashSet<Long>();
    private static final List<ChunkCoordinate> SCAN_QUEUE = new ArrayList<ChunkCoordinate>();
    private static final LinkedHashSet<Long> PRIORITY_LOADED_CHUNKS = new LinkedHashSet<Long>();
    private static final Map<Long, Integer> CHUNK_COUNTS = new HashMap<Long, Integer>();
    private static final Map<Long, Map<String, Integer>> CHUNK_TYPES = new HashMap<Long, Map<String, Integer>>();
    private static boolean indexDirty = true;

    private static String activeWorldKey = "";
    private static int queueIndex;
    private static int lastPlayerChunkX = Integer.MIN_VALUE;
    private static int lastPlayerChunkZ = Integer.MIN_VALUE;
    private static int lastRadius = -1;
    private static boolean dirty;
    private static long lastSaveAt;

    private SuspiciousChunkFinder() {}

    // ------------------------------------------------------------------ tick
    public static void tick(MinecraftClient client, Params p) {
        if (client.world == null || client.player == null) {
            flushIfDirty();
            return;
        }
        ensureWorld(client);

        int radius = Math.max(1, Math.min(8, p.radius));
        int playerChunkX = client.player.getBlockX() >> 4;
        int playerChunkZ = client.player.getBlockZ() >> 4;
        if (playerChunkX != lastPlayerChunkX || playerChunkZ != lastPlayerChunkZ
                || radius != lastRadius || SCAN_QUEUE.isEmpty() || queueIndex >= SCAN_QUEUE.size()) {
            rebuildQueue(playerChunkX, playerChunkZ, radius);
        }

        int budget = Math.max(1, Math.min(8, p.scansPerTick));
        int scans = 0;
        Iterator<Long> priority = PRIORITY_LOADED_CHUNKS.iterator();
        while (scans < budget && priority.hasNext()) {
            long packed = priority.next();
            priority.remove();
            scanChunk(client, (int) packed, (int) (packed >> 32), p);
            scans++;
        }
        while (scans < budget && queueIndex < SCAN_QUEUE.size()) {
            ChunkCoordinate c = SCAN_QUEUE.get(queueIndex++);
            scanChunk(client, c.x, c.z, p);
            scans++;
        }
        if (dirty && System.currentTimeMillis() - lastSaveAt > 3_000L) save();
    }

    /** Queue a loaded chunk for reconciliation on the next client tick. */
    public static void onChunkLoaded(int chunkX, int chunkZ) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) return;
        ensureWorld(client);
        long key = packChunk(chunkX, chunkZ);
        if (PRIORITY_LOADED_CHUNKS.size() < MAX_PRIORITY_CHUNKS) PRIORITY_LOADED_CHUNKS.add(key);
    }

    private static void ensureWorld(MinecraftClient client) {
        String key = worldKey(client);
        if (key.equals(activeWorldKey)) return;
        if (!activeWorldKey.isEmpty()) save();
        dirty = false;
        lastSaveAt = 0L;
        activeWorldKey = key;
        STORAGE.clear();
        REDSTONE_SNAPSHOTS.clear();
        REDSTONE_ACTIVE_CHUNKS.clear();
        NOTIFIED.clear();
        SCAN_QUEUE.clear();
        PRIORITY_LOADED_CHUNKS.clear();
        queueIndex = 0;
        lastPlayerChunkX = Integer.MIN_VALUE;
        lastPlayerChunkZ = Integer.MIN_VALUE;
        lastRadius = -1;
        indexDirty = true;
        load();
    }

    /** Stable identifier of the current world + dimension (also used by the spawner tracker). */
    public static String worldKey(MinecraftClient client) {
        try {
            if (client.isInSingleplayer() && client.getServer() != null) {
                return "sp:" + client.getServer().getSavePath(WorldSavePath.ROOT).toAbsolutePath()
                        + "|dim:" + client.world.getRegistryKey().getValue();
            }
            ServerInfo info = client.getCurrentServerEntry();
            if (info != null) {
                return "mp:" + info.address.toLowerCase(Locale.ROOT)
                        + "|dim:" + client.world.getRegistryKey().getValue();
            }
        } catch (RuntimeException ignored) {
            // fall through to the dimension-only key
        }
        return "dimension:" + client.world.getRegistryKey().getValue();
    }

    private static void rebuildQueue(int centerX, int centerZ, int radius) {
        SCAN_QUEUE.clear();
        for (int ring = 0; ring <= radius; ring++) {
            for (int x = -ring; x <= ring; x++) {
                for (int z = -ring; z <= ring; z++) {
                    if (Math.max(Math.abs(x), Math.abs(z)) != ring) continue;
                    SCAN_QUEUE.add(new ChunkCoordinate(centerX + x, centerZ + z));
                }
            }
        }
        queueIndex = 0;
        lastPlayerChunkX = centerX;
        lastPlayerChunkZ = centerZ;
        lastRadius = radius;
    }

    // ------------------------------------------------------------------ scan
    private static void scanChunk(MinecraftClient client, int chunkX, int chunkZ, Params p) {
        // The final argument is false: an unloaded chunk is never requested or generated here.
        Chunk chunk = client.world.getChunkManager().getChunk(chunkX, chunkZ, ChunkStatus.FULL, false);
        if (chunk == null) return;

        int minY = Math.max(client.world.getBottomY(), p.minY);
        int maxY = Math.min(client.world.getTopYInclusive(), p.depthCutoff);
        LinkedHashMap<Long, StorageRecord> foundStorage = new LinkedHashMap<Long, StorageRecord>();
        Map<Long, String> currentRedstone = new HashMap<Long, String>();

        if (maxY >= minY) {
            BlockPos.Mutable pos = new BlockPos.Mutable();
            for (int y = minY; y <= maxY; y++) {
                for (int lx = 0; lx < 16; lx++) {
                    for (int lz = 0; lz < 16; lz++) {
                        pos.set((chunkX << 4) + lx, y, (chunkZ << 4) + lz);
                        BlockState state = chunk.getBlockState(pos);
                        if (state.isAir()) continue;
                        String id = Registries.BLOCK.getId(state.getBlock()).getPath();
                        long packed = pos.asLong();
                        if (isStorage(id, p)) {
                            foundStorage.put(packed, new StorageRecord(id, captureOutline(state, client, pos)));
                        }
                        if (p.scanRedstone && isRedstoneRelated(id)) {
                            currentRedstone.put(packed, id + "|" + state);
                        }
                    }
                }
            }
        }

        long chunkKey = packChunk(chunkX, chunkZ);
        Map<Long, StorageRecord> previousChunkStorage = new HashMap<Long, StorageRecord>();
        for (Map.Entry<Long, StorageRecord> entry : STORAGE.entrySet()) {
            if (chunkOf(BlockPos.fromLong(entry.getKey())) == chunkKey) {
                previousChunkStorage.put(entry.getKey(), entry.getValue());
            }
        }
        if (!previousChunkStorage.equals(foundStorage)) {
            STORAGE.entrySet().removeIf(e -> chunkOf(BlockPos.fromLong(e.getKey())) == chunkKey);
            STORAGE.putAll(foundStorage);
            dirty = true;
            indexDirty = true;
        }
        while (STORAGE.size() > MAX_REMEMBERED_STORAGE) {
            Long oldest = STORAGE.keySet().iterator().next();
            STORAGE.remove(oldest);
            dirty = true;
            indexDirty = true;
        }

        if (p.scanRedstone) {
            Map<Long, String> previous = REDSTONE_SNAPSHOTS.put(chunkKey, currentRedstone);
            if (previous != null && !previous.equals(currentRedstone) && REDSTONE_ACTIVE_CHUNKS.add(chunkKey)) {
                dirty = true;
            }
            while (REDSTONE_SNAPSHOTS.size() > MAX_REDSTONE_SNAPSHOTS) {
                Iterator<Long> it = REDSTONE_SNAPSHOTS.keySet().iterator();
                it.next();
                it.remove();
            }
        }
        evaluateNotification(chunkKey, p);
    }

    private static List<ShapeBox> captureOutline(BlockState state, MinecraftClient client, BlockPos pos) {
        try {
            VoxelShape outline = state.getOutlineShape(client.world, pos, ShapeContext.absent());
            List<Box> boxes = outline.getBoundingBoxes();
            List<ShapeBox> result = new ArrayList<ShapeBox>(Math.min(boxes.size(), MAX_SHAPE_BOXES_PER_BLOCK));
            for (Box box : boxes) {
                if (result.size() >= MAX_SHAPE_BOXES_PER_BLOCK) break;
                ShapeBox shape = new ShapeBox(box.minX, box.minY, box.minZ, box.maxX, box.maxY, box.maxZ);
                if (shape.isUsable()) result.add(shape);
            }
            if (!result.isEmpty()) return List.copyOf(result);
        } catch (RuntimeException ignored) {
            // fall back to a full-block outline
        }
        return List.of(ShapeBox.FULL_BLOCK);
    }

    /** Storage test honouring the per-type switches of the module. */
    public static boolean isStorage(String id, Params p) {
        if (id.equals("hopper")) return p.hoppers;
        if (id.equals("dispenser") || id.equals("dropper")) return p.dispensers;
        if (id.equals("furnace") || id.equals("blast_furnace") || id.equals("smoker") || id.equals("brewing_stand")) return p.furnaces;
        return isStorage(id);
    }

    public static boolean isStorage(String id) {
        return id.equals("chest") || id.endsWith("_chest") || id.equals("barrel") || id.endsWith("_barrel")
                || id.contains("shulker_box") || id.equals("ender_chest") || id.equals("hopper")
                || id.equals("dispenser") || id.equals("dropper") || id.equals("furnace")
                || id.equals("blast_furnace") || id.equals("smoker") || id.equals("brewing_stand");
    }

    private static boolean isRedstoneRelated(String id) {
        return id.contains("redstone") || id.contains("repeater") || id.contains("comparator")
                || id.contains("observer") || id.contains("piston") || id.contains("lever")
                || id.contains("button") || id.contains("pressure_plate") || id.contains("tripwire")
                || id.contains("daylight_detector") || id.contains("target") || id.contains("sculk_sensor")
                || id.equals("tnt") || id.equals("note_block") || id.equals("dispenser")
                || id.equals("dropper") || id.equals("hopper") || id.endsWith("_door")
                || id.endsWith("_trapdoor") || id.endsWith("_fence_gate");
    }

    private static long packChunk(int x, int z) {
        return ((long) x & 0xFFFFFFFFL) | (((long) z & 0xFFFFFFFFL) << 32);
    }

    private static long chunkOf(BlockPos pos) {
        return packChunk(pos.getX() >> 4, pos.getZ() >> 4);
    }

    // ------------------------------------------------------------- reporting
    private static void rebuildIndex() {
        if (!indexDirty) return;
        CHUNK_COUNTS.clear();
        CHUNK_TYPES.clear();
        for (Map.Entry<Long, StorageRecord> e : STORAGE.entrySet()) {
            long chunk = chunkOf(BlockPos.fromLong(e.getKey()));
            CHUNK_COUNTS.merge(chunk, 1, Integer::sum);
            Map<String, Integer> types = CHUNK_TYPES.get(chunk);
            if (types == null) {
                types = new TreeMap<String, Integer>();
                CHUNK_TYPES.put(chunk, types);
            }
            types.merge(e.getValue().blockId, 1, Integer::sum);
        }
        indexDirty = false;
    }

    private static boolean qualifies(long chunkKey, Params p) {
        rebuildIndex();
        int count = CHUNK_COUNTS.containsKey(chunkKey) ? CHUNK_COUNTS.get(chunkKey) : 0;
        if (count < Math.max(4, p.threshold)) return false;
        return !p.requireRedstone || REDSTONE_ACTIVE_CHUNKS.contains(chunkKey);
    }

    private static void evaluateNotification(long chunkKey, Params p) {
        boolean suspicious = qualifies(chunkKey, p);
        if (!suspicious) {
            if (NOTIFIED.remove(chunkKey)) dirty = true;
            return;
        }
        if (!NOTIFIED.add(chunkKey)) return; // already announced: never repeat every tick
        dirty = true;
        int cx = (int) chunkKey;
        int cz = (int) (chunkKey >> 32);
        Map<String, Integer> types = CHUNK_TYPES.get(chunkKey);
        StringBuilder list = new StringBuilder();
        if (types != null) {
            for (Map.Entry<String, Integer> e : types.entrySet()) {
                if (list.length() > 0) list.append(", ");
                list.append(e.getValue()).append("x ").append(e.getKey());
            }
        }
        int total = CHUNK_COUNTS.containsKey(chunkKey) ? CHUNK_COUNTS.get(chunkKey) : 0;
        if (p.notifyChat) {
            Notifier.chat("Suspicious chunk detected at chunk (" + cx + ", " + cz + ") around X "
                    + (cx * 16 + 8) + " Z " + (cz * 16 + 8) + " - " + total + " storage blocks: " + list);
        }
        BlockPos centre = new BlockPos(cx * 16 + 8, 0, cz * 16 + 8);
        dev.ratman.phantom.util.FindLog.add("Sus chunk", total + " storage blocks: " + list, centre);
        if (p.copyCoords) dev.ratman.phantom.util.Compat.clipboard((cx * 16 + 8) + " ~ " + (cz * 16 + 8));
        if (p.notifySound) Notifier.sound(Notifier.SOUND_SUSPICIOUS, 1.0f, 1.2f);
    }

    public static List<StorageBlock> highlighted(double x, double y, double z, double maxDistance, Params p) {
        rebuildIndex();
        int minimum = Math.max(4, p.threshold);
        double maxSq = maxDistance * maxDistance;
        List<StorageBlock> result = new ArrayList<StorageBlock>();
        for (Map.Entry<Long, StorageRecord> entry : STORAGE.entrySet()) {
            BlockPos pos = BlockPos.fromLong(entry.getKey());
            long chunkKey = chunkOf(pos);
            Integer count = CHUNK_COUNTS.get(chunkKey);
            if (count == null || count < minimum) continue;
            if (p.requireRedstone && !REDSTONE_ACTIVE_CHUNKS.contains(chunkKey)) continue;
            double dx = pos.getX() + 0.5 - x;
            double dy = pos.getY() + 0.5 - y;
            double dz = pos.getZ() + 0.5 - z;
            if (dx * dx + dy * dy + dz * dz > maxSq) continue;
            StorageRecord record = entry.getValue();
            result.add(new StorageBlock(pos.toImmutable(), record.blockId, record.outline));
            if (result.size() >= 1000) break;
        }
        return result;
    }

    /** Chunk keys (cx, cz packed) currently considered suspicious; for the Region Map. */
    public static List<int[]> suspiciousChunks(Params p) {
        rebuildIndex();
        List<int[]> out = new ArrayList<int[]>();
        for (Map.Entry<Long, Integer> e : CHUNK_COUNTS.entrySet()) {
            if (qualifies(e.getKey(), p)) out.add(new int[]{(int) (long) e.getKey(), (int) (e.getKey() >> 32)});
        }
        return out;
    }

    public static int rememberedStorage() { return STORAGE.size(); }

    // ----------------------------------------------------------- persistence
    private static Path memoryPath() {
        return ConfigStore.dataDir().resolve("chunks-" + ConfigStore.worldFileId(activeWorldKey) + ".properties");
    }

    private static Path legacyPath() {
        return FabricLoader.getInstance().getConfigDir()
                .resolve("phantom-client-chunks-" + ConfigStore.worldFileId(activeWorldKey) + ".properties");
    }

    private static void load() {
        Path path = memoryPath();
        if (!Files.exists(path)) path = legacyPath();
        if (!Files.exists(path)) return;
        Properties properties = new Properties();
        try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            properties.load(reader);
            for (String key : properties.stringPropertyNames()) {
                try {
                    if (key.startsWith("storage.")) {
                        long pos = Long.parseLong(key.substring("storage.".length()));
                        STORAGE.put(pos, parseStorageRecord(properties.getProperty(key, "")));
                    } else if (key.startsWith("redstone.")) {
                        REDSTONE_ACTIVE_CHUNKS.add(Long.parseLong(key.substring("redstone.".length())));
                    } else if (key.startsWith("notified.")) {
                        NOTIFIED.add(Long.parseLong(key.substring("notified.".length())));
                    }
                } catch (IllegalArgumentException malformed) {
                    LOG.warn("[Phantom] Skipping invalid chunk-memory entry {}", key);
                }
            }
            while (STORAGE.size() > MAX_REMEMBERED_STORAGE) STORAGE.remove(STORAGE.keySet().iterator().next());
            indexDirty = true;
        } catch (IOException e) {
            LOG.error("[Phantom] Could not load chunk memory", e);
        }
    }

    private static StorageRecord parseStorageRecord(String encoded) {
        String[] parts = encoded.split("\\|", 2);
        String blockId = (parts.length == 0 || parts[0].isBlank()) ? "unknown" : parts[0];
        if (parts.length == 1 || parts[1].isBlank()) return new StorageRecord(blockId, List.of(ShapeBox.FULL_BLOCK));
        List<ShapeBox> boxes = new ArrayList<ShapeBox>();
        for (String encodedBox : parts[1].split(";")) {
            if (boxes.size() >= MAX_SHAPE_BOXES_PER_BLOCK) break;
            String[] v = encodedBox.split(",");
            if (v.length != 6) continue;
            try {
                ShapeBox box = new ShapeBox(Double.parseDouble(v[0]), Double.parseDouble(v[1]), Double.parseDouble(v[2]),
                        Double.parseDouble(v[3]), Double.parseDouble(v[4]), Double.parseDouble(v[5]));
                if (box.isUsable()) boxes.add(box);
            } catch (NumberFormatException ignored) {
                // skip one malformed box
            }
        }
        return new StorageRecord(blockId, boxes.isEmpty() ? List.of(ShapeBox.FULL_BLOCK) : boxes);
    }

    private static String serialize(StorageRecord record) {
        StringBuilder value = new StringBuilder(record.blockId).append('|');
        for (int i = 0; i < record.outline.size(); i++) {
            ShapeBox b = record.outline.get(i);
            if (i > 0) value.append(';');
            value.append(b.minX).append(',').append(b.minY).append(',').append(b.minZ).append(',')
                    .append(b.maxX).append(',').append(b.maxY).append(',').append(b.maxZ);
        }
        return value.toString();
    }

    private static void flushIfDirty() {
        if (dirty) save();
    }

    public static void save() {
        if (activeWorldKey.isEmpty() || !dirty) return;
        Properties properties = new Properties();
        for (Map.Entry<Long, StorageRecord> e : STORAGE.entrySet()) {
            properties.setProperty("storage." + e.getKey(), serialize(e.getValue()));
        }
        for (Long chunk : REDSTONE_ACTIVE_CHUNKS) properties.setProperty("redstone." + chunk, "true");
        for (Long chunk : NOTIFIED) properties.setProperty("notified." + chunk, "true");
        Path path = memoryPath();
        Path temporary = path.resolveSibling(path.getFileName().toString() + ".tmp");
        try {
            Files.createDirectories(path.getParent());
            try (Writer writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8)) {
                properties.store(writer, "Phantom Client persistent suspicious chunk memory");
            }
            try {
                Files.move(temporary, path, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ignored) {
                Files.move(temporary, path, StandardCopyOption.REPLACE_EXISTING);
            }
            dirty = false;
            lastSaveAt = System.currentTimeMillis();
        } catch (IOException e) {
            LOG.error("[Phantom] Could not save chunk memory", e);
        }
    }
}
