package dev.ratman.phantom.mixin;

import dev.ratman.phantom.modules.FeatureModules;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.Direction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Forces all faces of selected Xray blocks to render even when surrounded by solid blocks.
 * Both known shouldDrawSide overloads are hooked; whichever one the current Minecraft build uses
 * for chunk meshing takes effect, and a missing overload is simply skipped (require = 0).
 */
@Mixin(Block.class)
public abstract class BlockMixin {
    @Inject(method = "shouldDrawSide(Lnet/minecraft/block/BlockState;Lnet/minecraft/block/BlockState;Lnet/minecraft/util/math/Direction;)Z",
            at = @At("HEAD"), cancellable = true, require = 0)
    private static void phantom$showHiddenTargetFaces(BlockState state, BlockState otherState, Direction side,
                                                       CallbackInfoReturnable<Boolean> cir) {
        if (FeatureModules.xrayEnabled() && FeatureModules.shouldRenderInXray(state)) cir.setReturnValue(true);
    }

    @Inject(method = "shouldDrawSide(Lnet/minecraft/block/BlockState;Lnet/minecraft/world/BlockView;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/math/Direction;Lnet/minecraft/util/math/BlockPos;)Z",
            at = @At("HEAD"), cancellable = true, require = 0)
    private static void phantom$showHiddenTargetFacesWorld(BlockState state, net.minecraft.world.BlockView world,
                                                            net.minecraft.util.math.BlockPos pos, Direction side,
                                                            net.minecraft.util.math.BlockPos otherPos,
                                                            CallbackInfoReturnable<Boolean> cir) {
        if (FeatureModules.xrayEnabled() && FeatureModules.shouldRenderInXray(state)) cir.setReturnValue(true);
    }
}
