package dev.ratman.phantom.module;

import com.mojang.logging.LogUtils;
import dev.ratman.phantom.config.ConfigStore;
import dev.ratman.phantom.setting.Setting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 * Base class of every Phantom module. A module owns its typed settings, a keybind and optional
 * tick / world-render / HUD hooks. Hooks are invoked through {@link ModuleManager}, which isolates
 * failures so one broken module cannot crash the client.
 */
public abstract class Module {
    protected static final Logger LOG = LogUtils.getLogger();

    public final String id;
    public final String name;
    public final String description;
    public final ModuleCategory category;
    protected final MinecraftClient mc = MinecraftClient.getInstance();

    private boolean enabled;
    private int key = -1;
    private final List<Setting<?>> settings = new ArrayList<Setting<?>>();

    /** Settings-only modules (e.g. Performance) have no on/off state in the GUI. */
    public boolean alwaysOn;
    /** Hidden modules are not listed in the Active Modules HUD. */
    public boolean hideFromList;
    /** Whether the module is switched on in a fresh / reset profile. */
    public boolean defaultOn;
    int consecutiveErrors;

    protected Module(String id, String name, ModuleCategory category, String description) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.description = description;
    }

    // ------------------------------------------------------------------ state
    public final boolean enabled() { return alwaysOn || enabled; }

    public final void setEnabled(boolean value) {
        if (alwaysOn) value = true;
        if (value == enabled) return;
        enabled = value;
        consecutiveErrors = 0;
        try {
            if (value) onEnable(); else onDisable();
        } catch (RuntimeException e) {
            LOG.error("[Phantom] {} failed during {}", name, value ? "enable" : "disable", e);
        }
        ConfigStore.markDirty();
    }

    /** Used while loading a profile: applies state, then runs the matching lifecycle hook. */
    public final void applyLoadedState(boolean value) {
        boolean previous = enabled;
        enabled = alwaysOn || value;
        consecutiveErrors = 0;
        try {
            if (enabled && !previous) onEnable();
            else if (!enabled && previous) onDisable();
        } catch (RuntimeException e) {
            LOG.error("[Phantom] {} failed while loading profile", name, e);
        }
    }

    public final void toggle() { setEnabled(!enabled); }

    public final int keyCode() { return key; }

    public final void setKeyCode(int code) {
        this.key = code;
        ConfigStore.markDirty();
    }

    // ------------------------------------------------------------------ hooks
    public void onEnable() {}

    public void onDisable() {}

    /** Called every client tick while enabled and a world is loaded. */
    public void onTick() {}

    /** Called at the START of every client tick (before input is processed) while enabled and in a world. */
    public void onPreTick() {}

    /** Called every client tick while enabled but NOT in a world (title / disconnected screens). */
    public void onIdle() {}

    /** Called once per rendered frame while enabled and a world is loaded. */
    public void onFrame(float dt) {}

    /** Called from the world-render event while enabled. */
    public void onRender3D(WorldRenderContext context, float tickDelta) {}

    /** Called from the HUD layer while enabled. */
    public void onHud(DrawContext context, float tickDelta) {}

    /** Called when the player leaves or changes world. */
    public void onWorldReset() {}

    /** Short suffix for the Active Modules HUD (for example the current mode). */
    public String info() { return ""; }

    // --------------------------------------------------------------- settings
    public final List<Setting<?>> settings() { return settings; }

    public final Setting<?> setting(String settingKey) {
        for (Setting<?> s : settings) if (s.key.equals(settingKey)) return s;
        return null;
    }

    protected final <S extends Setting<?>> S add(S setting) {
        settings.add(setting);
        return setting;
    }

    protected final Setting.Bool bool(String k, String label, boolean def) {
        return add(new Setting.Bool(k, label, def));
    }

    protected final Setting.Num num(String k, String label, double def, double min, double max, double step) {
        return add(new Setting.Num(k, label, def, min, max, step, ""));
    }

    protected final Setting.Num num(String k, String label, double def, double min, double max, double step, String suffix) {
        return add(new Setting.Num(k, label, def, min, max, step, suffix));
    }

    protected final Setting.Mode mode(String k, String label, String def, String... modes) {
        return add(new Setting.Mode(k, label, def, modes));
    }

    protected final Setting.Col color(String k, String label, int argb) {
        return add(new Setting.Col(k, label, argb, false));
    }

    protected final Setting.Col colorA(String k, String label, int argb) {
        return add(new Setting.Col(k, label, argb, true));
    }

    protected final Setting.Text text(String k, String label, String def, int max) {
        return add(new Setting.Text(k, label, def, max));
    }

    public void resetSettings() {
        for (Setting<?> s : settings) s.reset();
        ConfigStore.markDirty();
    }

    protected final boolean ready() {
        return mc.player != null && mc.world != null;
    }
}
