package dev.ratman.phantom.util;

import com.mojang.logging.LogUtils;
import dev.ratman.phantom.config.ConfigStore;
import dev.ratman.phantom.module.Module;
import dev.ratman.phantom.module.ModuleManager;
import dev.ratman.phantom.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import org.slf4j.Logger;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Central record of everything the base-hunting modules discover (stashes, spawners, signs, ...).
 * Entries stay in memory for the Find Log HUD and are optionally appended to
 * {@code config/phantom/logs/finds-YYYY-MM-DD.log} so coordinates survive a crash or disconnect.
 */
public final class FindLog {
    private static final Logger LOG = LogUtils.getLogger();
    private static final int MAX = 100;
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final List<Entry> ENTRIES = new ArrayList<Entry>();

    public static final class Entry {
        public final String time;
        public final String type;
        public final String message;
        public final BlockPos pos;
        public final String dimension;

        Entry(String time, String type, String message, BlockPos pos, String dimension) {
            this.time = time;
            this.type = type;
            this.message = message;
            this.pos = pos;
            this.dimension = dimension;
        }

        public String coords() {
            return pos == null ? "" : pos.getX() + " " + pos.getY() + " " + pos.getZ();
        }
    }

    private FindLog() {}

    public static void add(String type, String message, BlockPos pos) {
        MinecraftClient mc = MinecraftClient.getInstance();
        String dim = mc.world == null ? "?" : mc.world.getRegistryKey().getValue().getPath();
        Entry e = new Entry(LocalDateTime.now().format(TIME), type, message, pos == null ? null : pos.toImmutable(), dim);
        ENTRIES.add(e);
        while (ENTRIES.size() > MAX) ENTRIES.remove(0);
        if (fileLoggingEnabled()) append(e);
    }

    public static List<Entry> recent(int count) {
        int from = Math.max(0, ENTRIES.size() - count);
        return new ArrayList<Entry>(ENTRIES.subList(from, ENTRIES.size()));
    }

    public static Entry last() { return ENTRIES.isEmpty() ? null : ENTRIES.get(ENTRIES.size() - 1); }

    public static Entry lastWithPosition() {
        for (int i = ENTRIES.size() - 1; i >= 0; i--) if (ENTRIES.get(i).pos != null) return ENTRIES.get(i);
        return null;
    }

    public static void clear() { ENTRIES.clear(); }

    private static boolean fileLoggingEnabled() {
        Module m = ModuleManager.byId("find_log");
        if (m == null) return true;
        Setting<?> s = m.setting("file");
        return !(s instanceof Setting.Bool) || ((Setting.Bool) s).on();
    }

    private static void append(Entry e) {
        try {
            Path dir = ConfigStore.dataDir().getParent().resolve("logs");
            Files.createDirectories(dir);
            Path file = dir.resolve("finds-" + LocalDate.now() + ".log");
            String line = e.time + " [" + e.dimension + "] " + e.type + ": " + e.message
                    + (e.pos == null ? "" : " @ " + e.coords()) + System.lineSeparator();
            Files.write(file, line.getBytes(StandardCharsets.UTF_8), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException ex) {
            LOG.warn("[Phantom] Could not write find log: {}", ex.toString());
        }
    }
}
