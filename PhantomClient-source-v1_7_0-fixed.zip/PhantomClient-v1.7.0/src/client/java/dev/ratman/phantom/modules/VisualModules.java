package dev.ratman.phantom.modules;

import dev.ratman.phantom.module.Module;
import dev.ratman.phantom.module.ModuleCategory;
import dev.ratman.phantom.module.ModuleManager;
import dev.ratman.phantom.setting.Setting;
import dev.ratman.phantom.util.Draw;
import dev.ratman.phantom.util.RenderUtil;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Visuals category. */
public final class VisualModules {
    private VisualModules() {}

    public static void register() {
        ModuleManager.register(new CustomCrosshair());
        ModuleManager.register(new CustomFov());
        ModuleManager.register(new BlockOverlay());
        ModuleManager.register(new JumpCircles());
    }

    /** Whether the vanilla crosshair should be replaced by the custom one. */
    public static boolean hideVanillaCrosshair() {
        Module m = ModuleManager.byId("custom_crosshair");
        if (!(m instanceof CustomCrosshair) || !m.enabled()) return false;
        return ((CustomCrosshair) m).hideVanilla.on();
    }

    // ================================================================== Custom Crosshair
    static final class CustomCrosshair extends Module {
        final Setting.Mode style = mode("style", "Style", "Plus", "Plus", "Cross", "Dot", "Circle", "Square");
        final Setting.Num size = num("size", "Size", 5.0, 1.0, 20.0, 1.0, " px");
        final Setting.Num gap = num("gap", "Gap", 3.0, 0.0, 12.0, 1.0, " px");
        final Setting.Num thickness = num("thickness", "Thickness", 1.0, 1.0, 4.0, 1.0, " px");
        final Setting.Col color = colorA("color", "Colour", 0xFFC084FC);
        final Setting.Bool outline = bool("outline", "Dark outline", true);
        final Setting.Bool centerDot = bool("dot", "Centre dot", false);
        final Setting.Bool dynamic = bool("dynamic", "Expand while moving", true);
        final Setting.Bool hideVanilla = bool("hidevanilla", "Hide vanilla crosshair", true);

        CustomCrosshair() {
            super("custom_crosshair", "Custom Crosshair", ModuleCategory.VISUALS, "Replaces the crosshair with a configurable one.");
        }

        private void rect(DrawContext c, int x1, int y1, int x2, int y2) {
            if (outline.on()) c.fill(x1 - 1, y1 - 1, x2 + 1, y2 + 1, 0xCC000000);
            c.fill(x1, y1, x2, y2, color.argb());
        }

        @Override public void onHud(DrawContext c, float td) {
            if (mc.currentScreen != null) return;
            int cx = c.getScaledWindowWidth() / 2;
            int cy = c.getScaledWindowHeight() / 2;
            int t = thickness.i();
            int s = size.i();
            int g = gap.i();
            ClientPlayerEntity p = mc.player;
            if (dynamic.on() && p != null) {
                Vec3d v = p.getVelocity();
                double h = Math.sqrt(v.x * v.x + v.z * v.z);
                g += (int) Math.min(6, Math.round(h * 20));
                if (!p.isOnGround()) g += 2;
            }
            int lo = -t / 2;
            int hi = lo + t;
            String st = style.get();
            if (st.equals("Plus")) {
                rect(c, cx + lo, cy - g - s, cx + hi, cy - g);
                rect(c, cx + lo, cy + g, cx + hi, cy + g + s);
                rect(c, cx - g - s, cy + lo, cx - g, cy + hi);
                rect(c, cx + g, cy + lo, cx + g + s, cy + hi);
            } else if (st.equals("Cross")) {
                for (int i = 0; i < s; i++) {
                    int d = g + i;
                    rect(c, cx - d - t / 2, cy - d - t / 2, cx - d + t - t / 2, cy - d + t - t / 2);
                    rect(c, cx + d - t / 2, cy - d - t / 2, cx + d + t - t / 2, cy - d + t - t / 2);
                    rect(c, cx - d - t / 2, cy + d - t / 2, cx - d + t - t / 2, cy + d + t - t / 2);
                    rect(c, cx + d - t / 2, cy + d - t / 2, cx + d + t - t / 2, cy + d + t - t / 2);
                }
            } else if (st.equals("Dot")) {
                rect(c, cx - s / 2, cy - s / 2, cx - s / 2 + Math.max(2, s), cy - s / 2 + Math.max(2, s));
            } else if (st.equals("Square")) {
                int r = g + s;
                rect(c, cx - r, cy - r, cx + r, cy - r + t);
                rect(c, cx - r, cy + r - t, cx + r, cy + r);
                rect(c, cx - r, cy - r, cx - r + t, cy + r);
                rect(c, cx + r - t, cy - r, cx + r, cy + r);
            } else {
                int r = g + s;
                for (int a = 0; a < 48; a++) {
                    double ang = a / 48.0 * Math.PI * 2;
                    int x = cx + (int) Math.round(Math.cos(ang) * r);
                    int y = cy + (int) Math.round(Math.sin(ang) * r);
                    rect(c, x, y, x + t, y + t);
                }
            }
            if (centerDot.on()) rect(c, cx - 1, cy - 1, cx + 1, cy + 1);
        }
    }

    // ================================================================== Custom FOV
    static final class CustomFov extends Module {
        final Setting.Num fov = num("fov", "Field of view", 90.0, 30.0, 110.0, 1.0, "\u00b0");
        private int previous = -1;

        CustomFov() {
            super("custom_fov", "Custom FOV", ModuleCategory.VISUALS, "Overrides your field of view (vanilla range 30-110).");
        }

        @Override public void onEnable() {
            if (mc.options != null) previous = mc.options.getFov().getValue();
        }

        @Override public void onTick() {
            if (previous < 0) previous = mc.options.getFov().getValue();
            if (mc.options.getFov().getValue() != fov.i()) mc.options.getFov().setValue(fov.i());
        }

        @Override public void onDisable() {
            if (previous >= 30 && mc.options != null) mc.options.getFov().setValue(previous);
            previous = -1;
        }
    }

    // ================================================================== Block Overlay
    static final class BlockOverlay extends Module {
        final Setting.Col color = color("color", "Colour", 0xFFC084FC);
        final Setting.Bool glow = bool("glow", "Glow", true);
        final Setting.Col glowColor = color("glowcolor", "Glow colour", 0xFFE9D5FF);
        final Setting.Num glowIntensity = num("glowintensity", "Glow intensity", 2.0, 1.0, 5.0, 1.0);
        final Setting.Bool shapeOutline = bool("shape", "Follow block shape", true);

        BlockOverlay() {
            super("block_overlay", "Block Overlay", ModuleCategory.VISUALS, "Draws a coloured outline (with optional glow) on the block you look at.");
            glowColor.visibleWhen(() -> glow.on());
            glowIntensity.visibleWhen(() -> glow.on());
        }

        @Override public void onRender3D(WorldRenderContext ctx, float td) {
            if (!(mc.crosshairTarget instanceof BlockHitResult) || mc.crosshairTarget.getType() != HitResult.Type.BLOCK) return;
            RenderUtil.Pass pass = RenderUtil.begin(ctx);
            if (pass == null) return;
            BlockPos pos = ((BlockHitResult) mc.crosshairTarget).getBlockPos();
            List<Box> boxes = new ArrayList<Box>();
            if (shapeOutline.on()) {
                BlockState state = mc.world.getBlockState(pos);
                try {
                    for (Box b : state.getOutlineShape(mc.world, pos, ShapeContext.absent()).getBoundingBoxes()) {
                        boxes.add(b.offset(pos.getX(), pos.getY(), pos.getZ()));
                    }
                } catch (RuntimeException ignored) {
                    // fall back to a full block
                }
            }
            if (boxes.isEmpty()) boxes.add(new Box(pos));
            for (Box b : boxes) {
                pass.box(b, color.argb(), 0, 0f);
                if (glow.on()) pass.glow(b, glowColor.argb(), glowIntensity.i() + 1, 1.0f);
            }
        }
    }

    // ================================================================== Jump Circles
    static final class JumpCircles extends Module {
        final Setting.Col color = color("color", "Colour", 0xFFC084FC);
        final Setting.Num size = num("size", "Max radius", 1.6, 0.5, 4.0, 0.1, " blocks");
        final Setting.Num duration = num("duration", "Duration", 700.0, 200.0, 2000.0, 50.0, " ms");
        private final List<double[]> circles = new ArrayList<double[]>();
        private boolean wasOnGround = true;

        JumpCircles() {
            super("jump_circles", "Jump Circles", ModuleCategory.VISUALS, "Leaves a fading ring on the ground where you jump.");
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (wasOnGround && !p.isOnGround() && p.getVelocity().y > 0.1) {
                circles.add(new double[]{p.getX(), p.getY() + 0.02, p.getZ(), System.currentTimeMillis()});
            }
            wasOnGround = p.isOnGround();
            long now = System.currentTimeMillis();
            Iterator<double[]> it = circles.iterator();
            while (it.hasNext()) if (now - it.next()[3] > duration.d()) it.remove();
        }

        @Override public void onWorldReset() { circles.clear(); }

        @Override public void onRender3D(WorldRenderContext ctx, float td) {
            if (circles.isEmpty()) return;
            RenderUtil.Pass pass = RenderUtil.begin(ctx);
            if (pass == null) return;
            long now = System.currentTimeMillis();
            for (double[] c : circles) {
                double age = (now - c[3]) / duration.d();
                double r = size.d() * Math.min(1.0, age * 1.4);
                int col = Draw.alpha(color.argb(), (float) Math.max(0.0, 1.0 - age));
                Vec3d prev = null;
                for (int i = 0; i <= 32; i++) {
                    double a = i / 32.0 * Math.PI * 2;
                    Vec3d cur = new Vec3d(c[0] + Math.cos(a) * r, c[1], c[2] + Math.sin(a) * r);
                    if (prev != null) pass.line(prev, cur, col);
                    prev = cur;
                }
            }
        }
    }
}
