package dev.ratman.phantom.mixin;

import dev.ratman.phantom.modules.FeatureModules;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * LivingEntityRenderer overrides hasLabel without calling the EntityRenderer version, so the Nametags
 * module has to hook it here as well for players and mobs to actually get forced nameplates.
 */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin<T extends LivingEntity> {
    @Inject(method = "hasLabel", at = @At("HEAD"), cancellable = true, require = 0)
    private void phantom$forceLivingNameplates(T entity, double squaredDistanceToCamera, CallbackInfoReturnable<Boolean> cir) {
        if (FeatureModules.shouldForceNametag(entity, squaredDistanceToCamera)) cir.setReturnValue(true);
    }
}
