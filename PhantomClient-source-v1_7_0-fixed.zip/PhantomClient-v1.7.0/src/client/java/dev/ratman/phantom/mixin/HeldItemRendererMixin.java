package dev.ratman.phantom.mixin;

import dev.ratman.phantom.modules.FeatureModules;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Applies pose offsets only around the local first-person hand render call. */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"))
    private void phantom$pushHandPose(AbstractClientPlayerEntity player, float tickProgress, float pitch,
                                      Hand hand, float swingProgress, ItemStack item, float equipProgress,
                                      MatrixStack matrices, OrderedRenderCommandQueue queue, int light,
                                      CallbackInfo ci) {
        if (player != net.minecraft.client.MinecraftClient.getInstance().player || !FeatureModules.handPoseEnabled()) return;
        matrices.push();
        FeatureModules.transformHand(matrices);
    }

    @Inject(method = "renderFirstPersonItem", at = @At("RETURN"))
    private void phantom$popHandPose(AbstractClientPlayerEntity player, float tickProgress, float pitch,
                                     Hand hand, float swingProgress, ItemStack item, float equipProgress,
                                     MatrixStack matrices, OrderedRenderCommandQueue queue, int light,
                                     CallbackInfo ci) {
        if (player == net.minecraft.client.MinecraftClient.getInstance().player && FeatureModules.handPoseEnabled()) matrices.pop();
    }
}
