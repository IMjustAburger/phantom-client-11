package dev.ratman.phantom.mixin;

import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Reads the mapped package-private hurt timer for local hit-particle detection. */
@Mixin(LivingEntity.class)
public interface LivingEntityAccessor {
    @Accessor("hurtTime")
    int phantom$getHurtTime();
}
