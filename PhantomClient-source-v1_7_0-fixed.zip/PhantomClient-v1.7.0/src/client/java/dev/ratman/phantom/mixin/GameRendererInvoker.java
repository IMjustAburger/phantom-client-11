package dev.ratman.phantom.mixin;

import net.minecraft.client.render.GameRenderer;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Access for loading and restoring the local motion-blur post effect. */
@Mixin(GameRenderer.class)
public interface GameRendererInvoker {
    @Accessor("postProcessorId")
    Identifier phantom$getPostProcessorId();

    @Invoker("setPostProcessor")
    void phantom$setPostProcessor(Identifier id);
}
