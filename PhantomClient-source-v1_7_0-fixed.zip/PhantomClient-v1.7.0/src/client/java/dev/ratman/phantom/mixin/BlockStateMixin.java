package dev.ratman.phantom.mixin;

import dev.ratman.phantom.modules.FeatureModules;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Hides non-target block models in the local chunk render pass while Xray is enabled. */
@Mixin(AbstractBlock.AbstractBlockState.class)
public abstract class BlockStateMixin {
    @Inject(method = "getRenderType", at = @At("RETURN"), cancellable = true)
    private void phantom$hideUnselectedBlocks(CallbackInfoReturnable<BlockRenderType> cir) {
        if (!FeatureModules.xrayEnabled()) return;
        BlockState state = (BlockState) (Object) this;
        if (!FeatureModules.shouldRenderInXray(state)) cir.setReturnValue(BlockRenderType.INVISIBLE);
    }
}
