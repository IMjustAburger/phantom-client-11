package dev.ratman.phantom.modules;

import dev.ratman.phantom.module.Module;
import dev.ratman.phantom.module.ModuleCategory;
import dev.ratman.phantom.module.ModuleManager;
import dev.ratman.phantom.setting.Setting;
import dev.ratman.phantom.util.Compat;
import dev.ratman.phantom.util.Inv;
import dev.ratman.phantom.util.Notifier;
import dev.ratman.phantom.world.BlockScanner;
import net.minecraft.block.BlockState;
import net.minecraft.client.gui.screen.DisconnectedScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;

import java.util.HashSet;
import java.util.Set;

/** Misc category. */
public final class MiscModules {
    private MiscModules() {}

    public static void register() {
        ModuleManager.register(new AutoEat());
        ModuleManager.register(new AutoReconnect());
        ModuleManager.register(new AutoReplenish());
        ModuleManager.register(new BlockNotifier());
        ModuleManager.register(new ChatMacro());
        ModuleManager.register(new CoordSnapper());
        ModuleManager.register(new FastUse());
        ModuleManager.register(new LegitAutoTool());
        ModuleManager.register(new WeatherNotifier());
    }

    // ================================================================== Auto Eat
    static final class AutoEat extends Module {
        final Setting.Num hunger = num("hunger", "Eat at or below", 14.0, 1.0, 19.0, 1.0, " food");
        final Setting.Bool gapples = bool("gapples", "Allow golden apples", false);
        final Setting.Bool lowHealth = bool("lowhp", "Also eat when health is low", true);
        private boolean eating;
        private int previousSlot = -1;
        private int ticks;

        AutoEat() {
            super("auto_eat", "Auto Eat", ModuleCategory.MISC, "Eats food from your hotbar when hungry.");
        }

        private boolean good(ItemStack s) {
            if (s.isEmpty() || !s.contains(DataComponentTypes.FOOD)) return false;
            String id = Registries.ITEM.getId(s.getItem()).getPath();
            if (id.equals("rotten_flesh") || id.equals("spider_eye") || id.equals("poisonous_potato")
                    || id.equals("pufferfish") || id.equals("chorus_fruit") || id.equals("suspicious_stew")
                    || id.equals("raw_chicken") || id.equals("chicken")) {
                return false;
            }
            if (id.contains("golden_apple")) return gapples.on();
            return true;
        }

        private void stop() {
            if (eating) KeyBinding.updatePressedStates();
            if (previousSlot >= 0) Compat.selectHotbar(previousSlot);
            eating = false;
            previousSlot = -1;
            ticks = 0;
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (mc.currentScreen != null) {
                if (eating) stop();
                return;
            }
            int food = p.getHungerManager().getFoodLevel();
            if (!eating) {
                boolean need = food <= hunger.i() || (lowHealth.on() && p.getHealth() <= 10f && food < 20);
                if (!need) return;
                int slot = Inv.findHotbar(this::good);
                if (slot < 0) return;
                previousSlot = Compat.selectedHotbar();
                Compat.selectHotbar(slot);
                eating = true;
                ticks = 0;
            }
            ticks++;
            if (!good(Inv.main()) || ticks > 120 || (ticks > 6 && !p.isUsingItem())) {
                stop();
                return;
            }
            mc.options.useKey.setPressed(true);
        }

        @Override public void onDisable() { stop(); }
    }

    // ================================================================== Auto Reconnect
    static final class AutoReconnect extends Module {
        final Setting.Num delay = num("delay", "Delay", 5.0, 1.0, 60.0, 1.0, " s");
        final Setting.Num attempts = num("attempts", "Max attempts", 10.0, 1.0, 50.0, 1.0);
        private ServerInfo lastServer;
        private long countdownStart;
        private int tries;

        AutoReconnect() {
            super("auto_reconnect", "Auto Reconnect", ModuleCategory.MISC,
                    "Reconnects to the last multiplayer server after a disconnect.");
        }

        @Override public void onTick() {
            ServerInfo info = mc.getCurrentServerEntry();
            if (info != null) lastServer = info;
            tries = 0;
            countdownStart = 0;
        }

        @Override public void onIdle() {
            if (lastServer == null || !(mc.currentScreen instanceof DisconnectedScreen)) {
                countdownStart = 0;
                return;
            }
            if (tries >= attempts.i()) return;
            long now = System.currentTimeMillis();
            if (countdownStart == 0) countdownStart = now;
            if (now - countdownStart >= Math.round(delay.d() * 1000.0)) {
                countdownStart = 0;
                tries++;
                Compat.reconnect(lastServer);
            }
        }
    }

    // ================================================================== Auto Replenish
    static final class AutoReplenish extends Module {
        final Setting.Num threshold = num("threshold", "Refill at or below", 8.0, 1.0, 32.0, 1.0, " items");
        final Setting.Num delay = num("delay", "Delay", 6.0, 1.0, 40.0, 1.0, " ticks");
        private int wait;

        AutoReplenish() {
            super("auto_replenish", "Auto Replenish", ModuleCategory.MISC,
                    "Refills hotbar stacks from your inventory when they run low.");
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (!Inv.canClick()) return;
            if (wait > 0) {
                wait--;
                return;
            }
            for (int h = 0; h < 9; h++) {
                ItemStack s = p.getInventory().getStack(h);
                if (s.isEmpty() || s.getMaxCount() <= 1 || s.getCount() > threshold.i()) continue;
                Item item = s.getItem();
                for (int i = 9; i < 36; i++) {
                    ItemStack other = p.getInventory().getStack(i);
                    if (!other.isEmpty() && other.isOf(item)) {
                        Inv.click(Inv.slotId(i), 0, SlotActionType.PICKUP);
                        Inv.click(Inv.slotId(h), 0, SlotActionType.PICKUP);
                        Inv.click(Inv.slotId(i), 0, SlotActionType.PICKUP);
                        wait = delay.i();
                        return;
                    }
                }
            }
        }
    }

    // ================================================================== Block Notifier
    static final class BlockNotifier extends Module {
        final Setting.Blocks blocks = add(new Setting.Blocks("blocks", "Blocks", 0xFFFFD166, null, false));
        final Setting.Num radius = num("radius", "Scan radius", 5.0, 1.0, 10.0, 1.0, " chunks");
        final Setting.Bool chat = bool("chat", "Chat message", true);
        final Setting.Bool sound = bool("sound", "Sound", true);
        private final BlockScanner scanner = new BlockScanner();
        private final Set<Long> announced = new HashSet<Long>();
        private int sinceLast;

        BlockNotifier() {
            super("block_notifier", "Block Notifier", ModuleCategory.MISC,
                    "Alerts when selected blocks appear in loaded chunks around you.");
        }

        @Override public void onEnable() { reset(); }

        @Override public void onWorldReset() { reset(); }

        private void reset() {
            scanner.invalidate();
            announced.clear();
        }

        @Override public void onTick() {
            if (blocks.map().isEmpty()) return;
            scanner.tick(mc, id -> blocks.contains(id), radius.i(), ClientModules.scansPerTick(), ClientModules.rescanMs(), -64, 320);
            sinceLast++;
            if (sinceLast < 10) return;
            sinceLast = 0;
            int sent = 0;
            for (BlockScanner.Hit hit : scanner.hits()) {
                long key = hit.pos.asLong();
                if (!announced.add(key)) continue;
                if (sent < 3) dev.ratman.phantom.util.FindLog.add("Block", dev.ratman.phantom.util.Blocks.displayName(hit.id), hit.pos);
                if (sent < 3 && chat.on()) {
                    Notifier.chat("Found " + dev.ratman.phantom.util.Blocks.displayName(hit.id) + " at X " + hit.pos.getX()
                            + " Y " + hit.pos.getY() + " Z " + hit.pos.getZ());
                }
                sent++;
            }
            if (sent > 3 && chat.on()) Notifier.chat("... and " + (sent - 3) + " more matching blocks.");
            if (sent > 0 && sound.on()) Notifier.sound(Notifier.SOUND_PING, 0.8f, 1.4f);
        }
    }

    // ================================================================== Chat Macro
    static final class ChatMacro extends Module {
        final Setting.Text message = text("message", "Message", "/home", 256);
        final Setting.Mode type = mode("type", "Send as", "Auto", "Auto", "Chat", "Command");

        ChatMacro() {
            super("chat_macro", "Chat Macro", ModuleCategory.MISC,
                    "Sends a chat message or command when switched on (bind a key), then turns itself off.");
        }

        @Override public void onEnable() {
            if (mc.getNetworkHandler() != null) {
                String m = message.get().trim();
                if (!m.isEmpty()) {
                    boolean command = type.is("Command") || (type.is("Auto") && m.startsWith("/"));
                    if (command) mc.getNetworkHandler().sendChatCommand(m.startsWith("/") ? m.substring(1) : m);
                    else mc.getNetworkHandler().sendChatMessage(m);
                }
            }
            mc.execute(() -> setEnabled(false));
        }
    }

    // ================================================================== Coordinate Snapper
    static final class CoordSnapper extends Module {
        final Setting.Mode output = mode("output", "Output", "Both", "Clipboard", "Chat", "Both");
        final Setting.Bool block = bool("block", "Block coordinates", true);

        CoordSnapper() {
            super("coord_snapper", "Coordinate Snapper", ModuleCategory.MISC,
                    "Copies / prints your current coordinates, then turns itself off.");
        }

        @Override public void onEnable() {
            ClientPlayerEntity p = mc.player;
            if (p != null) {
                String text = block.on()
                        ? p.getBlockX() + " " + p.getBlockY() + " " + p.getBlockZ()
                        : String.format(java.util.Locale.ROOT, "%.2f %.2f %.2f", p.getX(), p.getY(), p.getZ());
                if (!output.is("Chat")) Compat.clipboard(text);
                if (!output.is("Clipboard")) Notifier.chat("Coordinates: " + text + (output.is("Both") ? " (copied)" : ""));
            }
            mc.execute(() -> setEnabled(false));
        }
    }

    // ================================================================== Fast Use
    static final class FastUse extends Module {
        final Setting.Mode items = mode("items", "Items", "XP bottles", "XP bottles", "Throwables", "Both");
        final Setting.Num delay = num("delay", "Use every", 1.0, 1.0, 4.0, 1.0, " ticks");
        private int counter;

        FastUse() {
            super("fast_use", "Fast Use", ModuleCategory.MISC,
                    "Uses XP bottles and throwables faster while you hold the use key.");
        }

        private boolean matches(ItemStack s) {
            boolean xp = s.isOf(Items.EXPERIENCE_BOTTLE);
            boolean throwable = s.isOf(Items.SNOWBALL) || s.isOf(Items.EGG);
            if (items.is("XP bottles")) return xp;
            if (items.is("Throwables")) return throwable;
            return xp || throwable;
        }

        @Override public void onTick() {
            if (mc.currentScreen != null || mc.interactionManager == null) return;
            if (!mc.options.useKey.isPressed()) {
                counter = 0;
                return;
            }
            if (!matches(Inv.main())) return;
            counter++;
            if (counter % delay.i() == 0) {
                mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                mc.player.swingHand(Hand.MAIN_HAND);
            }
        }
    }

    // ================================================================== Legit Auto Tool
    static final class LegitAutoTool extends Module {
        final Setting.Bool swapBack = bool("swapback", "Swap back when done", true);
        final Setting.Bool preferSilk = bool("silk", "Avoid tools while holding sneak", false);
        private int previousSlot = -1;
        private int idle;

        LegitAutoTool() {
            super("legit_auto_tool", "Legit Auto Tool", ModuleCategory.MISC,
                    "Selects the fastest hotbar tool while you hold attack on a block.");
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (mc.currentScreen != null) return;
            boolean mining = mc.options.attackKey.isPressed() && mc.crosshairTarget instanceof BlockHitResult
                    && mc.crosshairTarget.getType() == net.minecraft.util.hit.HitResult.Type.BLOCK;
            if (mining && !(preferSilk.on() && p.isSneaking())) {
                idle = 0;
                BlockPos pos = ((BlockHitResult) mc.crosshairTarget).getBlockPos();
                BlockState state = mc.world.getBlockState(pos);
                int bestSlot = -1;
                float best = 1.0f;
                for (int i = 0; i < 9; i++) {
                    float speed = p.getInventory().getStack(i).getMiningSpeedMultiplier(state);
                    if (speed > best + 0.01f) {
                        best = speed;
                        bestSlot = i;
                    }
                }
                if (bestSlot >= 0 && bestSlot != Compat.selectedHotbar()) {
                    if (previousSlot < 0) previousSlot = Compat.selectedHotbar();
                    Compat.selectHotbar(bestSlot);
                }
            } else if (previousSlot >= 0) {
                idle++;
                if (idle > 4) {
                    if (swapBack.on()) Compat.selectHotbar(previousSlot);
                    previousSlot = -1;
                    idle = 0;
                }
            }
        }

        @Override public void onDisable() { previousSlot = -1; }
    }

    // ================================================================== Weather Notifier
    static final class WeatherNotifier extends Module {
        final Setting.Bool chat = bool("chat", "Chat message", true);
        final Setting.Bool sound = bool("sound", "Sound", true);
        private int last = -1;

        WeatherNotifier() {
            super("weather_notifier", "Weather Notifier", ModuleCategory.MISC,
                    "Tells you when the weather changes (clear / rain / thunder).");
        }

        @Override public void onEnable() { last = -1; }

        @Override public void onWorldReset() { last = -1; }

        @Override public void onTick() {
            int state = FeatureModules.serverWeatherState(mc.world);
            if (last != -1 && state != last) {
                String text = state == 2 ? "Thunderstorm started." : (state == 1 ? (last == 2 ? "Thunder stopped, still raining." : "It started raining.") : "Weather cleared.");
                if (chat.on()) Notifier.chat(text);
                if (sound.on()) Notifier.sound(Notifier.SOUND_PING, 0.7f, state == 0 ? 1.4f : 0.7f);
            }
            last = state;
        }
    }
}
