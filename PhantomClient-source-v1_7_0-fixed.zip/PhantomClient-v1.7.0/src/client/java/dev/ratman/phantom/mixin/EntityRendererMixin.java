package dev.ratman.phantom.mixin;

import dev.ratman.phantom.modules.FeatureModules;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Local nameplate visibility and text decoration. Does not touch packets or server-side names. */
@Mixin(EntityRenderer.class)
public abstract class EntityRendererMixin<T extends Entity> {
    @Inject(method = "hasLabel", at = @At("HEAD"), cancellable = true)
    private void phantom$forceSelectedNameplates(T entity, double squaredDistanceToCamera, CallbackInfoReturnable<Boolean> cir) {
        if (FeatureModules.shouldForceNametag(entity, squaredDistanceToCamera)) cir.setReturnValue(true);
    }

    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true)
    private void phantom$decorateLocalName(T entity, CallbackInfoReturnable<Text> cir) {
        Text decorated = FeatureModules.decorateName(entity, cir.getReturnValue());
        if (decorated != null) cir.setReturnValue(decorated);
    }
}
