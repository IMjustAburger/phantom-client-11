package dev.ratman.phantom.mixin;

import dev.ratman.phantom.modules.FeatureModules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Local visual overrides only: the integrated/remote server world is never changed. */
@Mixin(World.class)
public abstract class WorldMixin {
    @Inject(method = "getTimeOfDay", at = @At("RETURN"), cancellable = true)
    private void phantom$localTime(CallbackInfoReturnable<Long> cir) {
        World world = (World) (Object) this;
        if (world == MinecraftClient.getInstance().world) cir.setReturnValue(FeatureModules.localTimeOfDay(world, cir.getReturnValue()));
    }

    @Inject(method = "getRainGradient", at = @At("RETURN"), cancellable = true)
    private void phantom$localRain(float tickProgress, CallbackInfoReturnable<Float> cir) {
        World world = (World) (Object) this;
        if (world == MinecraftClient.getInstance().world) cir.setReturnValue(FeatureModules.localRain(world, cir.getReturnValueF()));
    }

    @Inject(method = "getThunderGradient", at = @At("RETURN"), cancellable = true)
    private void phantom$localThunder(float tickProgress, CallbackInfoReturnable<Float> cir) {
        World world = (World) (Object) this;
        if (world == MinecraftClient.getInstance().world) cir.setReturnValue(FeatureModules.localThunder(world, cir.getReturnValueF()));
    }

    @Inject(method = "isRaining", at = @At("RETURN"), cancellable = true)
    private void phantom$localIsRaining(CallbackInfoReturnable<Boolean> cir) {
        World world = (World) (Object) this;
        if (world == MinecraftClient.getInstance().world) cir.setReturnValue(FeatureModules.localIsRaining(world, cir.getReturnValue()));
    }

    @Inject(method = "isThundering", at = @At("RETURN"), cancellable = true)
    private void phantom$localIsThundering(CallbackInfoReturnable<Boolean> cir) {
        World world = (World) (Object) this;
        if (world == MinecraftClient.getInstance().world) cir.setReturnValue(FeatureModules.localIsThundering(world, cir.getReturnValue()));
    }
}
