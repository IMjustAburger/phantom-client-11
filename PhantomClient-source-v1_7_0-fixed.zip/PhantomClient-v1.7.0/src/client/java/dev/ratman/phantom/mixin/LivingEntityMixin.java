package dev.ratman.phantom.mixin;

import dev.ratman.phantom.modules.FeatureModules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Client-only local-player jump and swing timing hooks. */
@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    @Shadow private int jumpingCooldown;

    @Inject(method = "tickMovement", at = @At("HEAD"))
    private void phantom$removeLocalJumpCooldown(CallbackInfo ci) {
        if ((Object) this == MinecraftClient.getInstance().player && FeatureModules.noJumpDelayEnabled()) jumpingCooldown = 0;
    }

    @Inject(method = "getHandSwingDuration", at = @At("RETURN"), cancellable = true)
    private void phantom$adjustLocalSwingDuration(CallbackInfoReturnable<Integer> cir) {
        if ((Object) this != MinecraftClient.getInstance().player || !FeatureModules.handPoseEnabled()) return;
        int original = cir.getReturnValueI();
        double speed = Math.max(0.25, Math.min(3.0, FeatureModules.handSwingSpeed()));
        cir.setReturnValue(Math.max(1, (int) Math.round(original / speed)));
    }
}
