package dev.ratman.phantom.modules;

import dev.ratman.phantom.module.Module;
import dev.ratman.phantom.module.ModuleCategory;
import dev.ratman.phantom.module.ModuleManager;
import dev.ratman.phantom.setting.Setting;
import dev.ratman.phantom.util.Compat;
import dev.ratman.phantom.util.Inv;
import dev.ratman.phantom.util.Notifier;
import dev.ratman.phantom.util.Rot;
import dev.ratman.phantom.util.Targets;
import net.minecraft.block.BlockState;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/** Combat category. All attack logic is client-side input; servers and anti-cheat may still react. */
public final class CombatModules {
    private CombatModules() {}

    public static void register() {
        ModuleManager.register(new AimAssist());
        ModuleManager.register(new KillAura());
        ModuleManager.register(new AutoClicker());
        ModuleManager.register(new AutoTotem());
        ModuleManager.register(new CrystalAura());
        ModuleManager.register(new CrystalMacro());
        ModuleManager.register(new AutoCity());
        ModuleManager.register(new AutoInventoryTotem());
        ModuleManager.register(new Mace());
        ModuleManager.register(new ShieldBreaker());
        ModuleManager.register(new JumpReset());
    }

    // ------------------------------------------------------------------ helpers
    static Vec3d aimPoint(LivingEntity e, String point) {
        if (point.equals("Head")) return new Vec3d(e.getX(), e.getEyeY() - 0.1, e.getZ());
        if (point.equals("Feet")) return new Vec3d(e.getX(), e.getY() + 0.2, e.getZ());
        return e.getBoundingBox().getCenter();
    }

    static boolean holdingWeapon(ItemStack s) {
        return s.isIn(ItemTags.SWORDS) || s.isIn(ItemTags.AXES) || s.isOf(Items.MACE) || s.isOf(Items.TRIDENT);
    }

    // ================================================================== Aim Assist
    static final class AimAssist extends Module {
        final Setting.Mode targets = mode("targets", "Targets", "Both", Targets.KINDS);
        final Setting.Bool passive = bool("passive", "Include passive mobs", false);
        final Setting.Num range = num("range", "Range", 5.0, 2.0, 10.0, 0.5, " blocks");
        final Setting.Num cone = num("cone", "Target cone", 60.0, 5.0, 180.0, 1.0, "\u00b0");
        final Setting.Num hSpeed = num("hspeed", "Horizontal speed", 45.0, 1.0, 100.0, 1.0, "%");
        final Setting.Num vSpeed = num("vspeed", "Vertical speed", 30.0, 1.0, 100.0, 1.0, "%");
        final Setting.Num strength = num("strength", "Strength", 60.0, 5.0, 100.0, 1.0, "%");
        final Setting.Num smoothing = num("smoothing", "Smoothing", 55.0, 0.0, 95.0, 1.0, "%");
        final Setting.Bool prediction = bool("prediction", "Predict movement", true);
        final Setting.Num predTicks = num("predticks", "Prediction time", 2.0, 0.5, 6.0, 0.5, " ticks");
        final Setting.Mode point = mode("point", "Aim point", "Chest", "Head", "Chest", "Feet");
        final Setting.Bool los = bool("los", "Require line of sight", true);
        final Setting.Bool onlyAttack = bool("onlyattack", "Only while attacking", false);
        final Setting.Bool weaponOnly = bool("weapon", "Only with a weapon", false);

        AimAssist() {
            super("aim_assist", "Aim Assist", ModuleCategory.COMBAT,
                    "Smoothly rotates the camera toward a nearby player or mob without snapping.");
            predTicks.visibleWhen(() -> prediction.on());
        }

        @Override public void onFrame(float dt) {
            ClientPlayerEntity p = mc.player;
            if (p == null || mc.currentScreen != null) return;
            if (onlyAttack.on() && !mc.options.attackKey.isPressed()) return;
            if (weaponOnly.on() && !holdingWeapon(p.getMainHandStack())) return;

            LivingEntity best = null;
            double bestAngle = cone.d() / 2.0;
            Vec3d eye = p.getEyePos();
            for (LivingEntity e : Targets.nearby(range.d(), targets.get(), passive.on())) {
                if (los.on() && !p.canSee(e)) continue;
                Vec3d pt = aimPoint(e, point.get());
                float[] a = Rot.anglesTo(eye, pt);
                double angle = Rot.angleBetween(p.getYaw(), p.getPitch(), a[0], a[1]);
                if (angle <= bestAngle) {
                    bestAngle = angle;
                    best = e;
                }
            }
            if (best == null) return;

            Vec3d target = aimPoint(best, point.get());
            if (prediction.on()) target = target.add(Targets.velocity(best).multiply(predTicks.d()));
            float[] want = Rot.anglesTo(eye, target);
            float dYaw = Rot.wrap(want[0] - p.getYaw());
            float dPitch = want[1] - p.getPitch();

            double k = Math.max(0.03, Math.min(0.9, (strength.d() / 100.0) * (1.0 - smoothing.d() / 100.0 * 0.85)));
            float blend = (float) (1.0 - Math.pow(1.0 - k, Math.max(0.0f, dt) * 20.0));
            float maxYaw = (float) (hSpeed.d() * 4.0 * dt);
            float maxPitch = (float) (vSpeed.d() * 4.0 * dt);
            float stepYaw = Math.max(-maxYaw, Math.min(maxYaw, dYaw * blend));
            float stepPitch = Math.max(-maxPitch, Math.min(maxPitch, dPitch * blend));
            p.setYaw(p.getYaw() + stepYaw);
            p.setPitch(Math.max(-90f, Math.min(90f, p.getPitch() + stepPitch)));
        }
    }

    // ================================================================== KillAura
    static final class KillAura extends Module {
        final Setting.Mode targets = mode("targets", "Targets", "Both", Targets.KINDS);
        final Setting.Bool passive = bool("passive", "Include passive mobs", false);
        final Setting.Num range = num("range", "Range", 4.0, 2.0, 6.0, 0.1, " blocks");
        final Setting.Num delay = num("delay", "Attack delay", 250.0, 50.0, 1000.0, 10.0, " ms");
        final Setting.Bool cooldown = bool("cooldown", "Respect attack cooldown", true);
        final Setting.Num angle = num("angle", "Target angle", 120.0, 20.0, 360.0, 5.0, "\u00b0");
        final Setting.Mode priority = mode("priority", "Priority", "Distance", "Distance", "Health", "Angle");
        final Setting.Mode rotate = mode("rotate", "Rotation", "Smooth", "Off", "Smooth");
        final Setting.Num rotSpeed = num("rotspeed", "Rotation speed", 40.0, 5.0, 100.0, 1.0, "%");
        final Setting.Num rotSmooth = num("rotsmooth", "Rotation smoothing", 50.0, 0.0, 95.0, 1.0, "%");
        final Setting.Bool los = bool("los", "Require line of sight", true);
        final Setting.Bool weaponOnly = bool("weapon", "Only with a weapon", false);
        final Setting.Bool autoWeapon = bool("autoweapon", "Switch to best weapon in hotbar", false);
        final Setting.Bool weaponBack = bool("weaponback", "Switch back after fighting", true);
        private long nextAttack;
        private LivingEntity current;
        private int weaponPrev = -1;
        private int weaponIdle;

        KillAura() {
            super("kill_aura", "KillAura", ModuleCategory.COMBAT,
                    "Attacks eligible players or mobs in range. Rotation is smooth and optional.");
        }

        private LivingEntity pick() {
            ClientPlayerEntity p = mc.player;
            LivingEntity best = null;
            double bestScore = Double.MAX_VALUE;
            Vec3d eye = p.getEyePos();
            for (LivingEntity e : Targets.nearby(range.d(), targets.get(), passive.on())) {
                if (los.on() && !p.canSee(e)) continue;
                double dist = eye.distanceTo(e.getEyePos());
                if (dist > range.d()) continue;
                float[] a = Rot.anglesTo(eye, aimPoint(e, "Chest"));
                double ang = Rot.angleBetween(p.getYaw(), p.getPitch(), a[0], a[1]);
                if (ang > angle.d() / 2.0) continue;
                double score;
                if (priority.is("Health")) score = e.getHealth() + dist * 0.01;
                else if (priority.is("Angle")) score = ang;
                else score = dist;
                if (score < bestScore) {
                    bestScore = score;
                    best = e;
                }
            }
            return best;
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            current = null;
            if (mc.currentScreen != null || mc.interactionManager == null) return;
            if (weaponOnly.on() && !holdingWeapon(p.getMainHandStack())) return;
            LivingEntity target = pick();
            current = target;
            if (target == null) {
                if (weaponPrev >= 0 && ++weaponIdle > 15) {
                    if (weaponBack.on()) Compat.selectHotbar(weaponPrev);
                    weaponPrev = -1;
                    weaponIdle = 0;
                }
                return;
            }
            weaponIdle = 0;
            if (autoWeapon.on() && !holdingWeapon(p.getMainHandStack())) {
                int slot = Inv.findHotbar(s -> s.isIn(ItemTags.SWORDS));
                if (slot < 0) slot = Inv.findHotbar(s -> s.isIn(ItemTags.AXES));
                if (slot >= 0) {
                    if (weaponPrev < 0) weaponPrev = Compat.selectedHotbar();
                    Compat.selectHotbar(slot);
                }
            }
            long now = System.currentTimeMillis();
            if (now < nextAttack) return;
            if (cooldown.on() && p.getAttackCooldownProgress(0.5f) < 0.95f) return;
            if (rotate.is("Smooth")) {
                float[] a = Rot.anglesTo(p.getEyePos(), aimPoint(target, "Chest"));
                if (Rot.angleBetween(p.getYaw(), p.getPitch(), a[0], a[1]) > 12.0) return; // still turning
            }
            mc.interactionManager.attackEntity(p, target);
            p.swingHand(Hand.MAIN_HAND);
            nextAttack = now + Math.round(delay.d());
        }

        @Override public void onFrame(float dt) {
            ClientPlayerEntity p = mc.player;
            if (p == null || current == null || !rotate.is("Smooth") || mc.currentScreen != null) return;
            float[] want = Rot.anglesTo(p.getEyePos(), aimPoint(current, "Chest"));
            double k = Math.max(0.03, Math.min(0.9, (rotSpeed.d() / 100.0) * (1.0 - rotSmooth.d() / 100.0 * 0.85)));
            float blend = (float) (1.0 - Math.pow(1.0 - k, Math.max(0.0f, dt) * 20.0));
            float maxStep = (float) (rotSpeed.d() * 6.0 * dt);
            float dy = Rot.wrap(want[0] - p.getYaw());
            float dp = want[1] - p.getPitch();
            p.setYaw(p.getYaw() + Math.max(-maxStep, Math.min(maxStep, dy * blend)));
            p.setPitch(Math.max(-90f, Math.min(90f, p.getPitch() + Math.max(-maxStep, Math.min(maxStep, dp * blend)))));
        }

        @Override public void onDisable() { current = null; }

        @Override public String info() { return priority.get(); }
    }

    // ================================================================== Auto Clicker
    static final class AutoClicker extends Module {
        final Setting.Mode mode = mode("mode", "Activation", "Hold", "Hold", "Always");
        final Setting.Num minCps = num("mincps", "Min CPS", 8.0, 1.0, 20.0, 1.0);
        final Setting.Num maxCps = num("maxcps", "Max CPS", 12.0, 1.0, 20.0, 1.0);
        final Setting.Mode targets = mode("targets", "Targets", "Both", Targets.KINDS);
        final Setting.Bool passive = bool("passive", "Include passive mobs", true);
        final Setting.Bool cooldown = bool("cooldown", "Respect attack cooldown", true);
        final Setting.Num range = num("range", "Range", 3.5, 2.0, 6.0, 0.1, " blocks");
        private long nextClick;

        AutoClicker() {
            super("auto_clicker", "Auto Clicker", ModuleCategory.COMBAT,
                    "Attacks the entity under your crosshair at a randomised click rate.");
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (mc.currentScreen != null || mc.interactionManager == null) return;
            if (mode.is("Hold") && !mc.options.attackKey.isPressed()) return;
            long now = System.currentTimeMillis();
            if (now < nextClick) return;
            if (cooldown.on() && p.getAttackCooldownProgress(0.0f) < 1.0f) return;
            if (!(mc.crosshairTarget instanceof EntityHitResult)) return;
            Entity hit = ((EntityHitResult) mc.crosshairTarget).getEntity();
            if (!(hit instanceof LivingEntity)) return;
            LivingEntity target = (LivingEntity) hit;
            if (!Targets.valid(target, targets.get(), passive.on())) return;
            if (p.getEyePos().distanceTo(target.getEyePos()) > range.d()) return;
            mc.interactionManager.attackEntity(p, target);
            p.swingHand(Hand.MAIN_HAND);
            double lo = Math.min(minCps.d(), maxCps.d());
            double hi = Math.max(minCps.d(), maxCps.d());
            double cps = lo + Math.random() * (hi - lo);
            nextClick = now + Math.max(50L, Math.round(1000.0 / cps));
        }
    }

    // ================================================================== Auto Totem
    static final class AutoTotem extends Module {
        final Setting.Num health = num("health", "Activate at or below", 20.0, 1.0, 20.0, 0.5, " HP");
        final Setting.Num delay = num("delay", "Delay", 1.0, 0.0, 10.0, 1.0, " ticks");
        final Setting.Bool hotbar = bool("hotbar", "Keep a spare totem in hotbar", false);
        final Setting.Mode safeItem = mode("safeitem", "Offhand when healthy", "Totem", "Totem", "Golden Apple", "Shield", "End Crystal", "Nothing");
        final Setting.Bool warnLow = bool("warn", "Warn when totems are running out", true);
        final Setting.Num warnAt = num("warnat", "Warn at this many totems", 2.0, 1.0, 10.0, 1.0);
        private int wait;
        private boolean warned;

        AutoTotem() {
            super("auto_totem", "Auto Totem", ModuleCategory.COMBAT,
                    "Keeps a Totem of Undying in your offhand.");
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (!Inv.canClick()) return;
            if (wait > 0) {
                wait--;
                return;
            }
            if (warnLow.on()) {
                int total = 0;
                for (int i = 0; i < 36; i++) if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) total++;
                if (Inv.offhand().isOf(Items.TOTEM_OF_UNDYING)) total++;
                if (total <= warnAt.i() && !warned) {
                    warned = true;
                    Notifier.chat("Only " + total + " totem" + (total == 1 ? "" : "s") + " left.");
                    Notifier.sound(Notifier.SOUND_WARN, 0.8f, 1.1f);
                } else if (total > warnAt.i()) {
                    warned = false;
                }
            }
            boolean danger = p.getHealth() + p.getAbsorptionAmount() <= health.d();
            if (danger) {
                if (!Inv.offhand().isOf(Items.TOTEM_OF_UNDYING)) {
                    int idx = Inv.find(s -> s.isOf(Items.TOTEM_OF_UNDYING));
                    if (idx >= 0) {
                        Inv.swapToOffhand(idx);
                        wait = delay.i();
                    }
                }
                return;
            }
            Item safe = null;
            if (safeItem.is("Golden Apple")) safe = Items.GOLDEN_APPLE;
            else if (safeItem.is("Shield")) safe = Items.SHIELD;
            else if (safeItem.is("End Crystal")) safe = Items.END_CRYSTAL;
            else if (safeItem.is("Totem")) safe = Items.TOTEM_OF_UNDYING;
            if (safe == null || Inv.offhand().isOf(safe)) return;
            final Item want = safe;
            int idx2 = Inv.find(s -> s.isOf(want));
            if (idx2 >= 0) {
                Inv.swapToOffhand(idx2);
                wait = delay.i();
            }
        }
    }

    // ================================================================== Auto Inventory Totem
    static final class AutoInventoryTotem extends Module {
        final Setting.Bool offhand = bool("offhand", "Fill offhand", true);
        final Setting.Bool hotbar = bool("hotbar", "Fill a hotbar slot", true);
        final Setting.Num slot = num("slot", "Hotbar slot", 9.0, 1.0, 9.0, 1.0);
        final Setting.Num delay = num("delay", "Delay", 2.0, 0.0, 10.0, 1.0, " ticks");
        private int wait;

        AutoInventoryTotem() {
            super("auto_inventory_totem", "Auto Inventory Totem", ModuleCategory.COMBAT,
                    "While your inventory is open, moves totems to your offhand and a hotbar slot.");
        }

        @Override public void onTick() {
            if (!(mc.currentScreen instanceof InventoryScreen) || !Inv.canClick()) return;
            if (wait > 0) {
                wait--;
                return;
            }
            if (offhand.on() && !Inv.offhand().isOf(Items.TOTEM_OF_UNDYING)) {
                int idx = Inv.find(s -> s.isOf(Items.TOTEM_OF_UNDYING));
                if (idx >= 0) {
                    Inv.swapToOffhand(idx);
                    wait = delay.i();
                    return;
                }
            }
            if (hotbar.on()) {
                int target = slot.i() - 1;
                ItemStack there = mc.player.getInventory().getStack(target);
                if (!there.isOf(Items.TOTEM_OF_UNDYING)) {
                    int idx = -1;
                    for (int i = 9; i < 36; i++) {
                        if (mc.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                            idx = i;
                            break;
                        }
                    }
                    if (idx >= 0) {
                        Inv.swapToHotbar(idx, target);
                        wait = delay.i();
                    }
                }
            }
        }
    }

    // ================================================================== Crystal helpers
    static float crystalDamage(Vec3d crystal, LivingEntity e) {
        double dist = Math.sqrt(e.squaredDistanceTo(crystal)) / 12.0;
        if (dist > 1.0) return 0f;
        double impact = 1.0 - dist; // exposure and armour are NOT modelled: this is an upper-bound estimate
        return (float) ((impact * impact + impact) / 2.0 * 7.0 * 12.0 + 1.0);
    }

    static boolean obsidianLike(BlockState s) {
        return s.isOf(net.minecraft.block.Blocks.OBSIDIAN) || s.isOf(net.minecraft.block.Blocks.BEDROCK);
    }

    // ================================================================== Crystal Aura
    static final class CrystalAura extends Module {
        final Setting.Bool place = bool("place", "Place crystals", true);
        final Setting.Bool breakC = bool("break", "Break crystals", true);
        final Setting.Num targetRange = num("targetrange", "Target range", 10.0, 4.0, 14.0, 0.5, " blocks");
        final Setting.Num placeRange = num("placerange", "Place range", 4.5, 2.0, 6.0, 0.1, " blocks");
        final Setting.Num breakRange = num("breakrange", "Break range", 4.5, 2.0, 6.0, 0.1, " blocks");
        final Setting.Num minDamage = num("mindamage", "Min target damage", 6.0, 1.0, 36.0, 0.5);
        final Setting.Num maxSelf = num("maxself", "Max self damage", 6.0, 0.0, 36.0, 0.5);
        final Setting.Num placeDelay = num("placedelay", "Place delay", 100.0, 0.0, 500.0, 10.0, " ms");
        final Setting.Num breakDelay = num("breakdelay", "Break delay", 60.0, 0.0, 500.0, 10.0, " ms");
        final Setting.Bool autoSwap = bool("autoswap", "Auto-swap to crystals", true);
        final Setting.Bool antiSuicide = bool("antisuicide", "Anti suicide", true);
        private long nextPlace;
        private long nextBreak;
        private final Map<BlockPos, Long> placed = new HashMap<BlockPos, Long>();

        CrystalAura() {
            super("crystal_aura", "Crystal Aura", ModuleCategory.COMBAT,
                    "Places and breaks end crystals near enemy players. Damage is an estimate (no armour/exposure).");
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (mc.currentScreen != null || mc.interactionManager == null) return;
            long now = System.currentTimeMillis();
            Iterator<Map.Entry<BlockPos, Long>> it = placed.entrySet().iterator();
            while (it.hasNext()) if (now - it.next().getValue() > 3000L) it.remove();

            List<LivingEntity> enemies = Targets.nearby(targetRange.d(), "Players", false);
            float myHp = p.getHealth() + p.getAbsorptionAmount();

            if (breakC.on() && now >= nextBreak) {
                EndCrystalEntity bestCrystal = null;
                float bestScore = -1f;
                for (Entity e : mc.world.getEntities()) {
                    if (!(e instanceof EndCrystalEntity)) continue;
                    if (p.getEyePos().distanceTo(Compat.pos(e)) > breakRange.d()) continue;
                    Vec3d at = Compat.pos(e);
                    float self = crystalDamage(at, p);
                    if (antiSuicide.on() && self >= myHp - 2f) continue;
                    if (self > maxSelf.d()) continue;
                    float best = 0f;
                    for (LivingEntity en : enemies) best = Math.max(best, crystalDamage(at, en));
                    boolean ours = placed.containsKey(e.getBlockPos().down());
                    if (best >= minDamage.d() || ours) {
                        float score = best + (ours ? 2f : 0f);
                        if (score > bestScore) {
                            bestScore = score;
                            bestCrystal = (EndCrystalEntity) e;
                        }
                    }
                }
                if (bestCrystal != null) {
                    mc.interactionManager.attackEntity(p, bestCrystal);
                    p.swingHand(Hand.MAIN_HAND);
                    nextBreak = now + Math.round(breakDelay.d());
                    return;
                }
            }

            if (place.on() && now >= nextPlace && !enemies.isEmpty()) {
                Hand hand = null;
                if (Inv.offhand().isOf(Items.END_CRYSTAL)) hand = Hand.OFF_HAND;
                else if (Inv.main().isOf(Items.END_CRYSTAL)) hand = Hand.MAIN_HAND;
                else if (autoSwap.on()) {
                    int slot = Inv.findHotbar(s -> s.isOf(Items.END_CRYSTAL));
                    if (slot >= 0) {
                        Compat.selectHotbar(slot);
                        hand = Hand.MAIN_HAND;
                    }
                }
                if (hand == null) return;

                BlockPos bestPos = null;
                float bestScore = -999f;
                for (LivingEntity en : enemies) {
                    BlockPos base = en.getBlockPos();
                    for (int dx = -4; dx <= 4; dx++) {
                        for (int dz = -4; dz <= 4; dz++) {
                            for (int dy = -3; dy <= 1; dy++) {
                                BlockPos pos = base.add(dx, dy, dz);
                                if (!obsidianLike(mc.world.getBlockState(pos))) continue;
                                if (!mc.world.getBlockState(pos.up()).isAir() || !mc.world.getBlockState(pos.up(2)).isAir()) continue;
                                Vec3d at = new Vec3d(pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5);
                                if (p.getEyePos().distanceTo(at) > placeRange.d()) continue;
                                if (!mc.world.getOtherEntities(null, new Box(pos.up())).isEmpty()) continue;
                                float dmg = crystalDamage(at, en);
                                float self = crystalDamage(at, p);
                                if (dmg < minDamage.d() || self > maxSelf.d()) continue;
                                if (antiSuicide.on() && self >= myHp - 2f) continue;
                                float score = dmg - self * 0.5f;
                                if (score > bestScore) {
                                    bestScore = score;
                                    bestPos = pos;
                                }
                            }
                        }
                    }
                }
                if (bestPos != null) {
                    BlockHitResult hit = new BlockHitResult(
                            new Vec3d(bestPos.getX() + 0.5, bestPos.getY() + 1.0, bestPos.getZ() + 0.5),
                            Direction.UP, bestPos, false);
                    mc.interactionManager.interactBlock(p, hand, hit);
                    p.swingHand(hand);
                    placed.put(bestPos, now);
                    nextPlace = now + Math.round(placeDelay.d());
                }
            }
        }

        @Override public void onDisable() { placed.clear(); }
    }

    // ================================================================== Crystal Macro
    static final class CrystalMacro extends Module {
        final Setting.Num placeDelay = num("placedelay", "Place delay", 90.0, 0.0, 400.0, 10.0, " ms");
        final Setting.Num breakDelay = num("breakdelay", "Break delay", 60.0, 0.0, 400.0, 10.0, " ms");
        final Setting.Bool hit = bool("hit", "Hit crystal under crosshair", true);
        final Setting.Bool swap = bool("swap", "Swap to crystals while placing", true);
        private long nextPlace;
        private long nextBreak;

        CrystalMacro() {
            super("crystal_macro", "Crystal Macro", ModuleCategory.COMBAT,
                    "Hold use on obsidian/bedrock to place crystals quickly; hits crystals you look at.");
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (mc.currentScreen != null || mc.interactionManager == null) return;
            long now = System.currentTimeMillis();
            HitResult hr = mc.crosshairTarget;
            if (hit.on() && hr instanceof EntityHitResult && now >= nextBreak) {
                Entity e = ((EntityHitResult) hr).getEntity();
                if (e instanceof EndCrystalEntity) {
                    mc.interactionManager.attackEntity(p, e);
                    p.swingHand(Hand.MAIN_HAND);
                    nextBreak = now + Math.round(breakDelay.d());
                    return;
                }
            }
            if (!mc.options.useKey.isPressed() || now < nextPlace || !(hr instanceof BlockHitResult)) return;
            BlockHitResult bhr = (BlockHitResult) hr;
            BlockPos pos = bhr.getBlockPos();
            if (bhr.getSide() != Direction.UP || !obsidianLike(mc.world.getBlockState(pos))) return;
            if (!mc.world.getBlockState(pos.up()).isAir() || !mc.world.getBlockState(pos.up(2)).isAir()) return;
            if (!mc.world.getOtherEntities(null, new Box(pos.up())).isEmpty()) return;
            Hand hand = null;
            if (Inv.offhand().isOf(Items.END_CRYSTAL)) hand = Hand.OFF_HAND;
            else if (Inv.main().isOf(Items.END_CRYSTAL)) hand = Hand.MAIN_HAND;
            else if (swap.on()) {
                int slot = Inv.findHotbar(s -> s.isOf(Items.END_CRYSTAL));
                if (slot >= 0) {
                    Compat.selectHotbar(slot);
                    hand = Hand.MAIN_HAND;
                }
            }
            if (hand == null) return;
            mc.interactionManager.interactBlock(p, hand, bhr);
            p.swingHand(hand);
            nextPlace = now + Math.round(placeDelay.d());
        }
    }

    // ================================================================== Auto City
    static final class AutoCity extends Module {
        final Setting.Num range = num("range", "Target range", 6.0, 3.0, 8.0, 0.5, " blocks");
        final Setting.Num reach = num("reach", "Mining reach", 4.5, 3.0, 5.5, 0.1, " blocks");
        final Setting.Bool swapPick = bool("swap", "Auto-select pickaxe", true);
        final Setting.Bool disableDone = bool("disable", "Disable when block breaks", true);
        private BlockPos mining;

        AutoCity() {
            super("auto_city", "Auto City", ModuleCategory.COMBAT,
                    "Mines a block next to an enemy player's feet (breaks 'city' blocks of holes).");
        }

        private BlockPos choose(LivingEntity target) {
            BlockPos feet = target.getBlockPos();
            BlockPos best = null;
            double bestScore = -1;
            for (Direction d : Direction.Type.HORIZONTAL) {
                BlockPos pos = feet.offset(d);
                BlockState s = mc.world.getBlockState(pos);
                if (s.isAir() || s.getHardness(mc.world, pos) < 0) continue;
                if (mc.player.getEyePos().distanceTo(Vec3d.ofCenter(pos)) > reach.d()) continue;
                double score = s.isOf(net.minecraft.block.Blocks.OBSIDIAN) ? 2 : 1;
                if (score > bestScore) {
                    bestScore = score;
                    best = pos;
                }
            }
            return best;
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (mc.currentScreen != null || mc.interactionManager == null) return;
            if (mining != null && mc.world.getBlockState(mining).isAir()) {
                Notifier.chat("Auto City: block at " + mining.getX() + " " + mining.getY() + " " + mining.getZ() + " broken.");
                mining = null;
                if (disableDone.on()) {
                    setEnabled(false);
                    return;
                }
            }
            if (mining == null) {
                LivingEntity best = null;
                double bestDist = Double.MAX_VALUE;
                for (LivingEntity e : Targets.nearby(range.d(), "Players", false)) {
                    double d = p.squaredDistanceTo(e);
                    if (d < bestDist) {
                        bestDist = d;
                        best = e;
                    }
                }
                if (best == null) return;
                mining = choose(best);
                if (mining == null) return;
            }
            if (swapPick.on()) {
                int slot = Inv.findHotbar(s -> s.isIn(ItemTags.PICKAXES));
                if (slot >= 0 && slot != Compat.selectedHotbar()) Compat.selectHotbar(slot);
            }
            mc.interactionManager.updateBlockBreakingProgress(mining, Direction.UP);
            p.swingHand(Hand.MAIN_HAND);
        }

        @Override public void onDisable() {
            mining = null;
            if (mc.interactionManager != null) mc.interactionManager.cancelBlockBreaking();
        }
    }

    // ================================================================== Mace
    static final class Mace extends Module {
        final Setting.Num minFall = num("minfall", "Min fall distance", 3.0, 1.0, 20.0, 0.5, " blocks");
        final Setting.Num range = num("range", "Range", 4.0, 2.0, 6.0, 0.1, " blocks");
        final Setting.Mode targets = mode("targets", "Targets", "Players", Targets.KINDS);
        final Setting.Bool autoAttack = bool("attack", "Auto attack", true);
        final Setting.Bool swapBack = bool("swapback", "Swap back after landing", true);
        private int previousSlot = -1;

        Mace() {
            super("mace", "Mace", ModuleCategory.COMBAT,
                    "Swaps to a mace while falling toward a target and optionally smashes it.");
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (mc.currentScreen != null || mc.interactionManager == null) return;
            double fall = p.fallDistance;
            if (p.isOnGround() || fall < 0.1) {
                if (previousSlot >= 0 && swapBack.on()) Compat.selectHotbar(previousSlot);
                previousSlot = -1;
                return;
            }
            if (fall < minFall.d()) return;
            LivingEntity target = null;
            double bestDist = Double.MAX_VALUE;
            for (LivingEntity e : Targets.nearby(range.d(), targets.get(), false)) {
                double d = p.squaredDistanceTo(e);
                if (d < bestDist) {
                    bestDist = d;
                    target = e;
                }
            }
            if (target == null) return;
            if (!Inv.main().isOf(Items.MACE)) {
                int slot = Inv.findHotbar(s -> s.isOf(Items.MACE));
                if (slot < 0) return;
                if (previousSlot < 0) previousSlot = Compat.selectedHotbar();
                Compat.selectHotbar(slot);
            }
            if (autoAttack.on() && p.getAttackCooldownProgress(0.0f) >= 1.0f) {
                mc.interactionManager.attackEntity(p, target);
                p.swingHand(Hand.MAIN_HAND);
            }
        }

        @Override public void onDisable() {
            if (previousSlot >= 0) Compat.selectHotbar(previousSlot);
            previousSlot = -1;
        }
    }

    // ================================================================== Shield Breaker
    static final class ShieldBreaker extends Module {
        final Setting.Bool swapBack = bool("swapback", "Swap back afterwards", true);
        final Setting.Bool attackAssist = bool("hit", "Attack while shield is up", false);
        private int previousSlot = -1;

        ShieldBreaker() {
            super("shield_breaker", "Shield Breaker", ModuleCategory.COMBAT,
                    "Switches to an axe when the player you are attacking is blocking with a shield.");
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (mc.currentScreen != null) return;
            Entity looked = mc.crosshairTarget instanceof EntityHitResult ? ((EntityHitResult) mc.crosshairTarget).getEntity() : null;
            boolean blocking = looked instanceof PlayerEntity && ((PlayerEntity) looked).isBlocking()
                    && !Targets.isFriend(looked);
            if (blocking && (mc.options.attackKey.isPressed() || attackAssist.on())) {
                if (!Inv.main().isIn(ItemTags.AXES)) {
                    int slot = Inv.findHotbar(s -> s.isIn(ItemTags.AXES));
                    if (slot >= 0) {
                        if (previousSlot < 0) previousSlot = Compat.selectedHotbar();
                        Compat.selectHotbar(slot);
                    }
                }
                if (attackAssist.on() && Inv.main().isIn(ItemTags.AXES) && p.getAttackCooldownProgress(0.0f) >= 1.0f
                        && mc.interactionManager != null) {
                    mc.interactionManager.attackEntity(p, looked);
                    p.swingHand(Hand.MAIN_HAND);
                }
            } else if (previousSlot >= 0 && !blocking) {
                if (swapBack.on()) Compat.selectHotbar(previousSlot);
                previousSlot = -1;
            }
        }

        @Override public void onDisable() { previousSlot = -1; }
    }

    // ================================================================== Jump Reset
    static final class JumpReset extends Module {
        final Setting.Num chance = num("chance", "Chance", 100.0, 10.0, 100.0, 5.0, "%");
        private boolean holding;

        JumpReset() {
            super("jump_reset", "Jump Reset", ModuleCategory.COMBAT,
                    "Jumps the moment you take damage on the ground to reduce knockback.");
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (holding) {
                holding = false;
                mc.options.jumpKey.setPressed(false);
                return;
            }
            if (mc.currentScreen != null) return;
            if (p.hurtTime == 9 && p.isOnGround() && Math.random() * 100.0 < chance.d()) {
                mc.options.jumpKey.setPressed(true);
                holding = true;
            }
        }

        @Override public void onDisable() {
            if (holding) mc.options.jumpKey.setPressed(false);
            holding = false;
        }
    }
}
