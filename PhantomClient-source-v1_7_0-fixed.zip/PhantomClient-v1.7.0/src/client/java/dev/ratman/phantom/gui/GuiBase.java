package dev.ratman.phantom.gui;

import dev.ratman.phantom.config.ConfigStore;
import dev.ratman.phantom.util.Draw;
import dev.ratman.phantom.util.Theme;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/**
 * Immediate-mode GUI toolkit: widgets register hit regions while drawing, and input is dispatched to
 * the topmost region under the mouse (respecting scissor clips). Used by the ClickGUI and the block
 * picker so both share the same look, animations and colour picker.
 */
public abstract class GuiBase extends Screen {
    protected interface Drag { void to(double mx, double my); }

    protected static final class Hit {
        int x, y, w, h;
        int[] clip;
        Runnable left, right, middle;
        Drag drag;
    }

    public static final class TextBox {
        public String text = "";
        public final int max;
        public String placeholder = "";

        public TextBox(int max) { this.max = max; }
    }

    protected final List<Hit> hits = new ArrayList<Hit>();
    private final List<int[]> clips = new ArrayList<int[]>();
    protected Hit dragging;
    protected TextBox focused;
    protected float dt = 0.016f;
    protected int mouseX;
    protected int mouseY;
    private long lastNanos = System.nanoTime();
    private final Map<Object, Float> anims = new HashMap<Object, Float>();
    private final Map<Object, float[]> hsbStates = new HashMap<Object, float[]>();
    private final Map<Object, Integer> hsbRgb = new HashMap<Object, Integer>();

    protected GuiBase(String title) { super(Text.literal(title)); }

    @Override public boolean shouldPause() { return false; }

    // ------------------------------------------------------------------ frame
    protected void beginFrame(int mx, int my) {
        long now = System.nanoTime();
        dt = Math.max(0.0005f, Math.min(0.1f, (now - lastNanos) / 1.0e9f));
        lastNanos = now;
        hits.clear();
        clips.clear();
        mouseX = mx;
        mouseY = my;
    }

    protected float anim(Object key, float target) {
        Float cur = anims.get(key);
        if (cur == null) cur = target;
        float k = 1f - (float) Math.exp(-dt * 16f * Theme.animSpeed);
        cur = cur + (target - cur) * k;
        if (Math.abs(cur - target) < 0.002f) cur = target;
        anims.put(key, cur);
        return cur;
    }

    /** Like {@link #anim} but starts from 0 the first time it is seen (for hover / open effects). */
    protected float animFromZero(Object key, float target) {
        if (!anims.containsKey(key)) anims.put(key, 0f);
        return anim(key, target);
    }

    // ------------------------------------------------------------------ clipping
    protected boolean pushClip(DrawContext c, int x, int y, int w, int h) {
        int x1 = x;
        int y1 = y;
        int x2 = x + w;
        int y2 = y + h;
        if (!clips.isEmpty()) {
            int[] t = clips.get(clips.size() - 1);
            x1 = Math.max(x1, t[0]);
            y1 = Math.max(y1, t[1]);
            x2 = Math.min(x2, t[2]);
            y2 = Math.min(y2, t[3]);
        }
        if (x2 <= x1 || y2 <= y1) return false;
        c.enableScissor(x1, y1, x2, y2);
        clips.add(new int[]{x1, y1, x2, y2});
        return true;
    }

    protected void popClip(DrawContext c) {
        c.disableScissor();
        clips.remove(clips.size() - 1);
    }

    protected boolean inClip(double mx, double my) {
        if (clips.isEmpty()) return true;
        int[] t = clips.get(clips.size() - 1);
        return mx >= t[0] && mx < t[2] && my >= t[1] && my < t[3];
    }

    protected boolean hovered(int x, int y, int w, int h) {
        return Draw.inside(mouseX, mouseY, x, y, w, h) && inClip(mouseX, mouseY);
    }

    // ------------------------------------------------------------------ hit regions
    protected Hit hit(int x, int y, int w, int h, Runnable left, Runnable right, Drag drag) {
        Hit hit = new Hit();
        hit.x = x;
        hit.y = y;
        hit.w = w;
        hit.h = h;
        hit.left = left;
        hit.right = right;
        hit.drag = drag;
        hit.clip = clips.isEmpty() ? null : clips.get(clips.size() - 1);
        hits.add(hit);
        return hit;
    }

    private static boolean contains(Hit h, double mx, double my) {
        if (mx < h.x || mx >= h.x + h.w || my < h.y || my >= h.y + h.h) return false;
        if (h.clip != null && (mx < h.clip[0] || mx >= h.clip[2] || my < h.clip[1] || my >= h.clip[3])) return false;
        return true;
    }

    /** Called before regions are searched; return true to swallow the click. */
    protected boolean preClick(double mx, double my, int button) { return false; }

    protected void onEnter(TextBox box) {}

    protected void onTextChanged(TextBox box) {}

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x();
        double my = click.y();
        int b = click.button();
        if (preClick(mx, my, b)) return true;
        focused = null;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!contains(h, mx, my)) continue;
            if (b == 0 && h.left != null) h.left.run();
            else if (b == 1 && h.right != null) h.right.run();
            if (b == 0 && h.drag != null) {
                dragging = h;
                h.drag.to(mx, my);
            }
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (dragging != null && dragging.drag != null) {
            dragging.drag.to(click.x(), click.y());
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        dragging = null;
        return super.mouseReleased(click);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (focused != null) {
            int key = input.key();
            if (key == GLFW.GLFW_KEY_BACKSPACE) {
                if (!focused.text.isEmpty()) {
                    focused.text = focused.text.substring(0, focused.text.length() - 1);
                    onTextChanged(focused);
                }
            } else if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
                TextBox f = focused;
                focused = null;
                onEnter(f);
            } else if (key == GLFW.GLFW_KEY_ESCAPE) {
                focused = null;
            } else if (input.hasCtrl() && key == GLFW.GLFW_KEY_V) {
                String clip = this.client.keyboard.getClipboard();
                if (clip != null) {
                    for (char ch : clip.toCharArray()) {
                        if (ch >= 32 && ch != 127 && focused.text.length() < focused.max) focused.text += ch;
                    }
                    onTextChanged(focused);
                }
            }
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (focused != null) {
            if (input.isValidChar() && focused.text.length() < focused.max) {
                focused.text += input.asString();
                onTextChanged(focused);
            }
            return true;
        }
        return super.charTyped(input);
    }

    // ------------------------------------------------------------------ widgets
    protected void card(DrawContext c, int x, int y, int w, int h) {
        Draw.rrect(c, x + 1, y + 2, w, h, Theme.cornerRadius, 0x55000000);
        Draw.rrectBorder(c, x, y, w, h, Theme.cornerRadius, Draw.alpha(Theme.PANEL, Theme.panelOpacity), Theme.BORDER);
    }

    protected void button(DrawContext c, int x, int y, int w, int h, String label, boolean active, int accent, Runnable onClick) {
        boolean hov = active && hovered(x, y, w, h);
        float a = animFromZero("btn" + x + ":" + y + ":" + label, hov ? 1f : 0f);
        int bg = Draw.lerp(Theme.ROW, Draw.mul(accent, 0.55f), a);
        Draw.rrectBorder(c, x, y, w, h, Math.max(1, Theme.cornerRadius - 1), bg, Draw.lerp(Theme.BORDER, accent, a));
        int tc = active ? Draw.lerp(Theme.MUTED, Theme.TEXT, Math.max(a, 0.4f)) : Theme.DIM;
        Draw.textCentered(c, this.textRenderer, label, x + w / 2, y + (h - 8) / 2, tc);
        if (active && onClick != null) hit(x, y, w, h, onClick, null, null);
    }

    protected void toggleSwitch(DrawContext c, int x, int y, boolean on, Object key) {
        float a = anim("sw" + key, on ? 1f : 0f);
        int track = Draw.lerp(0xFF2A1F40, Theme.accent(), a);
        Draw.rrect(c, x, y, 18, 9, 4, track);
        int kx = x + 1 + Math.round(a * 9);
        Draw.rrect(c, kx, y + 1, 7, 7, 3, Draw.lerp(Theme.MUTED, 0xFFFFFFFF, a));
    }

    /** Draws label, value and a draggable bar. Height used: 25. */
    protected void slider(DrawContext c, int x, int y, int w, String label, String valueText, double ratio, DoubleConsumer onRatio) {
        Draw.text(c, this.textRenderer, label, x, y + 1, Theme.TEXT);
        Draw.textRight(c, this.textRenderer, valueText, x + w, y + 1, Theme.MUTED);
        int by = y + 13;
        Draw.rrect(c, x, by, w, 5, 2, 0xFF1E1533);
        int fw = (int) Math.round(Math.max(0, Math.min(1, ratio)) * w);
        if (fw > 0) Draw.rrect(c, x, by, Math.max(3, fw), 5, 2, Theme.accent());
        int kx = x + fw - 2;
        c.fill(Math.max(x - 1, kx), by - 2, Math.max(x - 1, kx) + 4, by + 7, 0xFFFFFFFF);
        final int bx = x;
        final int bw = w;
        hit(x, y + 9, w, 16, null, null, new Drag() {
            @Override public void to(double mx, double my) {
                onRatio.accept(Math.max(0, Math.min(1, (mx - bx) / bw)));
            }
        });
    }

    /** Slimmer slider (label + 4px bar). Height used: 20. */
    protected void sliderCompact(DrawContext c, int x, int y, int w, String label, String valueText, double ratio, DoubleConsumer onRatio) {
        Draw.text(c, this.textRenderer, label, x, y, Theme.TEXT);
        Draw.textRight(c, this.textRenderer, valueText, x + w, y, Theme.MUTED);
        int by = y + 11;
        Draw.rrect(c, x, by, w, 4, 2, 0xFF1E1533);
        int fw = (int) Math.round(Math.max(0, Math.min(1, ratio)) * w);
        if (fw > 0) Draw.rrect(c, x, by, Math.max(3, fw), 4, 2, Theme.accent());
        int kx = Math.max(x - 1, x + fw - 2);
        c.fill(kx, by - 2, kx + 4, by + 6, 0xFFFFFFFF);
        final int bx = x;
        final int bw = w;
        hit(x, y + 7, w, 14, null, null, new Drag() {
            @Override public void to(double mx, double my) {
                onRatio.accept(Math.max(0, Math.min(1, (mx - bx) / bw)));
            }
        });
    }

    protected void textBox(DrawContext c, int x, int y, int w, int h, TextBox box) {
        boolean focus = focused == box;
        Draw.rrectBorder(c, x, y, w, h, Math.max(1, Theme.cornerRadius - 1), 0xFF0A0612, focus ? Theme.accent() : Theme.BORDER);
        String shown = box.text;
        int tx = x + 5;
        int max = w - 10;
        while (!shown.isEmpty() && this.textRenderer.getWidth(shown) > max) shown = shown.substring(1);
        if (shown.isEmpty() && !focus) {
            Draw.text(c, this.textRenderer, box.placeholder, tx, y + (h - 8) / 2, Theme.DIM);
        } else {
            Draw.text(c, this.textRenderer, shown, tx, y + (h - 8) / 2, Theme.TEXT);
            if (focus && (System.currentTimeMillis() / 500L) % 2L == 0L) {
                int cx = tx + this.textRenderer.getWidth(shown);
                c.fill(cx, y + 3, cx + 1, y + h - 3, Theme.accent());
            }
        }
        final TextBox b = box;
        hit(x, y, w, h, new Runnable() {
            @Override public void run() { focused = b; }
        }, null, null);
    }

    private float[] hsb(Object key, int rgb) {
        Integer last = hsbRgb.get(key);
        float[] st = hsbStates.get(key);
        if (st == null || last == null || last != (rgb & 0xFFFFFF)) {
            st = Draw.toHsb(rgb);
            hsbStates.put(key, st);
            hsbRgb.put(key, rgb & 0xFFFFFF);
        }
        return st;
    }

    /** HSB(+alpha) colour picker. Returns the height consumed. */
    protected int colorPicker(DrawContext c, int x, int y, int w, Object key, IntSupplier get, IntConsumer set, boolean alpha) {
        final int current = get.getAsInt();
        final float[] st = hsb(key, current);
        final int alphaByte = (current >>> 24) & 0xFF;
        int cy = y;
        // hue
        drawBar(c, x, cy, w, 0, st, alphaByte, key, get, set, alpha);
        cy += 12;
        drawBar(c, x, cy, w, 1, st, alphaByte, key, get, set, alpha);
        cy += 12;
        drawBar(c, x, cy, w, 2, st, alphaByte, key, get, set, alpha);
        cy += 12;
        if (alpha) {
            drawBar(c, x, cy, w, 3, st, alphaByte, key, get, set, alpha);
            cy += 12;
        }
        int shown = alpha ? current : (current | 0xFF000000);
        Draw.rrectBorder(c, x, cy, 22, 10, 2, shown, Theme.BORDER);
        String hex = alpha ? String.format("#%08X", current) : String.format("#%06X", current & 0xFFFFFF);
        Draw.text(c, this.textRenderer, hex, x + 28, cy + 1, Theme.MUTED);
        cy += 14;
        return cy - y;
    }

    private void drawBar(DrawContext c, int x, int y, int w, int kind, final float[] st, int alphaByte,
                         final Object key, final IntSupplier get, final IntConsumer set, final boolean alpha) {
        int h = 8;
        int step = 2;
        for (int i = 0; i < w; i += step) {
            float t = (float) i / (float) Math.max(1, w - 1);
            int col;
            if (kind == 0) col = Draw.hsb(t, 1f, 1f);
            else if (kind == 1) col = Draw.hsb(st[0], t, Math.max(0.35f, st[2]));
            else if (kind == 2) col = Draw.hsb(st[0], st[1], t);
            else col = Draw.setAlpha(Draw.hsb(st[0], st[1], st[2]), 255);
            if (kind == 3) col = Draw.lerp(0xFF120C1E, col, t);
            c.fill(x + i, y, Math.min(x + w, x + i + step), y + h, col | 0xFF000000);
        }
        float ratio = kind == 0 ? st[0] : (kind == 1 ? st[1] : (kind == 2 ? st[2] : alphaByte / 255f));
        int mx = x + Math.round(Math.max(0f, Math.min(1f, ratio)) * (w - 2));
        c.fill(mx - 1, y - 1, mx + 3, y + h + 1, 0xFFFFFFFF);
        c.fill(mx, y, mx + 2, y + h, 0xFF000000);
        final int bx = x;
        final int bw = w;
        final int k = kind;
        hit(x, y - 2, w, h + 4, null, null, new Drag() {
            @Override public void to(double mxx, double myy) {
                float r = (float) Math.max(0, Math.min(1, (mxx - bx) / (double) Math.max(1, bw - 2)));
                if (k == 0) st[0] = r;
                else if (k == 1) st[1] = r;
                else if (k == 2) st[2] = r;
                int rgb = Draw.hsb(st[0], st[1], st[2]) & 0xFFFFFF;
                int a = k == 3 ? Math.round(r * 255f) : ((get.getAsInt() >>> 24) & 0xFF);
                if (!alpha) a = 255;
                hsbRgb.put(key, rgb);
                set.accept((a << 24) | rgb);
                ConfigStore.markDirty();
            }
        });
    }
}
