package dev.ratman.phantom.modules;

import dev.ratman.phantom.module.Module;
import dev.ratman.phantom.module.ModuleCategory;
import dev.ratman.phantom.module.ModuleManager;
import dev.ratman.phantom.setting.Setting;
import dev.ratman.phantom.util.Compat;
import dev.ratman.phantom.util.Inv;
import dev.ratman.phantom.util.Notifier;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerAbilities;
import net.minecraft.entity.vehicle.AbstractBoatEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/** Movement category. Everything here changes client-side motion; servers may correct or reject it. */
public final class MovementModules {
    private MovementModules() {}

    public static void register() {
        ModuleManager.register(new Flight());
        ModuleManager.register(new Speed());
        ModuleManager.register(new Sprint());
        ModuleManager.register(new Spider());
        ModuleManager.register(new Jesus());
        ModuleManager.register(new AutoWalk());
        ModuleManager.register(new AutoJump());
        ModuleManager.register(new BoatFly());
        ModuleManager.register(new ClickTp());
        ModuleManager.register(new ElytraFly());
        ModuleManager.register(new ElytraSwap());
        ModuleManager.register(new EntitySpeed());
        ModuleManager.register(new TridentBoost());
    }

    // ------------------------------------------------------------------ helpers
    /** {forward, strafeLeft} from the movement keys, each in -1..1. */
    static double[] keys(GameOptions o) {
        double f = 0;
        double s = 0;
        if (o.forwardKey.isPressed()) f += 1;
        if (o.backKey.isPressed()) f -= 1;
        if (o.leftKey.isPressed()) s += 1;
        if (o.rightKey.isPressed()) s -= 1;
        return new double[]{f, s};
    }

    static boolean moving(GameOptions o) {
        double[] k = keys(o);
        return k[0] != 0 || k[1] != 0;
    }

    /** World-space horizontal direction (unit length) for key input at a yaw. */
    static Vec3d direction(double forward, double strafe, float yaw) {
        double len = Math.sqrt(forward * forward + strafe * strafe);
        if (len < 1.0E-6) return Vec3d.ZERO;
        double f = forward / len;
        double s = strafe / len;
        double rad = Math.toRadians(yaw);
        double sin = Math.sin(rad);
        double cos = Math.cos(rad);
        return new Vec3d(-f * sin + s * cos, 0, f * cos + s * sin);
    }

    // ================================================================== Flight
    static final class Flight extends Module {
        final Setting.Mode mode = mode("mode", "Mode", "Abilities", "Abilities", "Velocity");
        final Setting.Num speed = num("speed", "Speed", 1.0, 0.1, 10.0, 0.1, "x");
        final Setting.Num vertical = num("vspeed", "Vertical speed", 1.0, 0.1, 5.0, 0.1, "x");
        final Setting.Bool antiKick = bool("antikick", "Anti-kick bob", false);
        private boolean prevAllow;
        private boolean prevFlying;
        private float prevSpeed = 0.05f;
        private boolean captured;
        private int tick;

        Flight() {
            super("flight", "Flight", ModuleCategory.MOVEMENT,
                    "Fly with an adjustable speed. Works in creative/single-player; most servers forbid flight.");
            vertical.visibleWhen(() -> mode.is("Velocity"));
            antiKick.visibleWhen(() -> mode.is("Velocity"));
        }

        @Override public void onEnable() {
            captured = false;
            tick = 0;
        }

        private void capture(PlayerAbilities a) {
            if (captured) return;
            prevAllow = a.allowFlying;
            prevFlying = a.flying;
            prevSpeed = a.getFlySpeed();
            captured = true;
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            PlayerAbilities a = p.getAbilities();
            capture(a);
            if (mode.is("Abilities")) {
                a.allowFlying = true;
                a.flying = true;
                a.setFlySpeed(speed.f() * 0.05f);
                return;
            }
            // Velocity mode: restore real abilities, then drive motion directly.
            a.allowFlying = prevAllow;
            a.flying = prevFlying;
            double[] k = keys(mc.options);
            Vec3d horizontal = direction(k[0], k[1], p.getYaw()).multiply(speed.d() * 0.9);
            double y = 0;
            if (mc.options.jumpKey.isPressed()) y += vertical.d() * 0.6;
            if (mc.options.sneakKey.isPressed()) y -= vertical.d() * 0.6;
            tick++;
            if (antiKick.on() && y == 0 && tick % 20 == 0) y = -0.04;
            p.setVelocity(horizontal.x, y, horizontal.z);
            p.fallDistance = 0;
        }

        @Override public void onDisable() {
            ClientPlayerEntity p = mc.player;
            if (p == null || !captured) return;
            PlayerAbilities a = p.getAbilities();
            a.allowFlying = prevAllow || p.isCreative() || p.isSpectator();
            a.flying = (prevFlying || p.isSpectator()) && a.allowFlying;
            a.setFlySpeed(prevSpeed <= 0 ? 0.05f : prevSpeed);
            captured = false;
        }

        @Override public String info() { return mode.get(); }
    }

    // ================================================================== Speed
    static final class Speed extends Module {
        final Setting.Num speed = num("speed", "Speed", 0.35, 0.1, 2.0, 0.01, " b/t");
        final Setting.Bool groundOnly = bool("ground", "Only on ground", false);
        final Setting.Bool autoJump = bool("hop", "Bunny hop", false);

        Speed() {
            super("speed", "Speed", ModuleCategory.MOVEMENT, "Overrides horizontal movement speed.");
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (!moving(mc.options) || p.isSneaking() || p.hasVehicle()) return;
            if (groundOnly.on() && !p.isOnGround()) return;
            double[] k = keys(mc.options);
            Vec3d dir = direction(k[0], k[1], p.getYaw()).multiply(speed.d());
            Vec3d v = p.getVelocity();
            p.setVelocity(dir.x, v.y, dir.z);
            if (autoJump.on() && p.isOnGround()) p.setVelocity(dir.x, 0.42, dir.z);
        }
    }

    // ================================================================== Sprint
    static final class Sprint extends Module {
        final Setting.Mode mode = mode("mode", "Mode", "Legit", "Legit", "Omni");

        Sprint() {
            super("sprint", "Sprint", ModuleCategory.MOVEMENT, "Keeps sprint active while you move.");
            defaultOn = false;
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (mc.currentScreen != null || p.getHungerManager().getFoodLevel() <= 6 || p.isSneaking()) return;
            boolean forward = mc.options.forwardKey.isPressed();
            boolean any = moving(mc.options);
            if (mode.is("Omni") ? any : forward) p.setSprinting(true);
        }

        @Override public String info() { return mode.get(); }
    }

    // ================================================================== Spider
    static final class Spider extends Module {
        final Setting.Num climb = num("speed", "Climb speed", 0.2, 0.05, 0.6, 0.01, " b/t");

        Spider() {
            super("spider", "Spider", ModuleCategory.MOVEMENT, "Climb walls by moving into them.");
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (p.horizontalCollision && !p.isSneaking()) {
                Vec3d v = p.getVelocity();
                p.setVelocity(v.x, climb.d(), v.z);
            }
        }
    }

    // ================================================================== Jesus
    static final class Jesus extends Module {
        final Setting.Num lift = num("lift", "Float strength", 0.11, 0.03, 0.3, 0.01);

        Jesus() {
            super("jesus", "Jesus", ModuleCategory.MOVEMENT,
                    "Floats on water by pushing you upward (not solid water; servers may rubber-band).");
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (p.isSneaking() || mc.options.jumpKey.isPressed()) return;
            Vec3d v = p.getVelocity();
            if (p.isTouchingWater()) {
                p.setVelocity(v.x, Math.max(v.y, lift.d()), v.z);
            } else {
                BlockPos below = BlockPos.ofFloored(p.getX(), p.getY() - 0.05, p.getZ());
                boolean overWater = mc.world.getFluidState(below).isIn(FluidTags.WATER);
                if (overWater && v.y < 0) {
                    p.setVelocity(v.x, 0, v.z);
                    p.setOnGround(true);
                }
            }
        }
    }

    // ================================================================== Auto Walk
    static final class AutoWalk extends Module {
        final Setting.Bool sprint = bool("sprint", "Also sprint", false);

        AutoWalk() {
            super("auto_walk", "Auto Walk", ModuleCategory.MOVEMENT, "Holds the forward key for you.");
        }

        @Override public void onTick() {
            if (mc.currentScreen != null) return;
            mc.options.forwardKey.setPressed(true);
            if (sprint.on()) mc.player.setSprinting(true);
        }

        @Override public void onDisable() { KeyBinding.updatePressedStates(); }
    }

    // ================================================================== Auto Jump
    static final class AutoJump extends Module {
        final Setting.Bool onlyCollide = bool("collide", "Only when blocked", true);
        private boolean pressed;

        AutoJump() {
            super("auto_jump", "Auto Jump", ModuleCategory.MOVEMENT, "Jumps automatically while you move.");
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (mc.currentScreen != null) return;
            boolean should = moving(mc.options) && p.isOnGround() && (!onlyCollide.on() || p.horizontalCollision);
            if (should) {
                mc.options.jumpKey.setPressed(true);
                pressed = true;
            } else if (pressed) {
                KeyBinding.updatePressedStates();
                pressed = false;
            }
        }

        @Override public void onDisable() {
            if (pressed) KeyBinding.updatePressedStates();
            pressed = false;
        }
    }

    // ================================================================== Boat Fly
    static final class BoatFly extends Module {
        final Setting.Num speed = num("speed", "Speed", 1.2, 0.1, 5.0, 0.1, " b/t");
        final Setting.Num vertical = num("vspeed", "Vertical speed", 0.6, 0.1, 3.0, 0.1, " b/t");
        private Entity last;

        BoatFly() {
            super("boat_fly", "Boat Fly", ModuleCategory.MOVEMENT, "Fly while riding a boat.");
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            Entity v = p.getVehicle();
            if (!(v instanceof AbstractBoatEntity)) return;
            last = v;
            double[] k = keys(mc.options);
            Vec3d h = direction(k[0], k[1], p.getYaw()).multiply(speed.d());
            double y = 0;
            if (mc.options.jumpKey.isPressed()) y += vertical.d();
            if (mc.options.sneakKey.isPressed()) y -= vertical.d();
            v.setNoGravity(true);
            v.setVelocity(h.x, y, h.z);
        }

        @Override public void onDisable() {
            if (last != null) last.setNoGravity(false);
            last = null;
        }
    }

    // ================================================================== Click TP
    static final class ClickTp extends Module {
        final Setting.Num range = num("range", "Range", 60.0, 5.0, 150.0, 1.0, " blocks");
        private boolean wasDown;

        ClickTp() {
            super("click_tp", "Click TP", ModuleCategory.MOVEMENT,
                    "Middle-click a block to teleport to it. Client-side only: servers will usually rubber-band you.");
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            boolean down = mc.options.pickItemKey.isPressed();
            if (down && !wasDown && mc.currentScreen == null) {
                HitResult hr = p.raycast(range.d(), Compat.tickDelta(), false);
                if (hr instanceof BlockHitResult && hr.getType() == HitResult.Type.BLOCK) {
                    BlockHitResult b = (BlockHitResult) hr;
                    BlockPos pos = b.getBlockPos();
                    Direction side = b.getSide();
                    double x = pos.getX() + 0.5;
                    double y = pos.getY() + 1.0;
                    double z = pos.getZ() + 0.5;
                    if (side != Direction.UP) {
                        BlockPos adj = pos.offset(side);
                        x = adj.getX() + 0.5;
                        y = adj.getY();
                        z = adj.getZ() + 0.5;
                    }
                    p.setPosition(x, y, z);
                    p.setVelocity(Vec3d.ZERO);
                }
            }
            wasDown = down;
        }
    }

    // ================================================================== Elytra Fly
    static final class ElytraFly extends Module {
        final Setting.Num speed = num("speed", "Speed", 1.6, 0.3, 5.0, 0.1, " b/t");
        final Setting.Num vertical = num("vspeed", "Vertical speed", 0.6, 0.1, 2.0, 0.1, " b/t");
        final Setting.Bool hover = bool("hover", "Hover when idle", true);

        ElytraFly() {
            super("elytra_fly", "Elytra Fly", ModuleCategory.MOVEMENT,
                    "Controls your velocity while gliding with an elytra.");
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (!p.isGliding()) return;
            Vec3d look = p.getRotationVec(1.0f);
            Vec3d v = p.getVelocity();
            if (mc.options.forwardKey.isPressed()) {
                p.setVelocity(look.x * speed.d(), look.y * speed.d(), look.z * speed.d());
            } else {
                double y = v.y;
                if (mc.options.jumpKey.isPressed()) y = vertical.d();
                else if (mc.options.sneakKey.isPressed()) y = -vertical.d();
                else if (hover.on()) y = 0;
                p.setVelocity(hover.on() ? 0 : v.x, y, hover.on() ? 0 : v.z);
            }
        }
    }

    // ================================================================== Elytra Swap
    static final class ElytraSwap extends Module {
        ElytraSwap() {
            super("elytra_swap", "Elytra Swap", ModuleCategory.MOVEMENT,
                    "Swaps your chestplate and elytra, then turns itself off. Bind a key for one-press swapping.");
        }

        private static boolean isChestplate(ItemStack s) {
            return !s.isEmpty() && Registries.ITEM.getId(s.getItem()).getPath().endsWith("_chestplate");
        }

        @Override public void onEnable() {
            ClientPlayerEntity p = mc.player;
            if (p == null) {
                scheduleOff();
                return;
            }
            if (!Inv.canClick()) {
                Notifier.chat("Elytra Swap: close other containers first.");
                scheduleOff();
                return;
            }
            ItemStack chest = p.getEquippedStack(EquipmentSlot.CHEST);
            int idx = chest.isOf(Items.ELYTRA)
                    ? Inv.find(MovementModules::isChestplateStack)
                    : Inv.find(s -> s.isOf(Items.ELYTRA));
            if (idx < 0) {
                Notifier.chat(chest.isOf(Items.ELYTRA) ? "Elytra Swap: no chestplate in inventory." : "Elytra Swap: no elytra in inventory.");
            } else {
                Inv.click(Inv.slotId(idx), 0, SlotActionType.PICKUP);
                Inv.click(6, 0, SlotActionType.PICKUP);
                Inv.click(Inv.slotId(idx), 0, SlotActionType.PICKUP);
            }
            scheduleOff();
        }

        private void scheduleOff() {
            mc.execute(() -> setEnabled(false));
        }
    }

    static boolean isChestplateStack(ItemStack s) {
        return ElytraSwap.isChestplate(s);
    }

    // ================================================================== Entity Speed
    static final class EntitySpeed extends Module {
        final Setting.Num speed = num("speed", "Speed", 0.9, 0.1, 4.0, 0.05, " b/t");

        EntitySpeed() {
            super("entity_speed", "Entity Speed", ModuleCategory.MOVEMENT, "Sets the speed of the mount you are riding.");
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            Entity v = p.getVehicle();
            if (v == null || !moving(mc.options)) return;
            double[] k = keys(mc.options);
            Vec3d h = direction(k[0], k[1], p.getYaw()).multiply(speed.d());
            Vec3d old = v.getVelocity();
            v.setVelocity(h.x, old.y, h.z);
        }
    }

    // ================================================================== Trident Boost
    static final class TridentBoost extends Module {
        final Setting.Num boost = num("boost", "Boost", 1.6, 1.0, 4.0, 0.1, "x");
        private boolean wasRiptide;

        TridentBoost() {
            super("trident_boost", "Trident Boost", ModuleCategory.MOVEMENT, "Multiplies the launch of a riptide trident.");
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            boolean now = p.isUsingRiptide();
            if (now && !wasRiptide) p.setVelocity(p.getVelocity().multiply(boost.d()));
            wasRiptide = now;
        }
    }
}
