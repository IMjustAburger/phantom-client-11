package dev.ratman.phantom.gui;

import dev.ratman.phantom.config.ConfigStore;
import dev.ratman.phantom.setting.Setting;
import dev.ratman.phantom.util.Blocks;
import dev.ratman.phantom.util.Draw;
import dev.ratman.phantom.util.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Searchable block selector with per-block colours. Used by Block ESP, Storage ESP and Block Notifier.
 * Left: every available block (type to search). Right: the current selection with colour editing.
 */
public final class BlockPickerScreen extends GuiBase {
    private final Screen parent;
    private final Setting.Blocks setting;
    private final TextBox query = new TextBox(40);
    private final Map<String, String> names = new HashMap<String, String>();
    private List<String> filtered = new ArrayList<String>();
    private String lastQuery = null;
    private int scroll;
    private int selScroll;
    private String editing = null; // block id being recoloured; "" = default colour

    public BlockPickerScreen(Screen parent, Setting.Blocks setting) {
        super("Select blocks");
        this.parent = parent;
        this.setting = setting;
        query.placeholder = "Search blocks by name...";
    }

    private List<String> candidates() {
        return setting.candidates != null ? setting.candidates : Blocks.allIds();
    }

    private String nameOf(String id) {
        String n = names.get(id);
        if (n == null) {
            n = Blocks.displayName(id);
            names.put(id, n);
        }
        return n;
    }

    private void refilter() {
        String q = query.text.trim().toLowerCase(Locale.ROOT);
        if (q.equals(lastQuery)) return;
        lastQuery = q;
        filtered = new ArrayList<String>();
        String qUnderscore = q.replace(' ', '_');
        for (String id : candidates()) {
            if (q.isEmpty() || id.contains(qUnderscore) || nameOf(id).toLowerCase(Locale.ROOT).contains(q)) filtered.add(id);
        }
        scroll = 0;
    }

    @Override public void renderBackground(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        // drawn in render()
    }

    @Override public void close() { this.client.setScreen(parent); }

    @Override public void removed() { ConfigStore.flush(); }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        beginFrame(mx, my);
        refilter();
        c.fillGradient(0, 0, this.width, this.height, Draw.alpha(0xFF05030A, 0.82f), Draw.alpha(0xFF14082A, 0.92f));
        int w = Math.min(600, this.width - 20);
        int h = this.height - 40;
        int x = (this.width - w) / 2;
        int y = 14;
        card(c, x, y, w, h);
        hit(x, y, w, h, null, null, null);
        Draw.text(c, this.textRenderer, setting.label, x + 12, y + 9, Theme.TEXT);
        Draw.textRight(c, this.textRenderer, setting.map().size() + " selected", x + w - 12, y + 9, Theme.accent());

        int leftW = (w - 36) * 11 / 20;
        int lx = x + 12;
        textBox(c, lx, y + 26, leftW, 16, query);
        int listY = y + 48;
        int listH = h - 48 - 12;
        Draw.rrectBorder(c, lx, listY, leftW, listH, 3, 0xFF0A0612, Theme.BORDER);
        int rowH = 17;
        int rows = Math.max(1, (listH - 6) / rowH);
        scroll = Math.max(0, Math.min(Math.max(0, filtered.size() - rows), scroll));
        if (pushClip(c, lx + 1, listY + 1, leftW - 2, listH - 2)) {
            int yy = listY + 3;
            for (int i = scroll; i < filtered.size() && i < scroll + rows; i++) {
                final String id = filtered.get(i);
                boolean sel = setting.contains(id);
                boolean hov = hovered(lx + 3, yy, leftW - 6, rowH - 1);
                int bg = sel ? Draw.mul(Theme.accent(), 0.45f) : (hov ? Theme.ROW_HOVER : Theme.ROW);
                Draw.rrect(c, lx + 3, yy, leftW - 6, rowH - 1, 3, bg);
                Draw.rrectBorder(c, lx + 7, yy + 3, 9, 9, 2, sel ? Theme.accent() : 0xFF1A1229, Theme.BORDER);
                Draw.text(c, this.textRenderer, Draw.fit(this.textRenderer, nameOf(id), leftW - 80), lx + 21, yy + 4, sel ? 0xFFFFFFFF : Theme.TEXT);
                Draw.textRight(c, this.textRenderer, Draw.fit(this.textRenderer, id, 80), lx + leftW - 8, yy + 4, Theme.DIM);
                hit(lx + 3, yy, leftW - 6, rowH - 1, new Runnable() {
                    @Override public void run() {
                        setting.toggle(id);
                        ConfigStore.markDirty();
                        if (!setting.contains(id) && id.equals(editing)) editing = null;
                    }
                }, null, null);
                yy += rowH;
            }
            popClip(c);
        }
        if (filtered.isEmpty()) Draw.text(c, this.textRenderer, "No blocks match", lx + 10, listY + 8, Theme.DIM);
        Draw.text(c, this.textRenderer, filtered.size() + " blocks", lx + 2, listY + listH + 1, Theme.DIM);

        // right: selection
        int rx = lx + leftW + 12;
        int rw = x + w - 12 - rx;
        Draw.text(c, this.textRenderer, "Selected blocks", rx, y + 29, Theme.MUTED);
        int ry = y + 42;
        boolean defEdit = "".equals(editing);
        Draw.rrectBorder(c, rx, ry, rw, 16, 3, defEdit ? Draw.mul(Theme.accent(), 0.4f) : Theme.ROW, defEdit ? Theme.accent() : Theme.BORDER);
        Draw.text(c, this.textRenderer, "Default colour", rx + 6, ry + 4, Theme.TEXT);
        Draw.rrectBorder(c, rx + rw - 28, ry + 3, 22, 10, 2, setting.defaultColor | 0xFF000000, Theme.BORDER);
        hit(rx, ry, rw, 16, new Runnable() {
            @Override public void run() { editing = "".equals(editing) ? null : ""; }
        }, null, null);
        ry += 20;

        int pickerH = 0;
        if (editing != null) pickerH = 12 * 3 + 14 + 10;
        int listBottom = y + h - 12 - 18 - pickerH;
        List<String> selected = setting.ids();
        int sRows = Math.max(1, (listBottom - ry) / 17);
        selScroll = Math.max(0, Math.min(Math.max(0, selected.size() - sRows), selScroll));
        if (pushClip(c, rx - 1, ry, rw + 2, listBottom - ry)) {
            int yy = ry;
            for (int i = selScroll; i < selected.size() && i < selScroll + sRows; i++) {
                final String id = selected.get(i);
                boolean ed = id.equals(editing);
                Draw.rrectBorder(c, rx, yy, rw, 16, 3, ed ? Draw.mul(Theme.accent(), 0.4f) : Theme.ROW, ed ? Theme.accent() : Theme.BORDER);
                Draw.rrectBorder(c, rx + 5, yy + 4, 8, 8, 2, setting.colorOf(id) | 0xFF000000, Theme.BORDER);
                Draw.text(c, this.textRenderer, Draw.fit(this.textRenderer, nameOf(id), rw - 44), rx + 18, yy + 4, Theme.TEXT);
                Draw.textRight(c, this.textRenderer, "x", rx + rw - 7, yy + 4, Theme.BAD);
                hit(rx + rw - 18, yy, 18, 16, new Runnable() {
                    @Override public void run() {
                        setting.toggle(id);
                        ConfigStore.markDirty();
                        if (id.equals(editing)) editing = null;
                    }
                }, null, null);
                hit(rx, yy, rw - 18, 16, new Runnable() {
                    @Override public void run() { editing = id.equals(editing) ? null : id; }
                }, null, null);
                yy += 17;
            }
            popClip(c);
        }
        if (selected.isEmpty()) {
            Draw.text(c, this.textRenderer, setting.emptyMeansAll ? "Nothing selected: all are shown" : "Click blocks on the left", rx + 4, ry + 4, Theme.DIM);
        }
        if (editing != null) {
            int py = y + h - 12 - 18 - pickerH + 4;
            final String id = editing;
            Draw.text(c, this.textRenderer, id.isEmpty() ? "Default colour" : nameOf(id), rx, py - 10, Theme.MUTED);
            colorPicker(c, rx + 2, py + 2, rw - 6, "bp-" + id, new java.util.function.IntSupplier() {
                @Override public int getAsInt() { return id.isEmpty() ? setting.defaultColor : setting.colorOf(id); }
            }, new java.util.function.IntConsumer() {
                @Override public void accept(int v) {
                    int argb = v | 0xFF000000;
                    if (id.isEmpty()) setting.defaultColor = argb;
                    else setting.setColor(id, argb);
                }
            }, false);
        }
        int by = y + h - 24;
        button(c, rx, by, (rw - 6) / 2, 16, "Clear all", true, Theme.BAD, new Runnable() {
            @Override public void run() {
                setting.reset();
                editing = null;
                ConfigStore.markDirty();
            }
        });
        button(c, rx + (rw - 6) / 2 + 6, by, (rw - 6) / 2, 16, "Done", true, Theme.accent(), new Runnable() {
            @Override public void run() { close(); }
        });
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        int dir = vertical > 0 ? -3 : 3;
        int w = Math.min(600, this.width - 20);
        int x = (this.width - w) / 2;
        int leftW = (w - 36) * 11 / 20;
        if (mx < x + 12 + leftW + 6) scroll += dir;
        else selScroll += dir / 3;
        return true;
    }
}
