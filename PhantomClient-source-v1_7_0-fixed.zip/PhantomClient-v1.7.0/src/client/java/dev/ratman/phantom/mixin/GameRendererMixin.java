package dev.ratman.phantom.mixin;

import dev.ratman.phantom.modules.RenderModules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * While Free Look is active the camera looks elsewhere, but what you can hit or interact with must
 * still come from the character's own view. The crosshair ray is therefore computed with the real
 * player as the camera entity and the detached camera is put back afterwards.
 */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Unique
    private Entity phantom$savedCamera;

    @Inject(method = "updateCrosshairTarget", at = @At("HEAD"), require = 0)
    private void phantom$aimFromBody(float tickProgress, CallbackInfo ci) {
        phantom$savedCamera = null;
        if (!RenderModules.freeLookActive()) return;
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        Entity camera = client.getCameraEntity();
        if (player != null && camera != null && camera != player) {
            phantom$savedCamera = camera;
            ((MinecraftClientAccessor) (Object) client).phantom$setCameraEntityRaw(player);
        }
    }

    @Inject(method = "updateCrosshairTarget", at = @At("RETURN"), require = 0)
    private void phantom$restoreCamera(float tickProgress, CallbackInfo ci) {
        if (phantom$savedCamera != null) {
            ((MinecraftClientAccessor) (Object) MinecraftClient.getInstance()).phantom$setCameraEntityRaw(phantom$savedCamera);
            phantom$savedCamera = null;
        }
    }
}
