package dev.ratman.phantom.gui;

import com.google.gson.JsonObject;

import java.util.HashMap;
import java.util.Map;

/** Persisted panel layout (positions / collapsed state) of the ClickGUI. */
public final class GuiState {
    public static final class PanelState {
        public int x = Integer.MIN_VALUE;
        public int y = Integer.MIN_VALUE;
        public boolean collapsed;
        /** Per-panel size overrides set by dragging the resize grip; 0 = use the theme default. */
        public int w;
        public int h;
    }

    private static final Map<String, PanelState> PANELS = new HashMap<String, PanelState>();

    private GuiState() {}

    public static PanelState panel(String id) {
        PanelState s = PANELS.get(id);
        if (s == null) {
            s = new PanelState();
            PANELS.put(id, s);
        }
        return s;
    }

    public static void clear() { PANELS.clear(); }

    public static JsonObject save() {
        JsonObject root = new JsonObject();
        for (Map.Entry<String, PanelState> e : PANELS.entrySet()) {
            PanelState p = e.getValue();
            if (p.x == Integer.MIN_VALUE) continue;
            JsonObject o = new JsonObject();
            o.addProperty("x", p.x);
            o.addProperty("y", p.y);
            o.addProperty("collapsed", p.collapsed);
            if (p.w > 0) o.addProperty("w", p.w);
            if (p.h > 0) o.addProperty("h", p.h);
            root.add(e.getKey(), o);
        }
        return root;
    }

    public static void load(JsonObject root) {
        PANELS.clear();
        if (root == null) return;
        for (Map.Entry<String, com.google.gson.JsonElement> e : root.entrySet()) {
            try {
                JsonObject o = e.getValue().getAsJsonObject();
                PanelState p = new PanelState();
                p.x = o.get("x").getAsInt();
                p.y = o.get("y").getAsInt();
                p.collapsed = o.has("collapsed") && o.get("collapsed").getAsBoolean();
                if (o.has("w")) p.w = o.get("w").getAsInt();
                if (o.has("h")) p.h = o.get("h").getAsInt();
                PANELS.put(e.getKey(), p);
            } catch (RuntimeException ignored) {
                // skip malformed panel entry
            }
        }
    }
}
