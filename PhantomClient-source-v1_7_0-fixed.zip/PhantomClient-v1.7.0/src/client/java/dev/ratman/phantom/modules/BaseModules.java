package dev.ratman.phantom.modules;

import dev.ratman.phantom.module.Module;
import dev.ratman.phantom.module.ModuleCategory;
import dev.ratman.phantom.module.ModuleManager;
import dev.ratman.phantom.setting.Setting;
import dev.ratman.phantom.util.Blocks;
import dev.ratman.phantom.util.Draw;
import dev.ratman.phantom.util.Notifier;
import dev.ratman.phantom.util.RenderUtil;
import dev.ratman.phantom.world.BlockScanner;
import dev.ratman.phantom.world.SpawnerTracker;
import dev.ratman.phantom.world.SuspiciousChunkFinder;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/** Base Finding category. Each detector is its own independently configurable module. */
public final class BaseModules {
    private BaseModules() {}

    public static void register() {
        ModuleManager.register(new SuspiciousChunks());
        ModuleManager.register(new SpawnerNotifier());
        ModuleManager.register(new StorageFinder());
    }

    /** Current suspicious-chunk parameters (used by the Region Map), or null when the module is absent. */
    public static SuspiciousChunkFinder.Params chunkParams() {
        Module m = ModuleManager.byId("suspicious_chunk_finder");
        if (m instanceof SuspiciousChunks) {
            SuspiciousChunks sc = (SuspiciousChunks) m;
            sc.refreshParams();
            return sc.params;
        }
        return null;
    }

    public static void chunkLoaded(int cx, int cz) {
        if (ModuleManager.enabled("suspicious_chunk_finder")) SuspiciousChunkFinder.onChunkLoaded(cx, cz);
        if (ModuleManager.enabled("spawner_notifier")) SpawnerTracker.onChunkLoaded(cx, cz);
    }

    // ================================================================== Suspicious Chunk Finder
    static final class SuspiciousChunks extends Module {
        final Setting.Num radius = num("radius", "Scan radius", 3.0, 1.0, 8.0, 1.0, " chunks");
        final Setting.Num yLevel = num("ylevel", "Highest Y to scan", 0.0, -64.0, 64.0, 1.0);
        final Setting.Num threshold = num("threshold", "Min storage blocks", 4.0, 4.0, 24.0, 1.0);
        final Setting.Num minY = num("miny", "Lowest Y to scan", -64.0, -64.0, 64.0, 1.0);
        final Setting.Bool hoppers = bool("hoppers", "Count hoppers", true);
        final Setting.Bool furnaces = bool("furnaces", "Count furnaces / brewing stands", true);
        final Setting.Bool dispensers = bool("dispensers", "Count dispensers / droppers", true);
        final Setting.Bool redstone = bool("redstone", "Observe redstone changes", true);
        final Setting.Bool needRedstone = bool("needredstone", "Require redstone change", true);
        final Setting.Col color = color("color", "Highlight colour", 0xFFC8A2FF);
        final Setting.Bool glow = bool("glow", "Glow", true);
        final Setting.Col glowColor = color("glowcolor", "Glow colour", 0xFFE5D4FF);
        final Setting.Num glowIntensity = num("glowintensity", "Glow intensity", 2.0, 1.0, 5.0, 1.0);
        final Setting.Num range = num("range", "Render range", 128.0, 32.0, 256.0, 8.0, " blocks");
        final Setting.Bool tracers = bool("tracers", "Tracers", false);
        final Setting.Bool chat = bool("chat", "Chat notification", true);
        final Setting.Bool sound = bool("sound", "Notification sound", true);
        final Setting.Bool copy = bool("copy", "Copy chunk centre to clipboard on find", false);
        private final SuspiciousChunkFinder.Params params = new SuspiciousChunkFinder.Params();

        SuspiciousChunks() {
            super("suspicious_chunk_finder", "Sus Chunk Finder", ModuleCategory.BASE_FINDING,
                    "Remembers deep storage clusters and observed redstone activity in loaded chunks. Never loads chunks.");
            needRedstone.visibleWhen(() -> redstone.on());
            glowColor.visibleWhen(() -> glow.on());
            glowIntensity.visibleWhen(() -> glow.on());
        }

        private void refreshParams() {
            params.radius = radius.i();
            params.depthCutoff = yLevel.i();
            params.threshold = Math.max(4, threshold.i());
            params.scanRedstone = redstone.on();
            params.requireRedstone = redstone.on() && needRedstone.on();
            params.notifyChat = chat.on();
            params.notifySound = sound.on();
            params.scansPerTick = ClientModules.scansPerTick();
            params.minY = minY.i();
            params.hoppers = hoppers.on();
            params.furnaces = furnaces.on();
            params.dispensers = dispensers.on();
            params.copyCoords = copy.on();
        }

        @Override public void onTick() {
            refreshParams();
            SuspiciousChunkFinder.tick(mc, params);
        }

        @Override public void onDisable() { SuspiciousChunkFinder.save(); }

        @Override public void onWorldReset() { SuspiciousChunkFinder.save(); }

        @Override public void onRender3D(WorldRenderContext ctx, float td) {
            RenderUtil.Pass pass = RenderUtil.begin(ctx);
            if (pass == null) return;
            refreshParams();
            List<SuspiciousChunkFinder.StorageBlock> blocks = SuspiciousChunkFinder.highlighted(
                    pass.camera.x, pass.camera.y, pass.camera.z, range.d(), params);
            int c = color.argb();
            for (SuspiciousChunkFinder.StorageBlock b : blocks) {
                for (SuspiciousChunkFinder.ShapeBox s : b.outline) {
                    Box box = new Box(b.position.getX() + s.minX, b.position.getY() + s.minY, b.position.getZ() + s.minZ,
                            b.position.getX() + s.maxX, b.position.getY() + s.maxY, b.position.getZ() + s.maxZ);
                    pass.box(box, c, 0, 0f);
                    if (glow.on()) pass.glow(box, glowColor.argb(), glowIntensity.i() + 1, 1.0f);
                }
                if (tracers.on()) pass.tracer(Vec3d.ofCenter(b.position), c);
            }
        }

        @Override public String info() { return SuspiciousChunkFinder.rememberedStorage() + " stored"; }
    }

    // ================================================================== Spawner Notifier
    static final class SpawnerNotifier extends Module {
        final Setting.Num radius = num("radius", "Scan radius", 12.0, 2.0, 24.0, 1.0, " chunks");
        final Setting.Bool disconnect = bool("disconnect", "Disconnect on NEW spawner", true);
        final Setting.Num disconnectDelay = num("delay", "Disconnect delay", 0.0, 0.0, 10.0, 1.0, " s");
        final Setting.Bool copy = bool("copy", "Copy coordinates to clipboard", false);
        final Setting.Bool chat = bool("chat", "Chat notification", true);
        final Setting.Bool sound = bool("sound", "Notification sound", true);
        final Setting.Col color = color("color", "Outline colour", 0xFFFF2D2D);
        final Setting.Bool glow = bool("glow", "Red glow", true);
        final Setting.Num glowIntensity = num("glowintensity", "Glow intensity", 3.0, 1.0, 5.0, 1.0);
        final Setting.Bool pillar = bool("pillar", "Vertical line to ceiling / bedrock", true);
        final Setting.Bool listHud = bool("list", "Show coordinates on screen", true);
        final Setting.Num range = num("range", "Render range", 512.0, 64.0, 1024.0, 16.0, " blocks");
        private final SpawnerTracker.Params params = new SpawnerTracker.Params();

        SpawnerNotifier() {
            super("spawner_notifier", "Spawner Notifier", ModuleCategory.BASE_FINDING,
                    "Finds mob spawners, remembers them across reconnects and optionally disconnects on a NEW one.");
            glowIntensity.visibleWhen(() -> glow.on());
            disconnectDelay.visibleWhen(() -> disconnect.on());
        }

        @Override public void onTick() {
            params.radius = radius.i();
            params.disconnectDelay = disconnectDelay.i();
            params.copyCoords = copy.on();
            params.disconnect = disconnect.on();
            params.notifyChat = chat.on();
            params.notifySound = sound.on();
            SpawnerTracker.tick(mc, params);
        }

        @Override public void onDisable() { SpawnerTracker.save(); }

        @Override public void onWorldReset() { SpawnerTracker.save(); }

        @Override public void onRender3D(WorldRenderContext ctx, float td) {
            List<BlockPos> known = SpawnerTracker.known();
            if (known.isEmpty()) return;
            RenderUtil.Pass pass = RenderUtil.begin(ctx);
            if (pass == null) return;
            double r2 = range.d() * range.d();
            double top = mc.world.getTopYInclusive() + 1;
            double bottom = mc.world.getBottomY();
            for (BlockPos pos : known) {
                Vec3d center = Vec3d.ofCenter(pos);
                if (center.squaredDistanceTo(pass.camera) > r2) continue;
                Box b = new Box(pos);
                pass.box(b, color.argb(), 0, 0f);
                if (glow.on()) pass.glow(b, color.argb(), glowIntensity.i() + 1, 1.0f);
                if (pillar.on()) {
                    pass.line(center, new Vec3d(center.x, top, center.z), 0xFFFFFFFF);
                    pass.line(center, new Vec3d(center.x, bottom, center.z), 0xFFFFFFFF);
                }
            }
        }

        @Override public void onHud(DrawContext c, float td) {
            if (!listHud.on()) return;
            List<BlockPos> known = SpawnerTracker.known();
            if (known.isEmpty() || mc.currentScreen != null) return;
            final Vec3d me = dev.ratman.phantom.util.Compat.pos(mc.player);
            known.sort((a, b) -> Double.compare(Vec3d.ofCenter(a).squaredDistanceTo(me), Vec3d.ofCenter(b).squaredDistanceTo(me)));
            int x = 6;
            int y = c.getScaledWindowHeight() / 2 - 20;
            c.drawText(mc.textRenderer, "Spawners (" + known.size() + ")", x, y, color.argb(), true);
            int shown = 0;
            for (BlockPos pos : known) {
                if (shown++ >= 6) break;
                y += 10;
                int dist = (int) Math.round(Math.sqrt(Vec3d.ofCenter(pos).squaredDistanceTo(me)));
                c.drawText(mc.textRenderer, SpawnerTracker.coords(pos) + "  (" + dist + "m)", x, y, 0xFFFFFFFF, true);
            }
        }

        @Override public String info() { return SpawnerTracker.known().size() + " known"; }
    }

    // ================================================================== Storage Finder
    static final class StorageFinder extends Module {
        final Setting.Num radius = num("radius", "Scan radius", 6.0, 1.0, 12.0, 1.0, " chunks");
        final Setting.Num threshold = num("threshold", "Min storage per chunk", 6.0, 2.0, 64.0, 1.0);
        final Setting.Num maxY = num("maxy", "Highest Y", 320.0, -64.0, 320.0, 1.0);
        final Setting.Bool chat = bool("chat", "Chat notification", true);
        final Setting.Bool sound = bool("sound", "Notification sound", true);
        private final Set<Long> announced = new HashSet<Long>();
        private int timer;

        StorageFinder() {
            super("storage_finder", "Storage Finder", ModuleCategory.BASE_FINDING,
                    "Announces chunks that hold many storage blocks (any height). Pair it with Storage ESP to see them.");
        }

        @Override public void onWorldReset() { announced.clear(); }

        @Override public void onEnable() { announced.clear(); }

        @Override public void onTick() {
            if (timer-- > 0) return;
            timer = 40;
            int pcx = mc.player.getBlockX() >> 4;
            int pcz = mc.player.getBlockZ() >> 4;
            int r = radius.i();
            for (int cx = pcx - r; cx <= pcx + r; cx++) {
                for (int cz = pcz - r; cz <= pcz + r; cz++) {
                    Chunk chunk = mc.world.getChunkManager().getChunk(cx, cz, ChunkStatus.FULL, false);
                    if (chunk == null) continue;
                    Map<String, Integer> counts = new TreeMap<String, Integer>();
                    int total = 0;
                    for (BlockEntity be : chunk.getBlockEntities().values()) {
                        if (be.getPos().getY() > maxY.i()) continue;
                        String id = BlockScanner.idOf(be.getCachedState());
                        if (!Blocks.isStorageId(id)) continue;
                        counts.merge(id, 1, Integer::sum);
                        total++;
                    }
                    long key = ((long) cx & 0xFFFFFFFFL) | (((long) cz & 0xFFFFFFFFL) << 32);
                    if (total >= threshold.i()) {
                        if (announced.add(key)) {
                            StringBuilder sb = new StringBuilder();
                            for (Map.Entry<String, Integer> e : counts.entrySet()) {
                                if (sb.length() > 0) sb.append(", ");
                                sb.append(e.getValue()).append("x ").append(e.getKey());
                            }
                            if (chat.on()) {
                                Notifier.chat("Storage cluster at chunk (" + cx + ", " + cz + ") around X " + (cx * 16 + 8)
                                        + " Z " + (cz * 16 + 8) + ": " + total + " blocks - " + sb);
                            }
                            dev.ratman.phantom.util.FindLog.add("Storage", total + " blocks: " + sb, new BlockPos(cx * 16 + 8, 0, cz * 16 + 8));
                            if (sound.on()) Notifier.sound(Notifier.SOUND_PING, 1.0f, 0.9f);
                        }
                    } else {
                        announced.remove(key);
                    }
                }
            }
        }
    }
}
