package dev.ratman.phantom.world;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import dev.ratman.phantom.config.ConfigStore;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.util.WorldSavePath;
import org.slf4j.Logger;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Named coordinates, saved per server (or singleplayer world) and shared by every dimension. */
public final class WaypointStore {
    private static final Logger LOG = LogUtils.getLogger();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final List<Waypoint> LIST = new ArrayList<Waypoint>();
    private static String key = "";

    public static final class Waypoint {
        public String name;
        public int x;
        public int y;
        public int z;
        /** Dimension path: "overworld", "the_nether", "the_end". */
        public String dimension;
        public boolean visible = true;
        public int color = 0xFFC084FC;

        public Waypoint(String name, int x, int y, int z, String dimension) {
            this.name = name;
            this.x = x;
            this.y = y;
            this.z = z;
            this.dimension = dimension;
        }
    }

    private WaypointStore() {}

    public static List<Waypoint> list() {
        ensure();
        return LIST;
    }

    public static String currentDimension() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.world == null ? "overworld" : mc.world.getRegistryKey().getValue().getPath();
    }

    private static String serverKey(MinecraftClient mc) {
        try {
            if (mc.isInSingleplayer() && mc.getServer() != null) {
                return "sp:" + mc.getServer().getSavePath(WorldSavePath.ROOT).toAbsolutePath();
            }
            ServerInfo info = mc.getCurrentServerEntry();
            if (info != null) return "mp:" + info.address.toLowerCase(Locale.ROOT);
        } catch (RuntimeException ignored) {
            // fall through
        }
        return "local";
    }

    private static Path path() {
        return ConfigStore.dataDir().resolve("waypoints-" + ConfigStore.worldFileId(key) + ".json");
    }

    /** Loads the right waypoint file for the current server (cheap when nothing changed). */
    public static void ensure() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;
        String k = serverKey(mc);
        if (k.equals(key)) return;
        key = k;
        LIST.clear();
        Path p = path();
        if (!Files.exists(p)) return;
        try (Reader r = Files.newBufferedReader(p, StandardCharsets.UTF_8)) {
            JsonElement e = JsonParser.parseReader(r);
            if (!e.isJsonObject() || !e.getAsJsonObject().has("waypoints")) return;
            for (JsonElement w : e.getAsJsonObject().getAsJsonArray("waypoints")) {
                JsonObject o = w.getAsJsonObject();
                Waypoint wp = new Waypoint(o.get("name").getAsString(), o.get("x").getAsInt(), o.get("y").getAsInt(),
                        o.get("z").getAsInt(), o.has("dim") ? o.get("dim").getAsString() : "overworld");
                if (o.has("visible")) wp.visible = o.get("visible").getAsBoolean();
                if (o.has("color")) wp.color = (int) Long.parseLong(o.get("color").getAsString().replace("#", ""), 16);
                LIST.add(wp);
            }
        } catch (IOException | RuntimeException ex) {
            LOG.error("[Phantom] Could not load waypoints", ex);
        }
    }

    public static Waypoint add(String name, int x, int y, int z) {
        ensure();
        String n = name == null || name.trim().isEmpty() ? "Waypoint " + (LIST.size() + 1) : name.trim();
        Waypoint wp = new Waypoint(n, x, y, z, currentDimension());
        LIST.add(wp);
        save();
        return wp;
    }

    public static void remove(Waypoint wp) {
        LIST.remove(wp);
        save();
    }

    public static void save() {
        if (key.isEmpty()) return;
        JsonObject root = new JsonObject();
        JsonArray arr = new JsonArray();
        for (Waypoint w : LIST) {
            JsonObject o = new JsonObject();
            o.addProperty("name", w.name);
            o.addProperty("x", w.x);
            o.addProperty("y", w.y);
            o.addProperty("z", w.z);
            o.addProperty("dim", w.dimension);
            o.addProperty("visible", w.visible);
            o.addProperty("color", String.format("#%08X", w.color));
            arr.add(o);
        }
        root.add("waypoints", arr);
        Path p = path();
        Path tmp = p.resolveSibling(p.getFileName().toString() + ".tmp");
        try {
            Files.createDirectories(p.getParent());
            try (Writer w = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8)) {
                w.write(GSON.toJson(root));
            }
            Files.move(tmp, p, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ex) {
            LOG.error("[Phantom] Could not save waypoints", ex);
        }
    }

    /** Coordinates of a waypoint as seen from the current dimension (overworld x8 / nether /8), or null if unrelated. */
    public static double[] localCoords(Waypoint w, String currentDim) {
        if (w.dimension.equals(currentDim)) return new double[]{w.x + 0.5, w.y, w.z + 0.5};
        if (w.dimension.equals("overworld") && currentDim.equals("the_nether")) return new double[]{w.x / 8.0, w.y, w.z / 8.0};
        if (w.dimension.equals("the_nether") && currentDim.equals("overworld")) return new double[]{w.x * 8.0, w.y, w.z * 8.0};
        return null;
    }
}
