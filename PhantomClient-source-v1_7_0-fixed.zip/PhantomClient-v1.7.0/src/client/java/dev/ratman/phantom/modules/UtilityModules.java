package dev.ratman.phantom.modules;

import dev.ratman.phantom.module.HudModule;
import dev.ratman.phantom.module.Module;
import dev.ratman.phantom.module.ModuleCategory;
import dev.ratman.phantom.module.ModuleManager;
import dev.ratman.phantom.setting.Setting;
import dev.ratman.phantom.util.ChatHooks;
import dev.ratman.phantom.util.Compat;
import dev.ratman.phantom.util.Draw;
import dev.ratman.phantom.util.Friends;
import dev.ratman.phantom.util.Inv;
import dev.ratman.phantom.util.Notifier;
import dev.ratman.phantom.util.Rot;
import dev.ratman.phantom.util.Theme;
import dev.ratman.phantom.world.WaypointStore;
import net.minecraft.block.BlockState;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Travel, safety, server and HUD helpers that make long sessions (for example on 2b2t) easier. */
public final class UtilityModules {
    private UtilityModules() {}

    public static void register() {
        ModuleManager.register(new ElytraHighway());
        ModuleManager.register(new AutoFirework());
        ModuleManager.register(new GoTo());
        ModuleManager.register(new Step());
        ModuleManager.register(new SafeWalk());
        ModuleManager.register(new AutoDrop());
        ModuleManager.register(new DurabilityAlert());
        ModuleManager.register(new Surround());
        ModuleManager.register(new AntiAfk());
        ModuleManager.register(new QueueNotifier());
        ModuleManager.register(new AutoLog());
        ModuleManager.register(new ChatAlerts());
        ModuleManager.register(new ChatFilter());
        ModuleManager.register(new ItemCounter());
        ModuleManager.register(new NearbyPlayers());
    }

    private static Set<String> csv(String text) {
        Set<String> out = new HashSet<String>();
        for (String part : text.toLowerCase(Locale.ROOT).split(",")) {
            String t = part.trim();
            if (!t.isEmpty()) out.add(t);
        }
        return out;
    }

    private static double horizontalSpeed(Vec3d v) {
        return Math.sqrt(v.x * v.x + v.z * v.z);
    }

    // ================================================================== Elytra Highway (pitch 40)
    static final class ElytraHighway extends Module {
        final Setting.Num climbPitch = num("climb", "Climb pitch", -40.0, -70.0, -10.0, 1.0, "\u00b0");
        final Setting.Num divePitch = num("dive", "Dive pitch", 40.0, 10.0, 70.0, 1.0, "\u00b0");
        final Setting.Num lowSpeed = num("low", "Start diving below", 1.0, 0.3, 2.0, 0.05, " b/t");
        final Setting.Num highSpeed = num("high", "Start climbing above", 1.6, 0.8, 3.0, 0.05, " b/t");
        final Setting.Num minY = num("miny", "Never go below Y", 120.0, -64.0, 320.0, 1.0);
        final Setting.Num turnSpeed = num("turn", "Pitch change speed", 90.0, 20.0, 360.0, 5.0, "\u00b0/s");
        final Setting.Bool lockYaw = bool("lockyaw", "Hold current heading", true);
        private boolean climbing = true;
        private float targetPitch;
        private float lockedYaw = Float.NaN;

        ElytraHighway() {
            super("elytra_highway", "Elytra Highway", ModuleCategory.MOVEMENT,
                    "Pitch-40 style elytra flying: alternates climbing and diving to keep speed without fireworks. Your view pitch changes.");
        }

        @Override public void onEnable() {
            climbing = true;
            lockedYaw = Float.NaN;
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (!p.isGliding()) {
                lockedYaw = Float.NaN;
                return;
            }
            if (Float.isNaN(lockedYaw)) lockedYaw = p.getYaw();
            double speed = p.getVelocity().length();
            if (p.getY() < minY.d()) climbing = true;
            else if (climbing && speed > highSpeed.d()) climbing = false;
            else if (!climbing && speed < lowSpeed.d()) climbing = true;
            if (!climbing && p.getY() < minY.d() + 8) climbing = true;
            targetPitch = climbing ? climbPitch.f() : divePitch.f();
        }

        @Override public void onFrame(float dt) {
            ClientPlayerEntity p = mc.player;
            if (p == null || !p.isGliding() || mc.currentScreen != null) return;
            float step = turnSpeed.f() * Math.max(0f, dt);
            float diff = targetPitch - p.getPitch();
            p.setPitch(p.getPitch() + Math.max(-step, Math.min(step, diff)));
            if (lockYaw.on() && !Float.isNaN(lockedYaw)) {
                float dy = Rot.wrap(lockedYaw - p.getYaw());
                p.setYaw(p.getYaw() + Math.max(-step, Math.min(step, dy)));
            }
        }

        @Override public String info() { return climbing ? "climb" : "dive"; }
    }

    // ================================================================== Auto Firework
    static final class AutoFirework extends Module {
        final Setting.Num minSpeed = num("minspeed", "Boost below", 0.9, 0.2, 2.0, 0.05, " b/t");
        final Setting.Num delay = num("delay", "Minimum delay", 40.0, 10.0, 200.0, 5.0, " ticks");
        final Setting.Bool swapBack = bool("swapback", "Swap back to previous slot", true);
        final Setting.Bool offhand = bool("offhand", "Use offhand rockets first", true);
        private int cooldown;
        private int previousSlot = -1;
        private int restoreIn;

        AutoFirework() {
            super("auto_firework", "Auto Firework", ModuleCategory.MOVEMENT,
                    "Fires a firework rocket while gliding whenever your speed drops too low.");
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (restoreIn > 0 && --restoreIn == 0 && previousSlot >= 0) {
                if (swapBack.on()) Compat.selectHotbar(previousSlot);
                previousSlot = -1;
            }
            if (cooldown > 0) cooldown--;
            if (!p.isGliding() || cooldown > 0 || mc.currentScreen != null || mc.interactionManager == null) return;
            if (p.getVelocity().length() >= minSpeed.d()) return;
            if (offhand.on() && Inv.offhand().isOf(Items.FIREWORK_ROCKET)) {
                mc.interactionManager.interactItem(p, Hand.OFF_HAND);
                cooldown = delay.i();
                return;
            }
            int slot = Inv.findHotbar(s -> s.isOf(Items.FIREWORK_ROCKET));
            if (slot < 0) return;
            if (previousSlot < 0) previousSlot = Compat.selectedHotbar();
            Compat.selectHotbar(slot);
            mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
            cooldown = delay.i();
            restoreIn = 3;
        }

        @Override public void onDisable() {
            if (previousSlot >= 0 && swapBack.on()) Compat.selectHotbar(previousSlot);
            previousSlot = -1;
            restoreIn = 0;
        }
    }

    // ================================================================== Go To
    static final class GoTo extends Module {
        final Setting.Text target = text("target", "Target (x z, x y z or waypoint name)", "0 0", 48);
        final Setting.Num stop = num("stop", "Stop within", 3.0, 1.0, 30.0, 0.5, " blocks");
        final Setting.Bool sprint = bool("sprint", "Sprint", true);
        final Setting.Bool jump = bool("jump", "Jump over obstacles", true);
        final Setting.Bool swim = bool("swim", "Swim up in water", true);
        final Setting.Num turnSpeed = num("turn", "Turn speed", 240.0, 60.0, 720.0, 10.0, "\u00b0/s");
        final Setting.Bool disableOnArrive = bool("disable", "Turn off on arrival", true);
        private double tx;
        private double tz;
        private boolean valid;
        private boolean pressedForward;

        GoTo() {
            super("go_to", "Go To", ModuleCategory.MOVEMENT,
                    "Walks in a straight line to coordinates (or a saved waypoint). It does not path-find around walls or water.");
        }

        private boolean parse() {
            String raw = target.get().trim();
            for (WaypointStore.Waypoint w : WaypointStore.list()) {
                if (w.name.equalsIgnoreCase(raw)) {
                    double[] c = WaypointStore.localCoords(w, WaypointStore.currentDimension());
                    if (c == null) return false;
                    tx = c[0];
                    tz = c[2];
                    return true;
                }
            }
            String[] t = raw.replace(",", " ").trim().split("\\s+");
            try {
                if (t.length == 2) {
                    tx = Double.parseDouble(t[0]);
                    tz = Double.parseDouble(t[1]);
                    return true;
                }
                if (t.length == 3) {
                    tx = Double.parseDouble(t[0]);
                    tz = Double.parseDouble(t[2]);
                    return true;
                }
            } catch (NumberFormatException ignored) {
                // invalid
            }
            return false;
        }

        @Override public void onEnable() {
            if (mc.player == null) {
                mc.execute(() -> setEnabled(false));
                return;
            }
            valid = parse();
            if (!valid) {
                Notifier.chat("Go To: could not read target \"" + target.get() + "\". Use \"x z\" or a waypoint name.");
                mc.execute(() -> setEnabled(false));
            } else {
                Notifier.chat("Walking to X " + Math.round(tx) + " Z " + Math.round(tz));
            }
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (!valid || mc.currentScreen != null) return;
            double dx = tx - p.getX();
            double dz = tz - p.getZ();
            if (Math.sqrt(dx * dx + dz * dz) <= stop.d()) {
                Notifier.chat("Go To: arrived.");
                Notifier.sound(Notifier.SOUND_PING, 1.0f, 1.3f);
                if (disableOnArrive.on()) mc.execute(() -> setEnabled(false));
                else {
                    mc.options.forwardKey.setPressed(false);
                    pressedForward = false;
                }
                return;
            }
            mc.options.forwardKey.setPressed(true);
            pressedForward = true;
            if (sprint.on()) p.setSprinting(true);
            if (jump.on() && p.isOnGround() && p.horizontalCollision) mc.options.jumpKey.setPressed(true);
            else if (swim.on() && p.isTouchingWater()) mc.options.jumpKey.setPressed(true);
            else if (jump.on() || swim.on()) mc.options.jumpKey.setPressed(false);
        }

        @Override public void onFrame(float dt) {
            ClientPlayerEntity p = mc.player;
            if (p == null || !valid || mc.currentScreen != null) return;
            float want = (float) (Math.toDegrees(Math.atan2(tz - p.getZ(), tx - p.getX())) - 90.0);
            float diff = Rot.wrap(want - p.getYaw());
            float step = turnSpeed.f() * Math.max(0f, dt);
            p.setYaw(p.getYaw() + Math.max(-step, Math.min(step, diff)));
        }

        @Override public void onDisable() {
            valid = false;
            if (pressedForward) KeyBinding.updatePressedStates();
            pressedForward = false;
        }
    }

    // ================================================================== Step
    static final class Step extends Module {
        final Setting.Num height = num("height", "Step height", 1.0, 0.6, 2.5, 0.1, " blocks");
        private double original = Double.NaN;

        Step() {
            super("step", "Step", ModuleCategory.MOVEMENT,
                    "Lets you walk up blocks without jumping. Client-side; servers may rubber-band larger steps.");
        }

        @Override public void onTick() {
            EntityAttributeInstance inst = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
            if (inst == null) return;
            if (Double.isNaN(original)) original = inst.getBaseValue();
            if (inst.getBaseValue() != height.d()) inst.setBaseValue(height.d());
        }

        @Override public void onDisable() {
            if (mc.player != null && !Double.isNaN(original)) {
                EntityAttributeInstance inst = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
                if (inst != null) inst.setBaseValue(original);
            }
            original = Double.NaN;
        }

        @Override public String info() { return String.format(Locale.ROOT, "%.1f", height.d()); }
    }

    // ================================================================== Safe Walk
    static final class SafeWalk extends Module {
        final Setting.Num drop = num("drop", "Treat drops of at least", 2.0, 1.0, 6.0, 1.0, " blocks");
        final Setting.Num lookahead = num("lookahead", "Look ahead", 0.35, 0.1, 1.0, 0.05, " blocks");
        private boolean forced;

        SafeWalk() {
            super("safe_walk", "Safe Walk", ModuleCategory.MOVEMENT,
                    "Automatically sneaks at ledges so you do not walk off edges (or into lava pits).");
        }

        private boolean unsafe(double x, double z) {
            BlockPos feet = BlockPos.ofFloored(x, mc.player.getY(), z);
            for (int i = 1; i <= drop.i(); i++) {
                BlockState s = mc.world.getBlockState(feet.down(i));
                if (!s.isAir() && s.getFluidState().isEmpty()) return false;
            }
            return true;
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (mc.currentScreen != null) return;
            boolean need = false;
            if (p.isOnGround() && MovementModules.moving(mc.options)) {
                double[] k = MovementModules.keys(mc.options);
                Vec3d dir = MovementModules.direction(k[0], k[1], p.getYaw()).multiply(lookahead.d());
                need = unsafe(p.getX() + dir.x, p.getZ() + dir.z);
            }
            if (need) {
                mc.options.sneakKey.setPressed(true);
                forced = true;
            } else if (forced) {
                KeyBinding.updatePressedStates();
                forced = false;
            }
        }

        @Override public void onDisable() {
            if (forced) KeyBinding.updatePressedStates();
            forced = false;
        }
    }

    // ================================================================== Auto Drop
    static final class AutoDrop extends Module {
        final Setting.Text items = text("items", "Item ids to drop (comma list)", "cobblestone,dirt,gravel,netherrack,cobbled_deepslate", 200);
        final Setting.Num delay = num("delay", "Delay", 6.0, 1.0, 40.0, 1.0, " ticks");
        final Setting.Bool hotbar = bool("hotbar", "Also drop from hotbar", false);
        final Setting.Bool onlyInventory = bool("inventoryonly", "Only while inventory is open", false);
        private int wait;

        AutoDrop() {
            super("auto_drop", "Auto Drop", ModuleCategory.PLAYER,
                    "Throws junk items out of your inventory automatically (item ids such as cobblestone, dirt).");
        }

        @Override public void onTick() {
            if (!Inv.canClick()) return;
            if (onlyInventory.on() && !(mc.currentScreen instanceof net.minecraft.client.gui.screen.ingame.InventoryScreen)) return;
            if (wait > 0) {
                wait--;
                return;
            }
            Set<String> ids = csv(items.get());
            if (ids.isEmpty()) return;
            int from = hotbar.on() ? 0 : 9;
            for (int i = from; i < 36; i++) {
                ItemStack s = mc.player.getInventory().getStack(i);
                if (s.isEmpty()) continue;
                String id = Registries.ITEM.getId(s.getItem()).getPath();
                if (ids.contains(id)) {
                    Inv.click(Inv.slotId(i), 1, SlotActionType.THROW);
                    wait = delay.i();
                    return;
                }
            }
        }
    }

    // ================================================================== Durability Alert
    static final class DurabilityAlert extends Module {
        final Setting.Num percent = num("percent", "Warn below", 15.0, 3.0, 60.0, 1.0, "%");
        final Setting.Bool armor = bool("armor", "Armour", true);
        final Setting.Bool tool = bool("tool", "Held tool / weapon", true);
        final Setting.Bool elytra = bool("elytra", "Elytra", true);
        final Setting.Bool sound = bool("sound", "Sound", true);
        private final Set<String> warned = new HashSet<String>();
        private int timer;

        DurabilityAlert() {
            super("durability_alert", "Durability Alert", ModuleCategory.PLAYER,
                    "Warns once when armour, elytra or your held tool is about to break.");
        }

        @Override public void onWorldReset() { warned.clear(); }

        private void check(ItemStack s, String slot) {
            if (s.isEmpty() || !s.isDamageable()) {
                warned.remove(slot);
                return;
            }
            double left = 100.0 * (s.getMaxDamage() - s.getDamage()) / Math.max(1, s.getMaxDamage());
            if (left <= percent.d()) {
                if (warned.add(slot)) {
                    Notifier.chat(s.getName().getString() + " (" + slot + ") is at " + Math.round(left) + "% durability.");
                    if (sound.on()) Notifier.sound(Notifier.SOUND_WARN, 0.8f, 0.9f);
                }
            } else {
                warned.remove(slot);
            }
        }

        @Override public void onTick() {
            if (timer-- > 0) return;
            timer = 40;
            ClientPlayerEntity p = mc.player;
            if (armor.on()) {
                check(p.getEquippedStack(EquipmentSlot.HEAD), "helmet");
                if (!(elytra.on() && p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA))) check(p.getEquippedStack(EquipmentSlot.CHEST), "chest");
                check(p.getEquippedStack(EquipmentSlot.LEGS), "legs");
                check(p.getEquippedStack(EquipmentSlot.FEET), "boots");
            }
            if (elytra.on() && p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) check(p.getEquippedStack(EquipmentSlot.CHEST), "elytra");
            if (tool.on()) check(p.getMainHandStack(), "main hand");
        }
    }

    // ================================================================== Surround
    static final class Surround extends Module {
        final Setting.Num perTick = num("pertick", "Blocks per tick", 2.0, 1.0, 4.0, 1.0);
        final Setting.Num delay = num("delay", "Delay between placements", 1.0, 0.0, 10.0, 1.0, " ticks");
        final Setting.Bool disableOnMove = bool("move", "Turn off when you leave the block", true);
        final Setting.Bool swapBack = bool("swapback", "Swap back after placing", true);
        final Setting.Bool announce = bool("announce", "Tell me when I have no obsidian", true);
        private BlockPos origin;
        private int wait;
        private boolean warned;

        Surround() {
            super("surround", "Surround", ModuleCategory.COMBAT,
                    "Places obsidian on the four sides of your feet (crystal-PvP protection). Needs obsidian in the hotbar.");
        }

        @Override public void onEnable() {
            origin = mc.player == null ? null : mc.player.getBlockPos();
            warned = false;
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (mc.currentScreen != null || mc.interactionManager == null || origin == null) return;
            if (disableOnMove.on() && !p.getBlockPos().equals(origin)) {
                setEnabled(false);
                return;
            }
            if (wait > 0) {
                wait--;
                return;
            }
            int slot = Inv.findHotbar(s -> s.isOf(Items.OBSIDIAN));
            if (slot < 0) {
                if (announce.on() && !warned) {
                    Notifier.chat("Surround: no obsidian in your hotbar.");
                    warned = true;
                }
                return;
            }
            int previous = Compat.selectedHotbar();
            int placed = 0;
            for (Direction d : Direction.Type.HORIZONTAL) {
                if (placed >= perTick.i()) break;
                BlockPos target = origin.offset(d);
                if (!mc.world.getBlockState(target).isAir()) continue;
                BlockPos support = target.down();
                BlockState sup = mc.world.getBlockState(support);
                if (!sup.isSolidBlock(mc.world, support)) continue;
                if (!mc.world.getOtherEntities(null, new net.minecraft.util.math.Box(target)).isEmpty()) continue;
                if (placed == 0) Compat.selectHotbar(slot);
                BlockHitResult hit = new BlockHitResult(
                        new Vec3d(support.getX() + 0.5, support.getY() + 1.0, support.getZ() + 0.5), Direction.UP, support, false);
                mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
                p.swingHand(Hand.MAIN_HAND);
                placed++;
            }
            if (placed > 0) {
                if (swapBack.on()) Compat.selectHotbar(previous);
                wait = delay.i();
            }
        }
    }

    // ================================================================== Anti AFK
    static final class AntiAfk extends Module {
        final Setting.Bool jump = bool("jump", "Jump", true);
        final Setting.Num jumpEvery = num("jumpevery", "Jump every", 25.0, 5.0, 120.0, 1.0, " s");
        final Setting.Bool swing = bool("swing", "Swing arm", true);
        final Setting.Num swingEvery = num("swingevery", "Swing every", 12.0, 3.0, 120.0, 1.0, " s");
        final Setting.Bool look = bool("look", "Turn the camera slightly", true);
        final Setting.Num lookDegrees = num("degrees", "Turn amount", 25.0, 5.0, 90.0, 1.0, "\u00b0");
        final Setting.Bool walk = bool("walk", "Step forward and back", false);
        final Setting.Num walkEvery = num("walkevery", "Step every", 40.0, 10.0, 300.0, 5.0, " s");
        private long nextJump;
        private long nextSwing;
        private long nextLook;
        private long nextWalk;
        private int walkPhase;
        private int jumpRelease;
        private float lookTarget = Float.NaN;

        AntiAfk() {
            super("anti_afk", "Anti AFK", ModuleCategory.SERVER,
                    "Performs small harmless actions at intervals so idle-kick timers keep resetting.");
        }

        @Override public void onEnable() {
            long now = System.currentTimeMillis();
            nextJump = now + 5000;
            nextSwing = now + 3000;
            nextLook = now + 8000;
            nextWalk = now + 15000;
            walkPhase = 0;
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (mc.currentScreen != null) return;
            long now = System.currentTimeMillis();
            if (jumpRelease > 0 && --jumpRelease == 0) KeyBinding.updatePressedStates();
            if (jump.on() && now >= nextJump && p.isOnGround()) {
                mc.options.jumpKey.setPressed(true);
                jumpRelease = 2;
                nextJump = now + Math.round(jumpEvery.d() * 1000.0);
            }
            if (swing.on() && now >= nextSwing) {
                p.swingHand(Hand.MAIN_HAND);
                nextSwing = now + Math.round(swingEvery.d() * 1000.0);
            }
            if (look.on() && now >= nextLook) {
                lookTarget = p.getYaw() + (Math.random() < 0.5 ? -1 : 1) * lookDegrees.f();
                nextLook = now + 20000L;
            }
            if (walk.on()) {
                if (walkPhase == 0 && now >= nextWalk) {
                    walkPhase = 6;
                    nextWalk = now + Math.round(walkEvery.d() * 1000.0);
                }
                if (walkPhase > 3) {
                    mc.options.forwardKey.setPressed(true);
                    walkPhase--;
                } else if (walkPhase > 0) {
                    mc.options.forwardKey.setPressed(false);
                    mc.options.backKey.setPressed(true);
                    walkPhase--;
                    if (walkPhase == 0) KeyBinding.updatePressedStates();
                }
            }
        }

        @Override public void onFrame(float dt) {
            ClientPlayerEntity p = mc.player;
            if (p == null || Float.isNaN(lookTarget) || mc.currentScreen != null) return;
            float diff = Rot.wrap(lookTarget - p.getYaw());
            float step = 60f * Math.max(0f, dt);
            if (Math.abs(diff) <= step) {
                p.setYaw(lookTarget);
                lookTarget = Float.NaN;
            } else {
                p.setYaw(p.getYaw() + Math.signum(diff) * step);
            }
        }

        @Override public void onDisable() {
            KeyBinding.updatePressedStates();
            lookTarget = Float.NaN;
        }
    }

    // ================================================================== Queue Notifier
    static final class QueueNotifier extends Module {
        final Setting.Num threshold = num("threshold", "Alert at position", 10.0, 1.0, 200.0, 1.0);
        final Setting.Bool everyStep = bool("everystep", "Also ping on every drop below the threshold", true);
        final Setting.Bool hud = bool("hud", "Show position on screen", true);
        final Setting.Bool joinAlert = bool("join", "Loud alert when the queue ends", true);
        final Setting.Text pattern = text("pattern", "Queue message pattern (regex, one number group)", "(?i)position in queue:?\\s*(\\d+)", 120);
        private int position = -1;
        private int lastAlerted = Integer.MAX_VALUE;
        private long lastSeen;
        private boolean wasQueued;
        private Pattern compiled;
        private String compiledFrom = "";

        QueueNotifier() {
            super("queue_notifier", "Queue Notifier", ModuleCategory.SERVER,
                    "Reads the server's 'position in queue' messages and alerts you when you are close or have joined.");
            ChatHooks.listen(this::onMessage);
            everyStep.visibleWhen(() -> true);
        }

        private Pattern pattern() {
            if (compiled == null || !compiledFrom.equals(pattern.get())) {
                try {
                    compiled = Pattern.compile(pattern.get());
                } catch (RuntimeException e) {
                    compiled = Pattern.compile("(?i)position in queue:?\\s*(\\d+)");
                }
                compiledFrom = pattern.get();
            }
            return compiled;
        }

        private void onMessage(String text) {
            if (!enabled()) return;
            Matcher m = pattern().matcher(text);
            if (!m.find() || m.groupCount() < 1) return;
            int pos;
            try {
                pos = Integer.parseInt(m.group(1));
            } catch (NumberFormatException e) {
                return;
            }
            position = pos;
            lastSeen = System.currentTimeMillis();
            wasQueued = true;
            if (pos <= threshold.i() && (pos < lastAlerted && (everyStep.on() || lastAlerted == Integer.MAX_VALUE))) {
                lastAlerted = pos;
                Notifier.chat("Queue position " + pos + (pos <= 3 ? " - almost there!" : ""));
                Notifier.sound(Notifier.SOUND_PING, 1.0f, pos <= 3 ? 1.6f : 1.1f);
            }
        }

        @Override public void onTick() {
            // The queue messages stop when you get in: treat ~25 s of silence after a position as "joined".
            if (wasQueued && System.currentTimeMillis() - lastSeen > 25000L) {
                wasQueued = false;
                if (joinAlert.on() && position >= 0 && position <= Math.max(threshold.i(), 5)) {
                    Notifier.chat("The queue messages stopped: you are probably in the server now.");
                    Notifier.sound(Notifier.SOUND_SPAWNER, 1.0f, 1.2f);
                }
                position = -1;
                lastAlerted = Integer.MAX_VALUE;
            }
        }

        @Override public void onHud(DrawContext c, float td) {
            if (!hud.on() || position < 0 || mc.currentScreen != null) return;
            String s = "Queue: " + position;
            int w = mc.textRenderer.getWidth(s) + 14;
            int x = (c.getScaledWindowWidth() - w) / 2;
            ClientModules.panel(c, x, 6, w, 16, 0.8f);
            c.drawText(mc.textRenderer, s, x + 8, 10, position <= threshold.i() ? Theme.GOOD : Theme.TEXT, true);
        }

        @Override public String info() { return position < 0 ? "" : String.valueOf(position); }
    }

    // ================================================================== Auto Log
    static final class AutoLog extends Module {
        final Setting.Num health = num("health", "Disconnect at or below (0 = off)", 6.0, 0.0, 20.0, 0.5, " HP");
        final Setting.Num totems = num("totems", "Disconnect with fewer totems than (0 = off)", 0.0, 0.0, 10.0, 1.0);
        final Setting.Bool players = bool("players", "Disconnect when a non-friend player is near", false);
        final Setting.Num playerRange = num("playerrange", "Player range", 48.0, 8.0, 256.0, 4.0, " blocks");
        final Setting.Bool crystals = bool("crystals", "Disconnect when an end crystal is near", false);
        final Setting.Num crystalRange = num("crystalrange", "Crystal range", 8.0, 3.0, 20.0, 1.0, " blocks");
        final Setting.Num grace = num("grace", "Grace period after joining", 5.0, 0.0, 30.0, 1.0, " s");
        final Setting.Bool disableAfter = bool("disable", "Turn off after triggering", true);
        private long armedAt;

        AutoLog() {
            super("auto_log", "Auto Log", ModuleCategory.SERVER,
                    "Disconnects you when your life is in danger: low health, no totems, a stranger or crystals nearby.");
            playerRange.visibleWhen(() -> players.on());
            crystalRange.visibleWhen(() -> crystals.on());
        }

        @Override public void onWorldReset() { armedAt = 0; }

        @Override public void onEnable() { armedAt = 0; }

        private int totemCount(ClientPlayerEntity p) {
            int n = p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING) ? 1 : 0;
            for (int i = 0; i < 36; i++) if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) n++;
            return n;
        }

        private void trigger(String reason) {
            Notifier.chat("Auto Log: " + reason);
            Notifier.sound(Notifier.SOUND_WARN, 1.0f, 0.7f);
            if (disableAfter.on()) setEnabled(false);
            Compat.disconnect("Phantom Auto Log: " + reason);
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            long now = System.currentTimeMillis();
            if (armedAt == 0) armedAt = now + Math.round(grace.d() * 1000.0);
            if (now < armedAt) return;
            float hp = p.getHealth() + p.getAbsorptionAmount();
            if (health.d() > 0 && hp <= health.d() && p.isAlive()) {
                trigger("health is " + String.format(Locale.ROOT, "%.1f", hp));
                return;
            }
            if (totems.i() > 0 && totemCount(p) < totems.i()) {
                trigger("fewer than " + totems.i() + " totems left");
                return;
            }
            if (players.on()) {
                double r2 = playerRange.d() * playerRange.d();
                for (AbstractClientPlayerEntity o : mc.world.getPlayers()) {
                    if (o == p || Friends.is(o.getName().getString()) || p.squaredDistanceTo(o) > r2) continue;
                    trigger(o.getName().getString() + " came within " + Math.round(Math.sqrt(p.squaredDistanceTo(o))) + " blocks");
                    return;
                }
            }
            if (crystals.on()) {
                double r2 = crystalRange.d() * crystalRange.d();
                for (Entity e : mc.world.getEntities()) {
                    if (e instanceof EndCrystalEntity && p.squaredDistanceTo(e) <= r2) {
                        trigger("end crystal nearby");
                        return;
                    }
                }
            }
        }
    }

    // ================================================================== Chat Alerts
    static final class ChatAlerts extends Module {
        final Setting.Text words = text("words", "Words to alert on (comma list)", "", 160);
        final Setting.Bool ownName = bool("ownname", "Alert on my name", true);
        final Setting.Bool whisper = bool("whisper", "Alert on private messages", true);
        final Setting.Bool sound = bool("sound", "Sound", true);
        final Setting.Bool echo = bool("echo", "Repeat the message as a Phantom notice", false);

        ChatAlerts() {
            super("chat_alerts", "Chat Alerts", ModuleCategory.SERVER,
                    "Plays a sound when chat mentions your name, a keyword or a private message.");
            ChatHooks.listen(this::onMessage);
        }

        private void onMessage(String text) {
            if (!enabled() || mc.player == null) return;
            String low = text.toLowerCase(Locale.ROOT);
            boolean hit = false;
            if (ownName.on() && low.contains(mc.player.getName().getString().toLowerCase(Locale.ROOT))) hit = true;
            if (!hit) for (String w : csv(words.get())) if (low.contains(w)) hit = true;
            if (!hit && whisper.on() && (low.contains(" whispers") || low.contains(" whispers to you") || low.startsWith("from ")
                    || low.contains("[msg]") || low.contains(" -> me]"))) hit = true;
            if (!hit) return;
            if (sound.on()) Notifier.sound(Notifier.SOUND_PING, 0.9f, 1.4f);
            if (echo.on()) Notifier.chat("Chat alert: " + text);
        }
    }

    // ================================================================== Chat Filter
    static final class ChatFilter extends Module {
        final Setting.Text blocked = text("blocked", "Hide messages containing (comma list)", "", 200);
        final Setting.Bool joinLeave = bool("joinleave", "Hide join / leave messages", false);
        final Setting.Bool deaths = bool("deaths", "Hide death messages", false);

        ChatFilter() {
            super("chat_filter", "Chat Filter", ModuleCategory.SERVER, "Hides spam, join/leave lines and death messages locally.");
            ChatHooks.filter(this::keep);
        }

        private boolean keep(String text) {
            if (!enabled()) return true;
            String low = text.toLowerCase(Locale.ROOT);
            if (joinLeave.on() && (low.endsWith(" joined the game") || low.endsWith(" left the game"))) return false;
            if (deaths.on() && (low.contains(" was slain by ") || low.contains(" was shot by ") || low.contains(" fell from ")
                    || low.contains(" burned to death") || low.contains(" drowned") || low.contains(" blew up")
                    || low.contains(" hit the ground too hard") || low.contains(" died") || low.contains(" was killed"))) return false;
            for (String w : csv(blocked.get())) if (low.contains(w)) return false;
            return true;
        }
    }

    // ================================================================== Item Counter HUD
    static final class ItemCounter extends HudModule {
        final Setting.Bool totems = bool("totems", "Totems of Undying", true);
        final Setting.Bool crystals = bool("crystals", "End crystals", true);
        final Setting.Bool pearls = bool("pearls", "Ender pearls", true);
        final Setting.Bool xp = bool("xp", "Experience bottles", false);
        final Setting.Bool gapples = bool("gapples", "Golden apples", true);
        final Setting.Bool rockets = bool("rockets", "Firework rockets", true);
        final Setting.Bool obsidian = bool("obsidian", "Obsidian", false);
        final Setting.Mode layout = mode("layout", "Layout", "Vertical", "Vertical", "Horizontal");
        final Setting.Num opacity = num("opacity", "Background", 0.7, 0.0, 1.0, 0.05);

        ItemCounter() {
            super("item_counter", "Item Counter", "Shows how many totems, crystals, pearls and other key items you carry.", 6, 140);
        }

        private int count(Item item) {
            ClientPlayerEntity p = mc.player;
            if (p == null) return 0;
            int n = p.getOffHandStack().isOf(item) ? p.getOffHandStack().getCount() : 0;
            for (int i = 0; i < 36; i++) {
                ItemStack s = p.getInventory().getStack(i);
                if (s.isOf(item)) n += s.getCount();
            }
            return n;
        }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            List<Item> list = new ArrayList<Item>();
            if (totems.on()) list.add(Items.TOTEM_OF_UNDYING);
            if (crystals.on()) list.add(Items.END_CRYSTAL);
            if (pearls.on()) list.add(Items.ENDER_PEARL);
            if (gapples.on()) list.add(Items.GOLDEN_APPLE);
            if (rockets.on()) list.add(Items.FIREWORK_ROCKET);
            if (xp.on()) list.add(Items.EXPERIENCE_BOTTLE);
            if (obsidian.on()) list.add(Items.OBSIDIAN);
            if (list.isEmpty()) {
                boxW = 30;
                boxH = 14;
                return;
            }
            boolean horizontal = layout.is("Horizontal");
            int cell = 34;
            boxW = horizontal ? list.size() * cell + 4 : 40;
            boxH = horizontal ? 22 : list.size() * 18 + 4;
            ClientModules.panel(c, x(), y(), boxW, boxH, (float) opacity.d());
            for (int i = 0; i < list.size(); i++) {
                int ix = horizontal ? x() + 5 + i * cell : x() + 6;
                int iy = horizontal ? y() + 3 : y() + 2 + i * 18;
                c.drawItem(new ItemStack(list.get(i)), ix, iy);
                int n = count(list.get(i));
                int col = n == 0 ? Theme.BAD : Theme.TEXT;
                c.drawText(mc.textRenderer, String.valueOf(n), ix + 17, iy + 4, col, true);
            }
        }
    }

    // ================================================================== Nearby Players HUD
    static final class NearbyPlayers extends HudModule {
        final Setting.Num range = num("range", "Range", 128.0, 16.0, 512.0, 8.0, " blocks");
        final Setting.Num max = num("max", "Max entries", 6.0, 1.0, 15.0, 1.0);
        final Setting.Bool health = bool("health", "Show health", true);
        final Setting.Bool distance = bool("distance", "Show distance", true);
        final Setting.Bool direction = bool("direction", "Show direction", true);
        final Setting.Bool friends = bool("friends", "Include friends", true);
        final Setting.Num opacity = num("opacity", "Background", 0.75, 0.0, 1.0, 0.05);

        NearbyPlayers() {
            super("nearby_players", "Nearby Players", "Lists players around you with distance, direction and health.", 6, 90);
        }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            List<String> lines = new ArrayList<String>();
            List<Integer> colors = new ArrayList<Integer>();
            ClientPlayerEntity p = mc.player;
            if (p != null && mc.world != null) {
                List<AbstractClientPlayerEntity> near = new ArrayList<AbstractClientPlayerEntity>();
                double r2 = range.d() * range.d();
                for (AbstractClientPlayerEntity o : mc.world.getPlayers()) {
                    if (o == p || p.squaredDistanceTo(o) > r2) continue;
                    if (!friends.on() && Friends.is(o.getName().getString())) continue;
                    near.add(o);
                }
                final ClientPlayerEntity me = p;
                near.sort((a, b) -> Double.compare(me.squaredDistanceTo(a), me.squaredDistanceTo(b)));
                Entity cam = mc.getCameraEntity() != null ? mc.getCameraEntity() : p;
                for (int i = 0; i < near.size() && i < max.i(); i++) {
                    AbstractClientPlayerEntity o = near.get(i);
                    StringBuilder sb = new StringBuilder(o.getName().getString());
                    if (distance.on()) sb.append("  ").append(Math.round(Math.sqrt(p.squaredDistanceTo(o)))).append("m");
                    if (direction.on()) sb.append(" ").append(BaseHuntModules.relativeDirection(cam.getYaw(), o.getX() - p.getX(), o.getZ() - p.getZ()));
                    if (health.on()) sb.append("  ").append(Math.round(o.getHealth() + o.getAbsorptionAmount())).append("hp");
                    lines.add(sb.toString());
                    colors.add(Friends.is(o.getName().getString()) ? Theme.GOOD : Theme.TEXT);
                }
            } else if (editing) {
                lines.add("Player  24m ^  20hp");
                colors.add(Theme.TEXT);
            }
            if (lines.isEmpty()) {
                boxW = 70;
                boxH = 14;
                if (editing) c.drawText(mc.textRenderer, "Nearby Players", x() + 4, y() + 3, Theme.MUTED, true);
                return;
            }
            int w = 40;
            for (String s : lines) w = Math.max(w, mc.textRenderer.getWidth(s));
            boxW = w + 12;
            boxH = lines.size() * 11 + 5;
            ClientModules.panel(c, x(), y(), boxW, boxH, (float) opacity.d());
            int ty = y() + 4;
            for (int i = 0; i < lines.size(); i++) {
                c.drawText(mc.textRenderer, lines.get(i), x() + 7, ty, colors.get(i), true);
                ty += 11;
            }
        }
    }
}
