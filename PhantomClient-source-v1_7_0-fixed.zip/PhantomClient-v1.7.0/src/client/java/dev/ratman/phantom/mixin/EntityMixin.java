package dev.ratman.phantom.mixin;

import dev.ratman.phantom.modules.RenderModules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Keeps the real player's body rotation independent from Free Look / Freecam camera rotation. */
@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "changeLookDirection(DD)V", at = @At("HEAD"), cancellable = true)
    private void phantom$routeMouseLook(double cursorDeltaX, double cursorDeltaY, CallbackInfo ci) {
        if ((Object) this != MinecraftClient.getInstance().player) return;
        if (RenderModules.redirectLook((Entity) (Object) this, cursorDeltaX, cursorDeltaY)) {
            ci.cancel();
        }
    }
}
