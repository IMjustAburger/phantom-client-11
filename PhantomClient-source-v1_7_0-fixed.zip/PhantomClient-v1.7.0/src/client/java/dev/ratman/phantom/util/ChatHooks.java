package dev.ratman.phantom.util;

import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 * One registration point for incoming game/system chat messages. Modules add listeners (read-only
 * observers) or filters (return false to hide a message). Public player chat on servers that sign
 * messages arrives through a different event and is not covered here.
 */
public final class ChatHooks {
    private static final List<Consumer<String>> LISTENERS = new ArrayList<Consumer<String>>();
    private static final List<Predicate<String>> FILTERS = new ArrayList<Predicate<String>>();
    private static boolean registered;

    private ChatHooks() {}

    public static void init() {
        if (registered) return;
        registered = true;
        ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) -> {
            if (overlay) return true;
            String text = message.getString();
            for (Predicate<String> f : FILTERS) {
                try {
                    if (!f.test(text)) return false;
                } catch (RuntimeException ignored) {
                    // a faulty filter must never swallow chat
                }
            }
            return true;
        });
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (overlay) return;
            String text = message.getString();
            for (Consumer<String> l : LISTENERS) {
                try {
                    l.accept(text);
                } catch (RuntimeException ignored) {
                    // listener errors are isolated from the game
                }
            }
        });
    }

    public static void listen(Consumer<String> listener) { LISTENERS.add(listener); }

    /** Adds a filter: return true to keep the message, false to hide it. */
    public static void filter(Predicate<String> filter) { FILTERS.add(filter); }

    /** Unused import guard for Text in case of future overlay handling. */
    static Text noop() { return null; }
}
