package dev.ratman.phantom.gui;

import dev.ratman.phantom.config.ConfigStore;
import dev.ratman.phantom.module.HudModule;
import dev.ratman.phantom.module.Module;
import dev.ratman.phantom.module.ModuleCategory;
import dev.ratman.phantom.module.ModuleManager;
import dev.ratman.phantom.setting.Setting;
import dev.ratman.phantom.util.Draw;
import dev.ratman.phantom.util.Friends;
import dev.ratman.phantom.util.Theme;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Phantom ClickGUI: floating, draggable category panels (Modules view) plus HUD editor, Friends,
 * Theme and Config (profile manager) views, with a bottom navigation pill.
 */
public final class ClickGui extends GuiBase {
    private enum View {
        MODULES("Modules"), HUD("HUD"), WAYPOINTS("Waypoints"), FRIENDS("Friends"), THEME("Theme"), CONFIG("Config");

        final String label;

        View(String label) { this.label = label; }
    }


    private static View lastView = View.MODULES;
    private View view = lastView;

    private static final class Panel {
        final String id;
        final ModuleCategory cat;
        float scroll;
        int rx, ry, rw, rh;

        Panel(String id, ModuleCategory cat) {
            this.id = id;
            this.cat = cat;
        }
    }

    private final List<Panel> panels = new ArrayList<Panel>();
    private final TextBox search = new TextBox(32);
    private final Set<Module> expanded = new HashSet<Module>();
    private final Set<Object> openColors = new HashSet<Object>();
    private Module bindModule;
    private Setting.KeyBind bindSetting;
    private Module hoverModule;
    private float openAnim;
    private float navX = -1f;
    private final long openedAt = System.currentTimeMillis();

    // Waypoints view state
    private final TextBox waypointName = new TextBox(24);
    private int wpScroll;
    private String wpStatus = "";

    // Friends view state
    private final TextBox friendInput = new TextBox(16);
    private int friendScroll;
    private String friendStatus = "";

    // Config view state
    private final TextBox configName = new TextBox(24);
    private String selectedProfile = ConfigStore.active();
    private String cfgStatus = "";
    private boolean cfgGood = true;
    private long cfgStatusUntil;
    private String confirmDelete = "";
    private long confirmUntil;
    private int cfgScroll;

    // Theme view state
    private boolean themePickerOpen;

    public ClickGui() {
        super("Phantom Client");
        for (ModuleCategory cat : ModuleCategory.values()) panels.add(new Panel(cat.name(), cat));
        panels.add(new Panel("enabled", null));
        panels.add(new Panel("search", null));
        search.placeholder = "Search modules...";
        friendInput.placeholder = "Player name";
        waypointName.placeholder = "Waypoint name (optional)";
        configName.placeholder = "Config name";
    }

    // ------------------------------------------------------------------ lifecycle
    @Override
    protected void init() {
        if (Theme.legacyLayout) {
            // Profile saved before panel sizes existed: lay the (now smaller) panels out again once.
            GuiState.clear();
            Theme.legacyLayout = false;
            ConfigStore.markDirty();
        }
        arrangePanels();
    }

    /** Gives every panel that has no saved position a spot in a tidy grid. */
    private void arrangePanels() {
        int pw = Theme.panelWidth;
        // one column on the right is kept free for the Enabled quick panel
        int perRow = Math.max(1, (this.width - 12) / (pw + 6) - 1);
        int top = headerH() + 22 + 14;
        int rowStep = Theme.panelMaxHeight + headerH() + 10;
        int categories = 0;
        for (Panel p : panels) if (p.cat != null) categories++;
        int rows = Math.max(1, (categories + perRow - 1) / perRow);
        // Small screens: shrink the rows so every panel starts on screen (they scroll internally).
        int available = this.height - top - 28;
        if (rows > 1 && rowStep * rows > available) rowStep = Math.max(headerH() + 50, available / rows);
        final int fitH = Math.max(50, rowStep - headerH() - 8);
        int index = 0;
        for (Panel p : panels) {
            GuiState.PanelState st = GuiState.panel(p.id);
            if (st.x != Integer.MIN_VALUE) {
                if (p.cat != null) index++;
                continue;
            }
            if (p.cat == null) {
                st.x = p.id.equals("enabled") ? Math.max(0, this.width - pw - 6) : Math.max(0, (this.width - pw) / 2);
                st.y = 6;
            } else {
                int col = index % perRow;
                int row = index / perRow;
                st.x = 6 + col * (pw + 6);
                st.y = top + row * rowStep;
                if (fitH < Theme.panelMaxHeight) st.h = fitH;
                index++;
            }
        }
    }

    private void resetLayout() {
        GuiState.clear();
        arrangePanels();
        ConfigStore.markDirty();
    }

    @Override
    public void removed() { ConfigStore.flush(); }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        // drawn in render()
    }

    private void setView(View v) {
        view = v;
        lastView = v;
        focused = null;
        bindModule = null;
        bindSetting = null;
    }

    // ------------------------------------------------------------------ render
    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        beginFrame(mx, my);
        openAnim = Draw.approach(openAnim, 1f, 1f - (float) Math.exp(-dt * 14f * Theme.animSpeed));
        hoverModule = null;
        c.fillGradient(0, 0, this.width, this.height, Draw.alpha(0xFF05030A, 0.55f * openAnim), Draw.alpha(0xFF14082A, 0.74f * openAnim));

        if (view == View.MODULES) renderModulesView(c);
        else if (view == View.HUD) renderHudView(c);
        else if (view == View.WAYPOINTS) renderWaypointsView(c);
        else if (view == View.FRIENDS) renderFriendsView(c);
        else if (view == View.THEME) renderThemeView(c);
        else renderConfigView(c);

        renderNav(c);
        if (view == View.MODULES && hoverModule != null) renderTooltip(c, hoverModule);
    }

    // ------------------------------------------------------------------ nav
    private void renderNav(DrawContext c) {
        View[] views = View.values();
        int tabW = 58;
        int total = views.length * tabW + 6;
        int x = (this.width - total) / 2;
        int y = this.height - 22;
        Draw.rrectBorder(c, x, y, total, 17, 8, Draw.alpha(0xFF0B0713, 0.96f), Theme.BORDER);
        int idx = view.ordinal();
        float target = x + 3 + idx * tabW;
        navX = navX < 0 ? target : navX + (target - navX) * (1f - (float) Math.exp(-dt * 18f * Theme.animSpeed));
        Draw.rrect(c, Math.round(navX), y + 2, tabW, 13, 6, Theme.accent());
        for (int i = 0; i < views.length; i++) {
            final View v = views[i];
            int tx = x + 3 + i * tabW;
            Draw.textCentered(c, this.textRenderer, v.label, tx + tabW / 2, y + 5, i == idx ? 0xFF0B0713 : Theme.MUTED);
            hit(tx, y, tabW, 17, new Runnable() {
                @Override public void run() { setView(v); }
            }, null, null);
        }
    }

    // ------------------------------------------------------------------ modules view
    private int rowH() { return Theme.rowHeight; }

    private int headerH() { return Theme.rowHeight + 6; }

    private int textY(int h) { return (h - 8) / 2 + 1; }

    private int panelW(GuiState.PanelState st) { return st.w > 0 ? st.w : Theme.panelWidth; }

    private int panelMaxH(GuiState.PanelState st) { return st.h > 0 ? st.h : Theme.panelMaxHeight; }

    private void renderModulesView(DrawContext c) {
        int slide = Math.round((1f - openAnim) * -12f);
        for (Panel p : new ArrayList<Panel>(panels)) renderPanel(c, p, slide);
    }

    private List<Module> visibleModules(Panel p) {
        String q = search.text.trim().toLowerCase(Locale.ROOT);
        List<Module> out = new ArrayList<Module>();
        for (Module m : ModuleManager.inCategory(p.cat)) {
            if (q.isEmpty() || m.name.toLowerCase(Locale.ROOT).contains(q) || m.id.contains(q)
                    || (q.length() >= 3 && m.description.toLowerCase(Locale.ROOT).contains(q))) out.add(m);
        }
        java.util.Collections.sort(out, new java.util.Comparator<Module>() {
            @Override public int compare(Module a, Module b) { return a.name.compareToIgnoreCase(b.name); }
        });
        return out;
    }

    private void bringToFront(Panel p) {
        panels.remove(p);
        panels.add(p);
    }

    private void drawHeader(DrawContext c, String title, int x, int y, int pw, boolean open) {
        int hh = headerH();
        c.fillGradient(x + 1, y + 1, x + pw - 1, y + hh, Draw.alpha(Theme.accent(), 0.26f), Draw.alpha(Theme.accent(), 0.03f));
        c.fill(x + 1, y + hh - 1, x + pw - 1, y + hh, Draw.alpha(Theme.accent(), open ? 0.55f : 0.25f));
        Draw.rrect(c, x + 7, y + (hh - 5) / 2, 5, 5, 2, Theme.accent());
        Draw.text(c, this.textRenderer, Draw.fit(this.textRenderer, title, pw - 50), x + 17, y + textY(hh), Theme.TEXT);
    }

    private void renderPanel(DrawContext c, final Panel p, int slide) {
        final GuiState.PanelState st = GuiState.panel(p.id);
        if (st.x == Integer.MIN_VALUE) return;
        final int pw = panelW(st);
        final int hh = headerH();
        final int rh = rowH();
        st.x = Math.max(0, Math.min(this.width - pw, st.x));
        st.y = Math.max(0, Math.min(this.height - hh - 26, st.y));
        final int x = st.x;
        final int y = st.y + slide;

        if (p.cat == null) {
            if (p.id.equals("enabled")) renderEnabledPanel(c, p, st, x, y, pw);
            else renderSearchPanel(c, p, st, x, y, pw);
            return;
        }
        List<Module> mods = visibleModules(p);
        boolean searching = !search.text.trim().isEmpty();
        if (mods.isEmpty()) return;

        float open = anim(p.id + "#open", (st.collapsed && !searching) ? 0f : 1f);
        int content = 0;
        int[] shown = new int[mods.size()];
        for (int i = 0; i < mods.size(); i++) {
            Module m = mods.get(i);
            float ea = anim(m.id + "#exp", expanded.contains(m) ? 1f : 0f);
            shown[i] = Math.round(layoutSettings(null, m, 0, 0, pw - 14, false) * ea);
            content += rh + shown[i];
        }
        int fullBody = content + 4;
        int maxH = panelMaxH(st);
        int bodyH = Math.min(maxH, fullBody);
        int visible = Math.round(bodyH * open);
        int maxScroll = Math.max(0, fullBody - maxH);
        p.scroll = Math.max(0, Math.min(maxScroll, p.scroll));
        p.rx = x;
        p.ry = y;
        p.rw = pw;
        p.rh = hh + visible;

        card(c, x, y, pw, hh + visible);
        drawHeader(c, p.cat.label(), x, y, pw, open > 0.5f);
        int enabledCount = 0;
        for (Module m : ModuleManager.inCategory(p.cat)) if (m.enabled() && !m.alwaysOn) enabledCount++;
        if (enabledCount > 0) Draw.textRight(c, this.textRenderer, String.valueOf(enabledCount), x + pw - 18, y + textY(hh), Theme.MUTED);
        Draw.chevron(c, x + pw - 14, y + (hh - 4) / 2, Theme.MUTED, open > 0.5f);

        // consume everything inside the panel so clicks do not fall through to panels below
        hit(x, y, pw, hh + visible, new Runnable() {
            @Override public void run() { bringToFront(p); }
        }, null, null);
        final double[] grab = new double[]{Double.NaN, 0};
        hit(x, y, pw - 22, hh, new Runnable() {
            @Override public void run() {
                bringToFront(p);
                grab[0] = Double.NaN;
            }
        }, new Runnable() {
            @Override public void run() {
                // right-click the header: back to the default size
                st.w = 0;
                st.h = 0;
                ConfigStore.markDirty();
            }
        }, new Drag() {
            @Override public void to(double mxx, double myy) {
                if (Double.isNaN(grab[0])) {
                    grab[0] = mxx - st.x;
                    grab[1] = myy - st.y;
                }
                st.x = (int) Math.round(mxx - grab[0]);
                st.y = (int) Math.round(myy - grab[1]);
                ConfigStore.markDirty();
            }
        });
        hit(x + pw - 22, y, 22, hh, new Runnable() {
            @Override public void run() {
                st.collapsed = !st.collapsed;
                ConfigStore.markDirty();
            }
        }, null, null);

        if (visible > 0 && pushClip(c, x + 1, y + hh, pw - 2, visible)) {
            int yy = y + hh + 2 - Math.round(p.scroll);
            for (int i = 0; i < mods.size(); i++) {
                Module m = mods.get(i);
                drawModuleRow(c, m, x + 3, yy, pw - 6);
                if (shown[i] > 0) {
                    int sy = yy + rh - 1;
                    if (pushClip(c, x + 3, sy, pw - 6, shown[i] + 1)) {
                        c.fill(x + 3, sy, x + pw - 3, sy + shown[i] + 1, 0xFF0D0919);
                        layoutSettings(c, m, x + 7, sy + 1, pw - 14, true);
                        popClip(c);
                    }
                }
                yy += rh + shown[i];
            }
            popClip(c);
        }
        if (maxScroll > 0 && visible > 8) {
            int trackH = visible - 6;
            int thumbH = Math.max(10, Math.round(trackH * (maxH / (float) fullBody)));
            int thumbY = y + hh + 3 + Math.round((trackH - thumbH) * (p.scroll / maxScroll));
            c.fill(x + pw - 3, thumbY, x + pw - 1, thumbY + thumbH, Draw.alpha(Theme.accent(), 0.6f));
        }

        // resize grip (bottom-right): drag to change this panel's width and maximum height
        if (visible > 14) {
            final int gx = x + pw - 10;
            final int gy = y + hh + visible - 10;
            int gc = hovered(gx, gy, 10, 10) ? Theme.accent() : Theme.DIM;
            c.fill(gx + 7, gy + 3, gx + 8, gy + 4, gc);
            c.fill(gx + 5, gy + 5, gx + 6, gy + 6, gc);
            c.fill(gx + 7, gy + 5, gx + 8, gy + 6, gc);
            c.fill(gx + 3, gy + 7, gx + 4, gy + 8, gc);
            c.fill(gx + 5, gy + 7, gx + 6, gy + 8, gc);
            c.fill(gx + 7, gy + 7, gx + 8, gy + 8, gc);
            hit(gx, gy, 10, 10, null, null, new Drag() {
                @Override public void to(double mxx, double myy) {
                    st.w = (int) Math.max(96, Math.min(300, Math.round(mxx - st.x + 3)));
                    st.h = (int) Math.max(60, Math.min(heightLimit(), Math.round(myy - (st.y + hh) + 3)));
                    ConfigStore.markDirty();
                }
            });
        }
    }

    /** Quick list of everything that is switched on, so any module can be turned off without hunting for it. */
    private void renderEnabledPanel(DrawContext c, final Panel p, final GuiState.PanelState st, int x, int y, int pw) {
        int hh = headerH();
        int rh = rowH();
        List<Module> on = new ArrayList<Module>();
        for (Module m : ModuleManager.all()) if (m.enabled() && !m.alwaysOn) on.add(m);
        java.util.Collections.sort(on, new java.util.Comparator<Module>() {
            @Override public int compare(Module a, Module b) { return a.name.compareToIgnoreCase(b.name); }
        });
        int shown = Math.min(on.size(), Math.max(3, (panelMaxH(st) - 4) / rh));
        int body = Math.max(1, shown) * rh + 4 + (on.size() > shown ? 11 : 0);
        int h = hh + body;
        p.rx = x;
        p.ry = y;
        p.rw = pw;
        p.rh = h;
        card(c, x, y, pw, h);
        drawHeader(c, "Enabled (" + on.size() + ")", x, y, pw, true);
        hit(x, y, pw, h, new Runnable() {
            @Override public void run() { bringToFront(p); }
        }, null, null);
        final double[] grab = new double[]{Double.NaN, 0};
        hit(x, y, pw, hh, new Runnable() {
            @Override public void run() { grab[0] = Double.NaN; }
        }, null, new Drag() {
            @Override public void to(double mxx, double myy) {
                if (Double.isNaN(grab[0])) {
                    grab[0] = mxx - st.x;
                    grab[1] = myy - st.y;
                }
                st.x = (int) Math.round(mxx - grab[0]);
                st.y = (int) Math.round(myy - grab[1]);
                ConfigStore.markDirty();
            }
        });
        int yy = y + hh + 2;
        if (on.isEmpty()) {
            Draw.text(c, this.textRenderer, "Nothing enabled", x + 8, yy + textY(rh), Theme.DIM);
            return;
        }
        for (int i = 0; i < shown; i++) {
            final Module m = on.get(i);
            boolean hov = hovered(x + 3, yy, pw - 6, rh - 1);
            if (hov) hoverModule = m;
            Draw.rrect(c, x + 3, yy, pw - 6, rh - 1, Math.max(1, Theme.cornerRadius - 1), hov ? Draw.mul(Theme.accent(), 0.65f) : Draw.mul(Theme.accent(), 0.45f));
            Draw.text(c, this.textRenderer, Draw.fit(this.textRenderer, m.name, pw - 24), x + 8, yy + textY(rh - 1), 0xFFFFFFFF);
            Draw.textRight(c, this.textRenderer, "x", x + pw - 9, yy + textY(rh - 1), hov ? Theme.BAD : Theme.MUTED);
            hit(x + 3, yy, pw - 6, rh - 1, new Runnable() {
                @Override public void run() { m.toggle(); }
            }, null, null);
            yy += rh;
        }
        if (on.size() > shown) Draw.text(c, this.textRenderer, "+" + (on.size() - shown) + " more", x + 8, yy + 1, Theme.DIM);
    }

    // ------------------------------------------------------------------ waypoints view
    private void renderWaypointsView(DrawContext c) {
        int w = Math.min(430, this.width - 16);
        int h = this.height - 40;
        int x = (this.width - w) / 2;
        int y = 10;
        card(c, x, y, w, h);
        hit(x, y, w, h, null, null, null);
        List<dev.ratman.phantom.world.WaypointStore.Waypoint> list = dev.ratman.phantom.world.WaypointStore.list();
        Draw.text(c, this.textRenderer, "Waypoints (" + list.size() + ")", x + 10, y + 8, Theme.TEXT);
        String dimNow = dev.ratman.phantom.world.WaypointStore.currentDimension();
        Draw.textRight(c, this.textRenderer, "saved per server  -  you are in " + dimNow, x + w - 10, y + 8, Theme.DIM);
        textBox(c, x + 10, y + 22, w - 100, 15, waypointName);
        button(c, x + w - 82, y + 22, 72, 15, "Add here", this.client != null && this.client.player != null, Theme.accent(), new Runnable() {
            @Override public void run() { addWaypointHere(); }
        });
        if (!wpStatus.isEmpty()) Draw.text(c, this.textRenderer, wpStatus, x + 10, y + 40, Theme.MUTED);

        int top = y + 54;
        int rowH = 18;
        int rows = Math.max(1, (y + h - 10 - top) / rowH);
        wpScroll = Math.max(0, Math.min(Math.max(0, list.size() - rows), wpScroll));
        net.minecraft.client.network.ClientPlayerEntity me = this.client == null ? null : this.client.player;
        if (pushClip(c, x + 6, top, w - 12, rows * rowH)) {
            int yy = top;
            for (int i = wpScroll; i < list.size() && i < wpScroll + rows; i++) {
                final dev.ratman.phantom.world.WaypointStore.Waypoint wp = list.get(i);
                Draw.rrect(c, x + 10, yy, w - 20, rowH - 2, 3, Theme.ROW);
                final int sx = x + 14;
                Draw.rrectBorder(c, sx, yy + 4, 9, 9, 2, wp.color | 0xFF000000, Theme.BORDER);
                hit(sx, yy + 3, 11, 11, new Runnable() {
                    @Override public void run() {
                        int idx = 0;
                        for (int k = 0; k < Theme.PRESETS.length; k++) if ((Theme.PRESETS[k] | 0xFF000000) == (wp.color | 0xFF000000)) idx = k;
                        wp.color = Theme.PRESETS[(idx + 1) % Theme.PRESETS.length];
                        dev.ratman.phantom.world.WaypointStore.save();
                    }
                }, null, null);
                Draw.text(c, this.textRenderer, Draw.fit(this.textRenderer, wp.name, 110), x + 28, yy + 5, wp.visible ? Theme.TEXT : Theme.DIM);
                String where = wp.x + " " + wp.y + " " + wp.z + " " + (wp.dimension.equals("overworld") ? "OW" : wp.dimension.equals("the_nether") ? "N" : "E");
                Draw.text(c, this.textRenderer, where, x + 144, yy + 5, Theme.MUTED);
                if (me != null) {
                    double[] lc = dev.ratman.phantom.world.WaypointStore.localCoords(wp, dimNow);
                    if (lc != null) {
                        long d = Math.round(Math.sqrt(Math.pow(lc[0] - me.getX(), 2) + Math.pow(lc[2] - me.getZ(), 2)));
                        Draw.textRight(c, this.textRenderer, d + "m", x + w - 118, yy + 5, Theme.accent());
                    }
                }
                int bx = x + w - 110;
                button(c, bx, yy + 1, 30, rowH - 4, wp.visible ? "Hide" : "Show", true, Theme.accent(), new Runnable() {
                    @Override public void run() {
                        wp.visible = !wp.visible;
                        dev.ratman.phantom.world.WaypointStore.save();
                    }
                });
                button(c, bx + 33, yy + 1, 32, rowH - 4, "Copy", true, Theme.accent(), new Runnable() {
                    @Override public void run() {
                        dev.ratman.phantom.util.Compat.clipboard(wp.x + " " + wp.y + " " + wp.z);
                        wpStatus = "Copied " + wp.name + ": " + wp.x + " " + wp.y + " " + wp.z;
                    }
                });
                button(c, bx + 68, yy + 1, 34, rowH - 4, "Del", true, Theme.BAD, new Runnable() {
                    @Override public void run() {
                        dev.ratman.phantom.world.WaypointStore.remove(wp);
                        wpStatus = "Deleted " + wp.name;
                    }
                });
                yy += rowH;
            }
            popClip(c);
        }
        if (list.isEmpty()) Draw.text(c, this.textRenderer, "No waypoints yet. Stand somewhere and press \"Add here\".", x + 14, top + 4, Theme.DIM);
    }

    private void addWaypointHere() {
        net.minecraft.client.network.ClientPlayerEntity p = this.client == null ? null : this.client.player;
        if (p == null) {
            wpStatus = "Join a world first.";
            return;
        }
        dev.ratman.phantom.world.WaypointStore.Waypoint wp = dev.ratman.phantom.world.WaypointStore.add(
                waypointName.text, p.getBlockX(), p.getBlockY(), p.getBlockZ());
        wpStatus = "Saved \"" + wp.name + "\" at " + wp.x + " " + wp.y + " " + wp.z;
        waypointName.text = "";
    }

    @Override
    protected void onEnter(TextBox box) {
        if (box == waypointName) addWaypointHere();
    }

    private int heightLimit() { return Math.max(80, this.height - headerH() - 40); }

    private void renderSearchPanel(DrawContext c, final Panel p, final GuiState.PanelState st, int x, int y, int pw) {
        int hh = headerH();
        int h = hh + 22;
        p.rx = x;
        p.ry = y;
        p.rw = pw;
        p.rh = h;
        card(c, x, y, pw, h);
        drawHeader(c, "Search", x, y, pw, true);
        hit(x, y, pw, h, new Runnable() {
            @Override public void run() { bringToFront(p); }
        }, null, null);
        final double[] grab = new double[]{Double.NaN, 0};
        hit(x, y, pw, hh, new Runnable() {
            @Override public void run() { grab[0] = Double.NaN; }
        }, null, new Drag() {
            @Override public void to(double mxx, double myy) {
                if (Double.isNaN(grab[0])) {
                    grab[0] = mxx - st.x;
                    grab[1] = myy - st.y;
                }
                st.x = (int) Math.round(mxx - grab[0]);
                st.y = (int) Math.round(myy - grab[1]);
                ConfigStore.markDirty();
            }
        });
        textBox(c, x + 5, y + hh + 3, pw - 10, 14, search);
    }

    private void drawModuleRow(DrawContext c, final Module m, int x, int y, int w) {
        int h = rowH() - 1;
        boolean hov = hovered(x, y, w, h);
        if (hov) hoverModule = m;
        float on = anim(m.id + "#on", m.enabled() && !m.alwaysOn ? 1f : 0f);
        float hv = animFromZero(m.id + "#hov", hov ? 1f : 0f);
        int base = Draw.lerp(Theme.ROW, Theme.ROW_HOVER, hv);
        int active = Draw.lerp(Draw.mul(Theme.accent(), 0.50f), Theme.accent(), hv * 0.35f);
        int bg = Draw.lerp(base, active, on);
        Draw.rrect(c, x, y, w, h, Math.max(1, Theme.cornerRadius - 1), bg);
        if (on > 0.01f) c.fill(x, y + 2, x + 2, y + h - 2, Draw.alpha(0xFFFFFFFF, 0.65f * on));
        int tc = Draw.lerp(Draw.lerp(Theme.MUTED, Theme.TEXT, hv), 0xFFFFFFFF, on);
        Draw.text(c, this.textRenderer, Draw.fit(this.textRenderer, m.name, w - 32), x + 7, y + textY(h), tc);
        boolean open = expanded.contains(m);
        if (m.keyCode() != -1) {
            String k = ModuleManager.keyName(m.keyCode());
            Draw.textRight(c, this.textRenderer, Draw.fit(this.textRenderer, k, 28), x + w - 13, y + textY(h), Draw.lerp(Theme.DIM, 0xFFE9D5FF, on));
        }
        Draw.chevron(c, x + w - 11, y + (h - 4) / 2, Draw.lerp(Theme.DIM, Theme.TEXT, Math.max(hv, on)), open);
        hit(x, y, w, h, new Runnable() {
            @Override public void run() {
                if (!m.alwaysOn) m.toggle();
                else toggleExpand(m);
            }
        }, new Runnable() {
            @Override public void run() { toggleExpand(m); }
        }, null);
        hit(x + w - 17, y, 17, h, new Runnable() {
            @Override public void run() { toggleExpand(m); }
        }, null, null);
    }

    private void toggleExpand(Module m) {
        if (!expanded.remove(m)) expanded.add(m);
    }

    // ------------------------------------------------------------------ settings layout
    /** Lays out (and draws when {@code draw}) a module's settings. Returns the total height. */
    private int layoutSettings(DrawContext c, final Module m, int x, int y, int w, boolean draw) {
        int cy = y + 2;
        if (!m.alwaysOn) {
            cy += keyRow(c, x, cy, w, draw, "Keybind", m.keyCode(), bindModule == m,
                    new Runnable() {
                        @Override public void run() {
                            bindModule = m;
                            bindSetting = null;
                        }
                    },
                    new Runnable() {
                        @Override public void run() { m.setKeyCode(-1); }
                    });
        }
        for (Setting<?> s : m.settings()) {
            if (!s.visible()) continue;
            cy += settingRow(c, s, x, cy, w, draw);
        }
        cy += resetRow(c, m, x, cy, w, draw);
        return cy + 2 - y;
    }

    private int keyRow(DrawContext c, int x, int y, int w, boolean draw, String label, int key, boolean listening,
                       Runnable start, Runnable clear) {
        int h = rowH();
        if (draw) {
            Draw.text(c, this.textRenderer, label, x + 1, y + textY(h), Theme.TEXT);
            int bw = 52;
            int bx = x + w - bw;
            int bh = h - 2;
            boolean hov = hovered(bx, y + 1, bw, bh);
            Draw.rrectBorder(c, bx, y + 1, bw, bh, 2, listening ? Draw.mul(Theme.accent(), 0.5f) : (hov ? Theme.ROW_HOVER : Theme.ROW),
                    listening ? Theme.accent() : Theme.BORDER);
            String t = listening ? "press key" : ModuleManager.keyName(key);
            Draw.textCentered(c, this.textRenderer, Draw.fit(this.textRenderer, t, bw - 4), bx + bw / 2, y + 1 + (bh - 8) / 2 + 1,
                    listening ? Theme.TEXT : Theme.MUTED);
            hit(bx, y + 1, bw, bh, start, clear, null);
        }
        return h;
    }

    private int resetRow(DrawContext c, final Module m, int x, int y, int w, boolean draw) {
        int h = rowH();
        if (draw) {
            button(c, x, y + 1, w, h - 2, "Reset settings", true, Theme.BAD, new Runnable() {
                @Override public void run() { m.resetSettings(); }
            });
        }
        return h;
    }

    private int settingRow(DrawContext c, final Setting<?> s, int x, int y, int w, boolean draw) {
        final int h = rowH();
        if (s instanceof Setting.Bool) {
            final Setting.Bool b = (Setting.Bool) s;
            if (draw) {
                Draw.text(c, this.textRenderer, Draw.fit(this.textRenderer, b.label, w - 26), x + 1, y + textY(h), Theme.TEXT);
                toggleSwitch(c, x + w - 19, y + (h - 9) / 2, b.on(), b);
                hit(x, y, w, h, new Runnable() {
                    @Override public void run() {
                        b.toggle();
                        ConfigStore.markDirty();
                    }
                }, null, null);
            }
            return h;
        }
        if (s instanceof Setting.Num) {
            final Setting.Num n = (Setting.Num) s;
            if (draw) {
                sliderCompact(c, x + 1, y + 2, w - 2, Draw.fit(this.textRenderer, n.label, w - 44), n.display(), n.ratio(),
                        new java.util.function.DoubleConsumer() {
                            @Override public void accept(double r) {
                                n.setRatio(r);
                                ConfigStore.markDirty();
                            }
                        });
            }
            return 22;
        }
        if (s instanceof Setting.Mode) {
            final Setting.Mode md = (Setting.Mode) s;
            if (draw) {
                Draw.text(c, this.textRenderer, Draw.fit(this.textRenderer, md.label, w / 2 - 2), x + 1, y + textY(h), Theme.TEXT);
                String v = "< " + md.get() + " >";
                Draw.textRight(c, this.textRenderer, Draw.fit(this.textRenderer, v, w / 2 + 6), x + w, y + textY(h), Theme.accent());
                hit(x, y, w, h, new Runnable() {
                    @Override public void run() {
                        md.cycle(1);
                        ConfigStore.markDirty();
                    }
                }, new Runnable() {
                    @Override public void run() {
                        md.cycle(-1);
                        ConfigStore.markDirty();
                    }
                }, null);
            }
            return h;
        }
        if (s instanceof Setting.Col) {
            final Setting.Col col = (Setting.Col) s;
            boolean open = openColors.contains(col);
            int pickerH = 0;
            if (open) pickerH = 12 * (col.allowAlpha ? 4 : 3) + 14 + 2;
            if (draw) {
                Draw.text(c, this.textRenderer, Draw.fit(this.textRenderer, col.label, w - 30), x + 1, y + textY(h), Theme.TEXT);
                Draw.rrectBorder(c, x + w - 24, y + (h - 10) / 2, 24, 10, 2, col.argb() | (col.allowAlpha ? 0 : 0xFF000000), open ? Theme.accent() : Theme.BORDER);
                hit(x, y, w, h, new Runnable() {
                    @Override public void run() {
                        if (!openColors.remove(col)) openColors.add(col);
                    }
                }, null, null);
                if (open) {
                    colorPicker(c, x + 2, y + h + 1, w - 6, col, new java.util.function.IntSupplier() {
                        @Override public int getAsInt() { return col.argb(); }
                    }, new java.util.function.IntConsumer() {
                        @Override public void accept(int v) { col.set(v); }
                    }, col.allowAlpha);
                }
            }
            return h + pickerH;
        }
        if (s instanceof Setting.Text) {
            final Setting.Text t = (Setting.Text) s;
            if (draw) {
                Draw.text(c, this.textRenderer, t.label, x + 1, y + 1, Theme.TEXT);
                TextBox box = textBoxFor(t);
                textBox(c, x, y + 11, w, 13, box);
            }
            return 27;
        }
        if (s instanceof Setting.KeyBind) {
            final Setting.KeyBind kb = (Setting.KeyBind) s;
            return keyRow(c, x, y, w, draw, Draw.fit(this.textRenderer, kb.label, w - 56), kb.get(), bindSetting == kb,
                    new Runnable() {
                        @Override public void run() {
                            bindSetting = kb;
                            bindModule = null;
                        }
                    },
                    new Runnable() {
                        @Override public void run() {
                            kb.set(-1);
                            ConfigStore.markDirty();
                        }
                    });
        }
        if (s instanceof Setting.Blocks) {
            final Setting.Blocks bl = (Setting.Blocks) s;
            if (draw) {
                button(c, x, y + 1, w, h - 1, Draw.fit(this.textRenderer, bl.label + " (" + bl.map().size() + ")", w - 8), true, Theme.accent(), new Runnable() {
                    @Override public void run() { client.setScreen(new BlockPickerScreen(ClickGui.this, bl)); }
                });
            }
            return h + 2;
        }
        return 0;
    }

    private final java.util.Map<Setting.Text, TextBox> textBoxes = new java.util.HashMap<Setting.Text, TextBox>();

    private TextBox textBoxFor(Setting.Text t) {
        TextBox box = textBoxes.get(t);
        if (box == null) {
            box = new TextBox(t.maxLength);
            box.text = t.get();
            textBoxes.put(t, box);
        } else if (focused != box && !box.text.equals(t.get())) {
            box.text = t.get();
        }
        return box;
    }

    @Override
    protected void onTextChanged(TextBox box) {
        for (java.util.Map.Entry<Setting.Text, TextBox> e : textBoxes.entrySet()) {
            if (e.getValue() == box) {
                e.getKey().set(box.text);
                ConfigStore.markDirty();
            }
        }
    }

    private void renderTooltip(DrawContext c, Module m) {
        if (m.description == null || m.description.isEmpty()) return;
        List<String> lines = wrap(m.description, 200);
        int w = 0;
        for (String l : lines) w = Math.max(w, this.textRenderer.getWidth(l));
        int h = lines.size() * 10 + 8;
        int x = Math.min(this.width - w - 14, mouseX + 12);
        int y = Math.min(this.height - h - 34, mouseY + 12);
        Draw.rrectBorder(c, x, y, w + 10, h, 3, 0xF20B0713, Theme.accent());
        int ty = y + 4;
        for (String l : lines) {
            Draw.text(c, this.textRenderer, l, x + 5, ty, Theme.TEXT);
            ty += 10;
        }
    }

    private List<String> wrap(String text, int maxWidth) {
        List<String> out = new ArrayList<String>();
        StringBuilder line = new StringBuilder();
        for (String word : text.split(" ")) {
            String trial = line.length() == 0 ? word : line + " " + word;
            if (this.textRenderer.getWidth(trial) > maxWidth && line.length() > 0) {
                out.add(line.toString());
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(trial);
            }
        }
        if (line.length() > 0) out.add(line.toString());
        return out;
    }

    // ------------------------------------------------------------------ HUD editor
    private final double[] hudGrab = new double[]{0, 0};

    private void renderHudView(DrawContext c) {
        List<HudModule> elements = new ArrayList<HudModule>();
        for (Module m : ModuleManager.all()) if (m instanceof HudModule) elements.add((HudModule) m);

        int lw = 170;
        int lh = 26 + elements.size() * 19 + 26;
        int lx = 10;
        int ly = 10;
        card(c, lx, ly, lw, lh);
        Draw.text(c, this.textRenderer, "HUD Elements", lx + 10, ly + 8, Theme.TEXT);
        Draw.textRight(c, this.textRenderer, "drag to move", lx + lw - 8, ly + 8, Theme.DIM);
        hit(lx, ly, lw, lh, null, null, null);
        int yy = ly + 24;
        for (final HudModule h : elements) {
            boolean hov = hovered(lx + 4, yy, lw - 8, 17);
            float on = anim(h.id + "#hudon", h.enabled() ? 1f : 0f);
            Draw.rrect(c, lx + 4, yy, lw - 8, 17, 3, Draw.lerp(hov ? Theme.ROW_HOVER : Theme.ROW, Draw.mul(Theme.accent(), 0.5f), on));
            Draw.text(c, this.textRenderer, h.name, lx + 10, yy + 5, Draw.lerp(Theme.MUTED, 0xFFFFFFFF, on));
            toggleSwitch(c, lx + lw - 28, yy + 4, h.enabled(), "hud" + h.id);
            hit(lx + 4, yy, lw - 8, 17, new Runnable() {
                @Override public void run() { h.toggle(); }
            }, null, null);
            yy += 19;
        }
        button(c, lx + 8, yy + 2, lw - 16, 16, "Reset positions", true, Theme.BAD, new Runnable() {
            @Override public void run() {
                for (HudModule h : elements) {
                    h.settings().get(0).reset();
                    h.settings().get(1).reset();
                }
                ConfigStore.markDirty();
            }
        });

        for (final HudModule h : elements) {
            if (!h.enabled()) continue;
            h.draw(c, 0f, true);
            int bx = h.x();
            int by = h.y();
            int bw = Math.max(10, h.boxW);
            int bh = Math.max(10, h.boxH);
            boolean hov = Draw.inside(mouseX, mouseY, bx, by, bw, bh);
            int oc = hov ? Theme.accent() : Draw.alpha(Theme.accent(), 0.45f);
            c.fill(bx - 1, by - 1, bx + bw + 1, by, oc);
            c.fill(bx - 1, by + bh, bx + bw + 1, by + bh + 1, oc);
            c.fill(bx - 1, by, bx, by + bh, oc);
            c.fill(bx + bw, by, bx + bw + 1, by + bh, oc);
            final double[] grab = new double[]{Double.NaN, 0};
            hit(bx, by, bw, bh, new Runnable() {
                @Override public void run() { grab[0] = Double.NaN; }
            }, null, new Drag() {
                @Override public void to(double mxx, double myy) {
                    if (Double.isNaN(grab[0])) {
                        grab[0] = mxx - h.x();
                        grab[1] = myy - h.y();
                    }
                    int nx = (int) Math.round(mxx - grab[0]);
                    int ny = (int) Math.round(myy - grab[1]);
                    nx = Math.max(0, Math.min(width - Math.max(10, h.boxW), nx));
                    ny = Math.max(0, Math.min(height - Math.max(10, h.boxH), ny));
                    h.moveTo(nx, ny);
                    ConfigStore.markDirty();
                }
            });
        }
    }

    // ------------------------------------------------------------------ friends view
    private void renderFriendsView(DrawContext c) {
        int w = 320;
        int h = this.height - 80;
        int x = (this.width - w) / 2;
        int y = 28;
        card(c, x, y, w, h);
        hit(x, y, w, h, null, null, null);
        Draw.text(c, this.textRenderer, "Friends", x + 12, y + 10, Theme.TEXT);
        Draw.textRight(c, this.textRenderer, "never targeted by combat modules", x + w - 12, y + 10, Theme.DIM);
        textBox(c, x + 12, y + 26, w - 90, 16, friendInput);
        button(c, x + w - 72, y + 26, 60, 16, "Add", true, Theme.accent(), new Runnable() {
            @Override public void run() { addFriendFromInput(); }
        });
        if (!friendStatus.isEmpty()) Draw.text(c, this.textRenderer, friendStatus, x + 12, y + 46, Theme.MUTED);

        int yy = y + 62;
        Draw.text(c, this.textRenderer, "Nearby players", x + 12, yy, Theme.MUTED);
        yy += 12;
        int shownNearby = 0;
        if (this.client != null && this.client.world != null) {
            for (final AbstractClientPlayerEntity p : this.client.world.getPlayers()) {
                if (p == this.client.player) continue;
                final String name = p.getName().getString();
                if (Friends.is(name)) continue;
                if (shownNearby >= 5) break;
                Draw.rrect(c, x + 12, yy, w - 24, 16, 3, Theme.ROW);
                Draw.text(c, this.textRenderer, name, x + 18, yy + 4, Theme.TEXT);
                button(c, x + w - 60, yy + 1, 42, 14, "+ Add", true, Theme.GOOD, new Runnable() {
                    @Override public void run() {
                        Friends.add(name);
                        friendStatus = "Added " + name;
                    }
                });
                yy += 18;
                shownNearby++;
            }
        }
        if (shownNearby == 0) {
            Draw.text(c, this.textRenderer, "No other players nearby", x + 18, yy + 2, Theme.DIM);
            yy += 14;
        }
        yy += 8;
        List<String> friends = Friends.list();
        Draw.text(c, this.textRenderer, "Friends (" + friends.size() + ")", x + 12, yy, Theme.MUTED);
        yy += 12;
        int rows = Math.max(1, (y + h - 10 - yy) / 18);
        friendScroll = Math.max(0, Math.min(Math.max(0, friends.size() - rows), friendScroll));
        if (pushClip(c, x + 8, yy, w - 16, rows * 18)) {
            for (int i = friendScroll; i < friends.size() && i < friendScroll + rows; i++) {
                final String name = friends.get(i);
                Draw.rrect(c, x + 12, yy, w - 24, 16, 3, Theme.ROW);
                Draw.text(c, this.textRenderer, name, x + 18, yy + 4, Theme.GOOD);
                button(c, x + w - 60, yy + 1, 42, 14, "Remove", true, Theme.BAD, new Runnable() {
                    @Override public void run() {
                        Friends.remove(name);
                        friendStatus = "Removed " + name;
                    }
                });
                yy += 18;
            }
            popClip(c);
        }
        if (friends.isEmpty()) Draw.text(c, this.textRenderer, "Your friends list is empty", x + 18, yy + 2, Theme.DIM);
    }

    private void addFriendFromInput() {
        String n = friendInput.text.trim();
        if (Friends.add(n)) {
            friendStatus = "Added " + n;
            friendInput.text = "";
        } else {
            friendStatus = "Enter a valid player name (letters, numbers, _)";
        }
    }

    // ------------------------------------------------------------------ theme view
    private void renderThemeView(DrawContext c) {
        int w = Math.min(470, this.width - 16);
        int x = (this.width - w) / 2;
        int y = 10;
        int h = Math.min(this.height - 40, 292);
        card(c, x, y, w, h);
        hit(x, y, w, h, null, null, null);
        Draw.text(c, this.textRenderer, "Theme & Layout", x + 10, y + 8, Theme.TEXT);
        int colW = (w - 30) / 2;
        int lx = x + 10;
        int rx = x + 20 + colW;

        // ---- left column: accent
        int cy = y + 24;
        Draw.text(c, this.textRenderer, "Accent preset", lx, cy, Theme.MUTED);
        cy += 11;
        int per = 4;
        int sw = (colW - (per - 1) * 4) / per;
        for (int i = 0; i < Theme.PRESETS.length; i++) {
            final int idx = i;
            int sx = lx + (i % per) * (sw + 4);
            int sy = cy + (i / per) * 20;
            boolean sel = !Theme.useCustom && !Theme.rainbow && Theme.preset == i;
            Draw.rrectBorder(c, sx, sy, sw, 16, 3, Theme.PRESETS[i], sel ? 0xFFFFFFFF : Theme.BORDER);
            hit(sx, sy, sw, 16, new Runnable() {
                @Override public void run() {
                    Theme.preset = idx;
                    Theme.useCustom = false;
                    Theme.rainbow = false;
                    ConfigStore.markDirty();
                }
            }, null, null);
        }
        cy += 2 * 20 + 2;
        cy += toggleLine(c, lx, cy, colW, "Custom accent colour", Theme.useCustom, new Runnable() {
            @Override public void run() {
                Theme.useCustom = !Theme.useCustom;
                if (Theme.useCustom) Theme.rainbow = false;
                themePickerOpen = Theme.useCustom;
                ConfigStore.markDirty();
            }
        });
        if (Theme.useCustom) {
            cy += colorPicker(c, lx + 2, cy, colW - 6, "theme-custom", new java.util.function.IntSupplier() {
                @Override public int getAsInt() { return Theme.custom; }
            }, new java.util.function.IntConsumer() {
                @Override public void accept(int v) { Theme.custom = v | 0xFF000000; }
            }, false) + 2;
        }
        cy += toggleLine(c, lx, cy, colW, "Rainbow accent", Theme.rainbow, new Runnable() {
            @Override public void run() {
                Theme.rainbow = !Theme.rainbow;
                if (Theme.rainbow) Theme.useCustom = false;
                ConfigStore.markDirty();
            }
        });
        cy += 4;
        sliderCompact(c, lx, cy, colW, "Panel opacity", Math.round(Theme.panelOpacity * 100) + "%",
                (Theme.panelOpacity - 0.5) / 0.5, new java.util.function.DoubleConsumer() {
                    @Override public void accept(double r) {
                        Theme.panelOpacity = (float) (0.5 + r * 0.5);
                        ConfigStore.markDirty();
                    }
                });
        cy += 24;
        sliderCompact(c, lx, cy, colW, "Animation speed", String.format(Locale.ROOT, "%.1fx", Theme.animSpeed),
                (Theme.animSpeed - 0.4) / 2.1, new java.util.function.DoubleConsumer() {
                    @Override public void accept(double r) {
                        Theme.animSpeed = (float) (0.4 + r * 2.1);
                        ConfigStore.markDirty();
                    }
                });
        cy += 24;
        sliderCompact(c, lx, cy, colW, "Corner radius", String.valueOf(Theme.cornerRadius), Theme.cornerRadius / 5.0,
                new java.util.function.DoubleConsumer() {
                    @Override public void accept(double r) {
                        Theme.cornerRadius = (int) Math.round(r * 5.0);
                        ConfigStore.markDirty();
                    }
                });

        // ---- right column: size of the module panels
        int ry = y + 24;
        Draw.text(c, this.textRenderer, "Module panel size", rx, ry, Theme.MUTED);
        ry += 12;
        int bw = (colW - 8) / 3;
        button(c, rx, ry, bw, 15, "Compact", true, Theme.accent(), new Runnable() {
            @Override public void run() {
                Theme.compact();
                resetLayout();
            }
        });
        button(c, rx + bw + 4, ry, bw, 15, "Default", true, Theme.accent(), new Runnable() {
            @Override public void run() {
                Theme.panelWidth = 124;
                Theme.rowHeight = 14;
                Theme.panelMaxHeight = 190;
                resetLayout();
            }
        });
        button(c, rx + 2 * (bw + 4), ry, bw, 15, "Roomy", true, Theme.accent(), new Runnable() {
            @Override public void run() {
                Theme.roomy();
                resetLayout();
            }
        });
        ry += 22;
        sliderCompact(c, rx, ry, colW, "Panel width", Theme.panelWidth + " px", (Theme.panelWidth - 96) / 144.0,
                new java.util.function.DoubleConsumer() {
                    @Override public void accept(double r) {
                        Theme.panelWidth = (int) Math.round(96 + r * 144.0);
                        ConfigStore.markDirty();
                    }
                });
        ry += 24;
        sliderCompact(c, rx, ry, colW, "Row height", Theme.rowHeight + " px", (Theme.rowHeight - 11) / 11.0,
                new java.util.function.DoubleConsumer() {
                    @Override public void accept(double r) {
                        Theme.rowHeight = (int) Math.round(11 + r * 11.0);
                        ConfigStore.markDirty();
                    }
                });
        ry += 24;
        sliderCompact(c, rx, ry, colW, "Max panel height", Theme.panelMaxHeight + " px", (Theme.panelMaxHeight - 100) / 320.0,
                new java.util.function.DoubleConsumer() {
                    @Override public void accept(double r) {
                        Theme.panelMaxHeight = (int) Math.round(100 + r * 320.0);
                        ConfigStore.markDirty();
                    }
                });
        ry += 28;
        Draw.text(c, this.textRenderer, "Drag a panel's bottom-right corner to resize it.", rx, ry, Theme.DIM);
        ry += 10;
        Draw.text(c, this.textRenderer, "Right-click a panel header to reset its size.", rx, ry, Theme.DIM);
        ry += 16;
        button(c, rx, ry, colW, 15, "Re-arrange panels", true, Theme.accent(), new Runnable() {
            @Override public void run() { resetLayout(); }
        });
        ry += 19;
        button(c, rx, ry, colW, 15, "Reset theme & layout", true, Theme.BAD, new Runnable() {
            @Override public void run() {
                Theme.reset();
                resetLayout();
            }
        });
    }

    private int toggleLine(DrawContext c, int x, int y, int w, String label, boolean on, Runnable click) {
        Draw.text(c, this.textRenderer, label, x, y + 4, Theme.TEXT);
        toggleSwitch(c, x + w - 20, y + 3, on, "tl" + label);
        hit(x, y, w, 16, click, null, null);
        return 19;
    }

    // ------------------------------------------------------------------ config view
    private void status(String text, boolean good) {
        cfgStatus = text;
        cfgGood = good;
        cfgStatusUntil = System.currentTimeMillis() + 5000L;
    }

    private void renderConfigView(DrawContext c) {
        int w = 440;
        int h = this.height - 80;
        int x = (this.width - w) / 2;
        int y = 28;
        card(c, x, y, w, h);
        hit(x, y, w, h, null, null, null);
        Draw.text(c, this.textRenderer, "Config Manager", x + 12, y + 10, Theme.TEXT);
        Draw.textRight(c, this.textRenderer, "Active: " + ConfigStore.active(), x + w - 12, y + 10, Theme.accent());

        // profile list
        int lx = x + 12;
        int ly = y + 28;
        int lw = 200;
        int lh = h - 40;
        Draw.rrectBorder(c, lx, ly, lw, lh, 3, 0xFF0A0612, Theme.BORDER);
        List<String> profiles = ConfigStore.profiles();
        int rows = Math.max(1, (lh - 8) / 19);
        cfgScroll = Math.max(0, Math.min(Math.max(0, profiles.size() - rows), cfgScroll));
        if (pushClip(c, lx + 1, ly + 1, lw - 2, lh - 2)) {
            int yy = ly + 4;
            for (int i = cfgScroll; i < profiles.size() && i < cfgScroll + rows; i++) {
                final String name = profiles.get(i);
                boolean sel = name.equalsIgnoreCase(selectedProfile);
                boolean act = name.equalsIgnoreCase(ConfigStore.active());
                boolean hov = hovered(lx + 4, yy, lw - 8, 17);
                int bg = sel ? Draw.mul(Theme.accent(), 0.5f) : (hov ? Theme.ROW_HOVER : Theme.ROW);
                Draw.rrect(c, lx + 4, yy, lw - 8, 17, 3, bg);
                Draw.text(c, this.textRenderer, Draw.fit(this.textRenderer, name, lw - 70), lx + 10, yy + 5, sel ? 0xFFFFFFFF : Theme.TEXT);
                if (act) Draw.textRight(c, this.textRenderer, "active", lx + lw - 10, yy + 5, Theme.GOOD);
                hit(lx + 4, yy, lw - 8, 17, new Runnable() {
                    @Override public void run() {
                        selectedProfile = name;
                        configName.text = name;
                    }
                }, null, null);
                yy += 19;
            }
            popClip(c);
        }

        // actions
        int ax = lx + lw + 12;
        int aw = w - (ax - x) - 12;
        Draw.text(c, this.textRenderer, "Name", ax, ly + 1, Theme.MUTED);
        textBox(c, ax, ly + 12, aw, 16, configName);
        int by = ly + 36;
        final String sel = selectedProfile;
        button(c, ax, by, aw, 16, "Create new (from current)", true, Theme.accent(), new Runnable() {
            @Override public void run() {
                if (ConfigStore.create(configName.text)) {
                    selectedProfile = ConfigStore.active();
                    status("Created and activated \"" + ConfigStore.active() + "\"", true);
                } else {
                    status("Pick a unique name (letters, numbers, space, - _)", false);
                }
            }
        });
        by += 20;
        button(c, ax, by, aw, 16, "Save active", true, Theme.accent(), new Runnable() {
            @Override public void run() {
                status(ConfigStore.saveActive() ? "Saved \"" + ConfigStore.active() + "\"" : "Save failed - see game log", ConfigStore.saveActive());
            }
        });
        by += 20;
        button(c, ax, by, aw, 16, "Load selected", true, Theme.accent(), new Runnable() {
            @Override public void run() {
                if (ConfigStore.load(sel)) status("Loaded \"" + sel + "\"", true);
                else status("Select a profile to load", false);
            }
        });
        by += 20;
        button(c, ax, by, aw, 16, "Rename selected", true, Theme.accent(), new Runnable() {
            @Override public void run() {
                if (ConfigStore.rename(sel, configName.text)) {
                    selectedProfile = ConfigStore.cleanName(configName.text);
                    status("Renamed to \"" + selectedProfile + "\"", true);
                } else {
                    status("Type a new unique name, then select a profile", false);
                }
            }
        });
        by += 20;
        button(c, ax, by, aw, 16, "Duplicate selected", true, Theme.accent(), new Runnable() {
            @Override public void run() {
                if (ConfigStore.duplicate(sel, configName.text)) status("Duplicated \"" + sel + "\"", true);
                else status("Type a new unique name for the copy", false);
            }
        });
        by += 20;
        boolean confirming = sel.equalsIgnoreCase(confirmDelete) && System.currentTimeMillis() < confirmUntil;
        button(c, ax, by, aw, 16, confirming ? "Click again to delete" : "Delete selected", true, Theme.BAD, new Runnable() {
            @Override public void run() {
                if (sel.equalsIgnoreCase(confirmDelete) && System.currentTimeMillis() < confirmUntil) {
                    if (ConfigStore.delete(sel)) {
                        selectedProfile = ConfigStore.active();
                        status("Deleted \"" + sel + "\"", true);
                    } else {
                        status("Cannot delete the last remaining profile", false);
                    }
                    confirmDelete = "";
                } else {
                    confirmDelete = sel;
                    confirmUntil = System.currentTimeMillis() + 3000L;
                }
            }
        });
        by += 20;
        button(c, ax, by, aw, 16, "Reset active to defaults", true, Theme.BAD, new Runnable() {
            @Override public void run() {
                ConfigStore.resetActiveToDefaults();
                status("Active profile reset to defaults", true);
            }
        });
        by += 24;
        if (System.currentTimeMillis() < cfgStatusUntil) {
            int yy = by;
            for (String line : wrap(cfgStatus, aw)) {
                Draw.text(c, this.textRenderer, line, ax, yy, cfgGood ? Theme.GOOD : Theme.BAD);
                yy += 10;
            }
        }
        Draw.text(c, this.textRenderer, "Profiles are saved to config/phantom/profiles", ax, ly + lh - 10, Theme.DIM);
    }

    // ------------------------------------------------------------------ input
    @Override
    protected boolean preClick(double mx, double my, int button) {
        if (bindModule != null || bindSetting != null) {
            int code = -100 - button;
            if (bindModule != null) bindModule.setKeyCode(code);
            if (bindSetting != null) {
                bindSetting.set(code);
                ConfigStore.markDirty();
            }
            bindModule = null;
            bindSetting = null;
            return true;
        }
        return false;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (bindModule != null || bindSetting != null) {
            int code = key == GLFW.GLFW_KEY_ESCAPE ? -1 : key;
            if (bindModule != null) bindModule.setKeyCode(code);
            if (bindSetting != null) {
                bindSetting.set(code);
                ConfigStore.markDirty();
            }
            bindModule = null;
            bindSetting = null;
            return true;
        }
        if (focused == null && key == GLFW.GLFW_KEY_RIGHT_SHIFT && System.currentTimeMillis() - openedAt > 350L) {
            this.close();
            return true;
        }
        if (focused == friendInput && (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER)) {
            focused = null;
            addFriendFromInput();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        int dir = vertical > 0 ? -1 : 1;
        if (view == View.MODULES) {
            for (int i = panels.size() - 1; i >= 0; i--) {
                Panel p = panels.get(i);
                if (p.cat != null && Draw.inside(mx, my, p.rx, p.ry, p.rw, p.rh)) {
                    p.scroll += dir * 22;
                    return true;
                }
            }
        } else if (view == View.WAYPOINTS) {
            wpScroll += dir;
            return true;
        } else if (view == View.FRIENDS) {
            friendScroll += dir;
            return true;
        } else if (view == View.CONFIG) {
            cfgScroll += dir;
            return true;
        }
        return super.mouseScrolled(mx, my, horizontal, vertical);
    }
}
