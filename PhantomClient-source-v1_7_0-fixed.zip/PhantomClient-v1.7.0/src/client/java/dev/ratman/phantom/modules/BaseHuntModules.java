package dev.ratman.phantom.modules;

import dev.ratman.phantom.module.HudModule;
import dev.ratman.phantom.module.Module;
import dev.ratman.phantom.module.ModuleCategory;
import dev.ratman.phantom.module.ModuleManager;
import dev.ratman.phantom.setting.Setting;
import dev.ratman.phantom.util.Compat;
import dev.ratman.phantom.util.Draw;
import dev.ratman.phantom.util.FindLog;
import dev.ratman.phantom.util.Notifier;
import dev.ratman.phantom.util.RenderUtil;
import dev.ratman.phantom.util.Theme;
import dev.ratman.phantom.world.BlockScanner;
import dev.ratman.phantom.world.SpawnerTracker;
import dev.ratman.phantom.world.SuspiciousChunkFinder;
import dev.ratman.phantom.world.WaypointStore;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.SignBlockEntity;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.entity.passive.AbstractDonkeyEntity;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LightType;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Extra base-hunting tools: entity / sign / block-entity finders, light overlay, portals, waypoints and HUD readouts. */
public final class BaseHuntModules {
    private BaseHuntModules() {}

    public static void register() {
        ModuleManager.register(new EntityFinder());
        ModuleManager.register(new SignFinder());
        ModuleManager.register(new BlockEntityEsp());
        ModuleManager.register(new LightOverlay());
        ModuleManager.register(new PortalEsp());
        ModuleManager.register(new Waypoints());
        ModuleManager.register(new AddWaypoint());
        ModuleManager.register(new CopyLastFind());
        ModuleManager.register(new FindLogHud());
        ModuleManager.register(new ChunkInfo());
    }

    private static long chunkKey(int cx, int cz) {
        return ((long) cx & 0xFFFFFFFFL) | (((long) cz & 0xFFFFFFFFL) << 32);
    }

    // ================================================================== Entity Finder
    static final class EntityFinder extends Module {
        final Setting.Bool frames = bool("frames", "Item frames", true);
        final Setting.Bool onlyFilled = bool("filled", "Only frames holding an item", true);
        final Setting.Bool stands = bool("stands", "Armor stands", true);
        final Setting.Bool carts = bool("carts", "Chest / hopper minecarts", true);
        final Setting.Bool boats = bool("boats", "Chest boats", true);
        final Setting.Bool mounts = bool("mounts", "Donkeys / mules / llamas with chests", true);
        final Setting.Bool villagers = bool("villagers", "Villagers", false);
        final Setting.Num range = num("range", "Range", 128.0, 16.0, 300.0, 4.0, " blocks");
        final Setting.Col frameColor = color("framecolor", "Frame colour", 0xFFFFD166);
        final Setting.Col standColor = color("standcolor", "Armor stand colour", 0xFF93C5FD);
        final Setting.Col cartColor = color("cartcolor", "Minecart colour", 0xFFFF9F43);
        final Setting.Col boatColor = color("boatcolor", "Boat colour", 0xFF6BE7D8);
        final Setting.Col mountColor = color("mountcolor", "Mount colour", 0xFFF472B6);
        final Setting.Col villagerColor = color("villagercolor", "Villager colour", 0xFF7EE787);
        final Setting.Bool glow = bool("glow", "Glow", true);
        final Setting.Bool tracers = bool("tracers", "Tracers", false);
        final Setting.Bool notify = bool("notify", "Notify on new finds", true);
        final Setting.Num cluster = num("cluster", "Notify when this many are in one chunk", 3.0, 1.0, 20.0, 1.0);
        final Setting.Bool sound = bool("sound", "Notification sound", true);

        private final List<Entity> tracked = new ArrayList<Entity>();
        private final List<Integer> trackedColors = new ArrayList<Integer>();
        private final Set<String> announced = new HashSet<String>();
        private int timer;

        EntityFinder() {
            super("entity_finder", "Entity Finder", ModuleCategory.BASE_FINDING,
                    "Highlights and announces base indicators: item frames, armor stands, storage minecarts, chest boats, loaded mounts, villagers.");
            sound.visibleWhen(() -> notify.on());
            cluster.visibleWhen(() -> notify.on());
            onlyFilled.visibleWhen(() -> frames.on());
        }

        @Override public void onWorldReset() {
            tracked.clear();
            trackedColors.clear();
            announced.clear();
        }

        @Override public void onEnable() { announced.clear(); }

        /** Returns 0 = none, otherwise an index into the settings above (1 frame .. 6 villager). */
        private int classify(Entity e) {
            String id = Registries.ENTITY_TYPE.getId(e.getType()).getPath();
            if (frames.on() && (id.equals("item_frame") || id.equals("glow_item_frame"))) {
                if (onlyFilled.on() && e instanceof ItemFrameEntity && ((ItemFrameEntity) e).getHeldItemStack().isEmpty()) return 0;
                return 1;
            }
            if (stands.on() && e instanceof ArmorStandEntity) return 2;
            if (carts.on() && (id.equals("chest_minecart") || id.equals("hopper_minecart"))) return 3;
            if (boats.on() && (id.contains("chest_boat") || id.contains("chest_raft"))) return 4;
            if (mounts.on() && e instanceof AbstractDonkeyEntity && ((AbstractDonkeyEntity) e).hasChest()) return 5;
            if (villagers.on() && id.equals("villager")) return 6;
            return 0;
        }

        private int colorFor(int kind) {
            switch (kind) {
                case 1: return frameColor.argb();
                case 2: return standColor.argb();
                case 3: return cartColor.argb();
                case 4: return boatColor.argb();
                case 5: return mountColor.argb();
                default: return villagerColor.argb();
            }
        }

        private String nameFor(int kind) {
            switch (kind) {
                case 1: return "item frames";
                case 2: return "armor stands";
                case 3: return "storage minecarts";
                case 4: return "chest boats";
                case 5: return "chest mounts";
                default: return "villagers";
            }
        }

        @Override public void onTick() {
            if (timer-- > 0) return;
            timer = 10;
            tracked.clear();
            trackedColors.clear();
            double r2 = range.d() * range.d();
            Map<String, List<Entity>> perChunk = new LinkedHashMap<String, List<Entity>>();
            for (Entity e : mc.world.getEntities()) {
                if (e == mc.player || e.isRemoved() || mc.player.squaredDistanceTo(e) > r2) continue;
                int kind = classify(e);
                if (kind == 0) continue;
                tracked.add(e);
                trackedColors.add(colorFor(kind));
                String key = kind + ":" + chunkKey(e.getBlockX() >> 4, e.getBlockZ() >> 4);
                List<Entity> list = perChunk.get(key);
                if (list == null) {
                    list = new ArrayList<Entity>();
                    perChunk.put(key, list);
                }
                list.add(e);
            }
            if (!notify.on()) return;
            for (Map.Entry<String, List<Entity>> en : perChunk.entrySet()) {
                List<Entity> list = en.getValue();
                if (list.size() < cluster.i() || !announced.add(en.getKey())) continue;
                int kind = Integer.parseInt(en.getKey().substring(0, en.getKey().indexOf(':')));
                Entity first = list.get(0);
                BlockPos pos = first.getBlockPos();
                String msg = list.size() + " " + nameFor(kind) + " near X " + pos.getX() + " Y " + pos.getY() + " Z " + pos.getZ();
                Notifier.chat(msg);
                FindLog.add("Entities", msg, pos);
                if (sound.on()) Notifier.sound(Notifier.SOUND_PING, 0.9f, 1.1f);
            }
        }

        @Override public void onRender3D(WorldRenderContext ctx, float td) {
            if (tracked.isEmpty()) return;
            RenderUtil.Pass pass = RenderUtil.begin(ctx);
            if (pass == null) return;
            for (int i = 0; i < tracked.size(); i++) {
                Entity e = tracked.get(i);
                if (e.isRemoved()) continue;
                int c = trackedColors.get(i);
                Box b = RenderUtil.lerpedBox(e, td);
                pass.box(b, c, 0, 0f);
                if (glow.on()) pass.glow(b, c, 2, 1.0f);
                if (tracers.on()) pass.tracer(b.getCenter(), c);
            }
        }

        @Override public String info() { return tracked.size() + ""; }
    }

    // ================================================================== Sign Finder
    static final class SignFinder extends Module {
        final Setting.Num radius = num("radius", "Scan radius", 6.0, 1.0, 12.0, 1.0, " chunks");
        final Setting.Bool nonEmpty = bool("nonempty", "Only signs with text", true);
        final Setting.Text keywords = text("keywords", "Only if text contains (comma list, empty = all)", "", 120);
        final Setting.Col color = color("color", "Colour", 0xFFFDE68A);
        final Setting.Bool glow = bool("glow", "Glow", true);
        final Setting.Bool tracers = bool("tracers", "Tracers", false);
        final Setting.Num range = num("renderrange", "Render range", 96.0, 16.0, 256.0, 4.0, " blocks");
        final Setting.Bool chat = bool("chat", "Chat the text of new signs", true);
        final Setting.Bool sound = bool("sound", "Notification sound", true);

        private static final class Sign {
            BlockPos pos;
            String text;
        }

        private final List<Sign> signs = new ArrayList<Sign>();
        private final Set<Long> announced = new HashSet<Long>();
        private int timer;

        SignFinder() {
            super("sign_finder", "Sign Finder", ModuleCategory.BASE_FINDING,
                    "Highlights signs through walls and prints what they say (names, coordinates, base clues).");
            sound.visibleWhen(() -> chat.on());
        }

        @Override public void onWorldReset() {
            signs.clear();
            announced.clear();
        }

        @Override public void onEnable() { announced.clear(); }

        private boolean matches(String text) {
            String filter = keywords.get().trim().toLowerCase(Locale.ROOT);
            if (filter.isEmpty()) return true;
            String low = text.toLowerCase(Locale.ROOT);
            for (String k : filter.split(",")) {
                String t = k.trim();
                if (!t.isEmpty() && low.contains(t)) return true;
            }
            return false;
        }

        private static String readSign(SignBlockEntity sign) {
            StringBuilder sb = new StringBuilder();
            Text[] front = sign.getFrontText().getMessages(false);
            Text[] back = sign.getBackText().getMessages(false);
            for (Text t : front) {
                String s = t.getString().trim();
                if (!s.isEmpty()) sb.append(sb.length() > 0 ? " / " : "").append(s);
            }
            StringBuilder b2 = new StringBuilder();
            for (Text t : back) {
                String s = t.getString().trim();
                if (!s.isEmpty()) b2.append(b2.length() > 0 ? " / " : "").append(s);
            }
            if (b2.length() > 0) sb.append(sb.length() > 0 ? " | back: " : "back: ").append(b2);
            return sb.toString();
        }

        @Override public void onTick() {
            if (timer-- > 0) return;
            timer = 20;
            signs.clear();
            int r = radius.i();
            int pcx = mc.player.getBlockX() >> 4;
            int pcz = mc.player.getBlockZ() >> 4;
            int newThisScan = 0;
            for (int cx = pcx - r; cx <= pcx + r; cx++) {
                for (int cz = pcz - r; cz <= pcz + r; cz++) {
                    Chunk chunk = mc.world.getChunkManager().getChunk(cx, cz, ChunkStatus.FULL, false);
                    if (chunk == null) continue;
                    for (BlockEntity be : chunk.getBlockEntities().values()) {
                        if (!(be instanceof SignBlockEntity)) continue;
                        String text = readSign((SignBlockEntity) be);
                        if (nonEmpty.on() && text.isEmpty()) continue;
                        if (!matches(text)) continue;
                        Sign s = new Sign();
                        s.pos = be.getPos().toImmutable();
                        s.text = text;
                        signs.add(s);
                        if (announced.add(s.pos.asLong()) && newThisScan < 4) {
                            newThisScan++;
                            String msg = "Sign at X " + s.pos.getX() + " Y " + s.pos.getY() + " Z " + s.pos.getZ()
                                    + (text.isEmpty() ? "" : ": " + text);
                            if (chat.on()) Notifier.chat(msg);
                            FindLog.add("Sign", text.isEmpty() ? "(blank)" : text, s.pos);
                            if (sound.on() && chat.on()) Notifier.sound(Notifier.SOUND_PING, 0.7f, 1.5f);
                        }
                    }
                }
            }
        }

        @Override public void onRender3D(WorldRenderContext ctx, float td) {
            if (signs.isEmpty()) return;
            RenderUtil.Pass pass = RenderUtil.begin(ctx);
            if (pass == null) return;
            double r2 = range.d() * range.d();
            int c = color.argb();
            for (Sign s : signs) {
                Vec3d center = Vec3d.ofCenter(s.pos);
                if (center.squaredDistanceTo(pass.camera) > r2) continue;
                Box b = new Box(s.pos);
                pass.box(b, c, 0, 0f);
                if (glow.on()) pass.glow(b, c, 2, 1.0f);
                if (tracers.on()) pass.tracer(center, c);
            }
        }

        @Override public String info() { return signs.size() + ""; }
    }

    // ================================================================== Block Entity ESP
    static int group(String id) {
        if (id.equals("hopper") || id.equals("dropper") || id.equals("dispenser")) return 1;
        if (id.equals("furnace") || id.equals("blast_furnace") || id.equals("smoker") || id.equals("brewing_stand")) return 2;
        if (id.endsWith("_bed")) return 3;
        if (id.contains("sign")) return 4;
        if (id.contains("banner")) return 5;
        if (id.equals("beacon") || id.equals("spawner") || id.equals("conduit") || id.equals("enchanting_table")
                || id.equals("end_gateway") || id.equals("end_portal") || id.contains("_head") || id.contains("_skull")
                || id.equals("lectern") || id.equals("jukebox")) return 6;
        if (id.equals("chest") || id.equals("trapped_chest") || id.equals("barrel") || id.equals("ender_chest")
                || id.contains("shulker_box") || id.equals("chiseled_bookshelf") || id.equals("decorated_pot")
                || id.equals("crafter")) return 0;
        return -1;
    }

    static final class BlockEntityEsp extends Module {
        final Setting.Bool containers = bool("containers", "Chests, barrels, shulkers", true);
        final Setting.Col containerColor = color("containercolor", "Containers colour", 0xFFFFD166);
        final Setting.Bool redstone = bool("redstone", "Hoppers, droppers, dispensers", true);
        final Setting.Col redstoneColor = color("redstonecolor", "Redstone colour", 0xFFB5C1D8);
        final Setting.Bool furnaces = bool("furnaces", "Furnaces, brewing stands", false);
        final Setting.Col furnaceColor = color("furnacecolor", "Furnace colour", 0xFFFF8B75);
        final Setting.Bool beds = bool("beds", "Beds", true);
        final Setting.Col bedColor = color("bedcolor", "Bed colour", 0xFFFF6B8B);
        final Setting.Bool signs = bool("signs", "Signs", true);
        final Setting.Col signColor = color("signcolor", "Sign colour", 0xFFFDE68A);
        final Setting.Bool banners = bool("banners", "Banners", false);
        final Setting.Col bannerColor = color("bannercolor", "Banner colour", 0xFF93C5FD);
        final Setting.Bool special = bool("special", "Beacons, spawners, heads, lecterns...", true);
        final Setting.Col specialColor = color("specialcolor", "Special colour", 0xFFC084FC);
        final Setting.Num range = num("range", "Range", 96.0, 16.0, 256.0, 4.0, " blocks");
        final Setting.Bool glow = bool("glow", "Glow", true);
        final Setting.Bool tracers = bool("tracers", "Tracers", false);

        private static final class Item {
            BlockPos pos;
            int color;
            List<Box> boxes;
        }

        private final List<Item> items = new ArrayList<Item>();
        private int timer;

        BlockEntityEsp() {
            super("block_entity_esp", "Block Entity ESP", ModuleCategory.BASE_FINDING,
                    "One-stop ESP for everything that indicates a base: containers, beds, signs, banners, beacons, spawners.");
            containerColor.visibleWhen(() -> containers.on());
            redstoneColor.visibleWhen(() -> redstone.on());
            furnaceColor.visibleWhen(() -> furnaces.on());
            bedColor.visibleWhen(() -> beds.on());
            signColor.visibleWhen(() -> signs.on());
            bannerColor.visibleWhen(() -> banners.on());
            specialColor.visibleWhen(() -> special.on());
        }

        @Override public void onWorldReset() { items.clear(); }

        @Override public void onDisable() { items.clear(); }

        private int colorOf(int g) {
            switch (g) {
                case 0: return containers.on() ? containerColor.argb() : 0;
                case 1: return redstone.on() ? redstoneColor.argb() : 0;
                case 2: return furnaces.on() ? furnaceColor.argb() : 0;
                case 3: return beds.on() ? bedColor.argb() : 0;
                case 4: return signs.on() ? signColor.argb() : 0;
                case 5: return banners.on() ? bannerColor.argb() : 0;
                case 6: return special.on() ? specialColor.argb() : 0;
                default: return 0;
            }
        }

        @Override public void onTick() {
            if (timer-- > 0) return;
            timer = 20;
            items.clear();
            int radius = (int) Math.ceil(range.d() / 16.0) + 1;
            int pcx = mc.player.getBlockX() >> 4;
            int pcz = mc.player.getBlockZ() >> 4;
            for (int cx = pcx - radius; cx <= pcx + radius; cx++) {
                for (int cz = pcz - radius; cz <= pcz + radius; cz++) {
                    Chunk chunk = mc.world.getChunkManager().getChunk(cx, cz, ChunkStatus.FULL, false);
                    if (chunk == null) continue;
                    for (BlockEntity be : chunk.getBlockEntities().values()) {
                        BlockState state = be.getCachedState();
                        int g = group(BlockScanner.idOf(state));
                        if (g < 0) continue;
                        int col = colorOf(g);
                        if (col == 0) continue;
                        Item it = new Item();
                        it.pos = be.getPos().toImmutable();
                        it.color = col;
                        it.boxes = new ArrayList<Box>();
                        try {
                            for (Box b : state.getOutlineShape(mc.world, it.pos, ShapeContext.absent()).getBoundingBoxes()) {
                                it.boxes.add(b.offset(it.pos.getX(), it.pos.getY(), it.pos.getZ()));
                                if (it.boxes.size() >= 6) break;
                            }
                        } catch (RuntimeException ignored) {
                            // full block fallback below
                        }
                        if (it.boxes.isEmpty()) it.boxes.add(new Box(it.pos));
                        items.add(it);
                    }
                }
            }
        }

        @Override public void onRender3D(WorldRenderContext ctx, float td) {
            if (items.isEmpty()) return;
            RenderUtil.Pass pass = RenderUtil.begin(ctx);
            if (pass == null) return;
            double r2 = range.d() * range.d();
            for (Item it : items) {
                Vec3d center = Vec3d.ofCenter(it.pos);
                if (center.squaredDistanceTo(pass.camera) > r2) continue;
                for (Box b : it.boxes) {
                    pass.box(b, it.color, 0, 0f);
                    if (glow.on()) pass.glow(b, it.color, 2, 1.0f);
                }
                if (tracers.on()) pass.tracer(center, it.color);
            }
        }

        @Override public String info() { return items.size() + ""; }
    }

    // ================================================================== Light Overlay
    static final class LightOverlay extends Module {
        final Setting.Num radius = num("radius", "Radius", 8.0, 3.0, 16.0, 1.0, " blocks");
        final Setting.Num below = num("below", "Blocks below", 3.0, 0.0, 8.0, 1.0);
        final Setting.Num above = num("above", "Blocks above", 2.0, 0.0, 8.0, 1.0);
        final Setting.Num threshold = num("threshold", "Block light at or below", 0.0, 0.0, 7.0, 1.0);
        final Setting.Col dangerColor = color("danger", "Always spawns (no sky light)", 0xFFFF4D6D);
        final Setting.Col nightColor = color("night", "Spawns at night (has sky light)", 0xFFFFD166);
        final Setting.Bool showNight = bool("shownight", "Show night-only spots", true);
        final Setting.Num maxMarks = num("max", "Max markers", 900.0, 100.0, 3000.0, 100.0);
        private final List<BlockPos> danger = new ArrayList<BlockPos>();
        private final List<BlockPos> night = new ArrayList<BlockPos>();
        private int timer;

        LightOverlay() {
            super("light_overlay", "Light Overlay", ModuleCategory.BASE_FINDING,
                    "Marks dark, mob-spawnable floor spots around you (red = always, yellow = night only).");
            nightColor.visibleWhen(() -> showNight.on());
        }

        @Override public void onWorldReset() {
            danger.clear();
            night.clear();
        }

        @Override public void onTick() {
            if (timer-- > 0) return;
            timer = 10;
            danger.clear();
            night.clear();
            BlockPos origin = mc.player.getBlockPos();
            int r = radius.i();
            int total = 0;
            for (int dy = -below.i(); dy <= above.i(); dy++) {
                for (int dx = -r; dx <= r; dx++) {
                    for (int dz = -r; dz <= r; dz++) {
                        if (total >= maxMarks.i()) return;
                        BlockPos pos = origin.add(dx, dy, dz);
                        if (!mc.world.getBlockState(pos).isAir()) continue;
                        BlockPos floor = pos.down();
                        BlockState fs = mc.world.getBlockState(floor);
                        if (!fs.isSolidBlock(mc.world, floor)) continue;
                        if (!mc.world.getBlockState(pos.up()).isAir()) continue;
                        if (mc.world.getLightLevel(LightType.BLOCK, pos) > threshold.i()) continue;
                        if (mc.world.getLightLevel(LightType.SKY, pos) == 0) danger.add(pos);
                        else if (showNight.on()) night.add(pos);
                        else continue;
                        total++;
                    }
                }
            }
        }

        private void drawX(RenderUtil.Pass pass, BlockPos p, int color) {
            double y = p.getY() + 0.02;
            pass.line(new Vec3d(p.getX() + 0.15, y, p.getZ() + 0.15), new Vec3d(p.getX() + 0.85, y, p.getZ() + 0.85), color);
            pass.line(new Vec3d(p.getX() + 0.85, y, p.getZ() + 0.15), new Vec3d(p.getX() + 0.15, y, p.getZ() + 0.85), color);
        }

        @Override public void onRender3D(WorldRenderContext ctx, float td) {
            if (danger.isEmpty() && night.isEmpty()) return;
            RenderUtil.Pass pass = RenderUtil.begin(ctx);
            if (pass == null) return;
            for (BlockPos p : danger) drawX(pass, p, dangerColor.argb());
            for (BlockPos p : night) drawX(pass, p, nightColor.argb());
        }
    }

    // ================================================================== Portal ESP
    static final class PortalEsp extends Module {
        final Setting.Col portalColor = color("portal", "Nether portals", 0xFFB388FF);
        final Setting.Col endColor = color("end", "End portal / frames", 0xFF6BE7D8);
        final Setting.Num radius = num("radius", "Scan radius", 6.0, 1.0, 12.0, 1.0, " chunks");
        final Setting.Num range = num("range", "Render range", 128.0, 16.0, 256.0, 8.0, " blocks");
        final Setting.Bool glow = bool("glow", "Glow", true);
        final Setting.Bool tracers = bool("tracers", "Tracers", false);
        final Setting.Bool notify = bool("notify", "Notify on new portals", true);
        private final BlockScanner scanner = new BlockScanner();
        private final Set<Long> announced = new HashSet<Long>();
        private int timer;

        PortalEsp() {
            super("portal_esp", "Portal ESP", ModuleCategory.BASE_FINDING,
                    "Finds nether portals, end portals and end portal frames through terrain.");
        }

        @Override public void onEnable() {
            scanner.invalidate();
            announced.clear();
        }

        @Override public void onWorldReset() {
            scanner.invalidate();
            announced.clear();
        }

        @Override public void onTick() {
            scanner.tick(mc, id -> id.equals("nether_portal") || id.equals("end_portal") || id.equals("end_portal_frame"),
                    radius.i(), ClientModules.scansPerTick(), ClientModules.rescanMs(), -64, 320);
            if (!notify.on() || timer-- > 0) return;
            timer = 40;
            int sent = 0;
            for (BlockScanner.Hit h : scanner.hits()) {
                // announce one portal per 8-block cell so a whole portal frame is a single message
                long cell = BlockPos.asLong(h.pos.getX() >> 3, h.pos.getY() >> 3, h.pos.getZ() >> 3);
                if (!announced.add(cell) || sent >= 2) continue;
                sent++;
                String msg = (h.id.equals("nether_portal") ? "Nether portal" : "End portal") + " at X " + h.pos.getX()
                        + " Y " + h.pos.getY() + " Z " + h.pos.getZ();
                Notifier.chat(msg);
                FindLog.add("Portal", msg, h.pos);
            }
        }

        @Override public void onRender3D(WorldRenderContext ctx, float td) {
            RenderUtil.Pass pass = RenderUtil.begin(ctx);
            if (pass == null) return;
            double r2 = range.d() * range.d();
            int drawn = 0;
            for (BlockScanner.Hit h : scanner.hits()) {
                Vec3d center = Vec3d.ofCenter(h.pos);
                if (center.squaredDistanceTo(pass.camera) > r2 || drawn++ > 600) continue;
                int c = h.id.equals("nether_portal") ? portalColor.argb() : endColor.argb();
                Box b = new Box(h.pos);
                pass.box(b, c, 0, 0f);
                if (glow.on()) pass.glow(b, c, 2, 1.0f);
                if (tracers.on() && drawn < 8) pass.tracer(center, c);
            }
        }
    }

    // ================================================================== Waypoints
    static String relativeDirection(float viewYaw, double dx, double dz) {
        double yawTo = Math.toDegrees(Math.atan2(-dx, dz));
        double rel = ((yawTo - viewYaw) % 360.0 + 540.0) % 360.0 - 180.0;
        double a = Math.abs(rel);
        String side = rel > 0 ? ">" : "<";
        if (a < 22.5) return "^";
        if (a < 67.5) return "^" + side;
        if (a < 112.5) return side;
        if (a < 157.5) return "v" + side;
        return "v";
    }

    static final class Waypoints extends Module {
        final Setting.Bool beams = bool("beams", "Vertical beams", true);
        final Setting.Bool boxes = bool("boxes", "Marker boxes", true);
        final Setting.Bool tracers = bool("tracers", "Tracers", false);
        final Setting.Bool converted = bool("converted", "Show nether/overworld converted waypoints", true);
        final Setting.Num hudCount = num("hudcount", "HUD entries", 4.0, 0.0, 10.0, 1.0);
        final Setting.Mode hudCorner = mode("corner", "HUD corner", "Top right", "Top left", "Top right", "Bottom left", "Bottom right");
        final Setting.Num maxDistance = num("maxdistance", "Max distance (0 = unlimited)", 0.0, 0.0, 100000.0, 100.0, " blocks");

        Waypoints() {
            super("waypoints", "Waypoints", ModuleCategory.BASE_FINDING,
                    "Shows your saved waypoints in the world and on the HUD. Manage them in the Waypoints tab.");
            hudCorner.visibleWhen(() -> hudCount.i() > 0);
        }

        @Override public void onEnable() { WaypointStore.ensure(); }

        private Vec3d viewerPos() {
            Entity cam = mc.getCameraEntity() != null ? mc.getCameraEntity() : mc.player;
            return Compat.pos(cam);
        }

        @Override public void onRender3D(WorldRenderContext ctx, float td) {
            List<WaypointStore.Waypoint> list = WaypointStore.list();
            if (list.isEmpty()) return;
            RenderUtil.Pass pass = RenderUtil.begin(ctx);
            if (pass == null) return;
            String dim = WaypointStore.currentDimension();
            double top = mc.world.getTopYInclusive() + 1;
            double bottom = mc.world.getBottomY();
            for (WaypointStore.Waypoint w : list) {
                if (!w.visible) continue;
                if (!converted.on() && !w.dimension.equals(dim)) continue;
                double[] c = WaypointStore.localCoords(w, dim);
                if (c == null) continue;
                double dist = Math.sqrt(Math.pow(c[0] - pass.camera.x, 2) + Math.pow(c[2] - pass.camera.z, 2));
                if (maxDistance.d() > 0 && dist > maxDistance.d()) continue;
                Vec3d at = new Vec3d(c[0], c[1], c[2]);
                if (boxes.on()) pass.box(new Box(c[0] - 0.5, c[1], c[2] - 0.5, c[0] + 0.5, c[1] + 1.0, c[2] + 0.5), w.color, 1, 1.0f);
                if (beams.on()) pass.line(new Vec3d(c[0], bottom, c[2]), new Vec3d(c[0], top, c[2]), w.color);
                if (tracers.on()) pass.tracer(at.add(0, 0.5, 0), w.color);
            }
        }

        @Override public void onHud(DrawContext c, float td) {
            int n = hudCount.i();
            if (n <= 0 || mc.currentScreen != null) return;
            List<WaypointStore.Waypoint> list = WaypointStore.list();
            String dim = WaypointStore.currentDimension();
            Vec3d me = viewerPos();
            float yaw = (mc.getCameraEntity() != null ? mc.getCameraEntity() : mc.player).getYaw();
            List<double[]> rows = new ArrayList<double[]>();
            List<WaypointStore.Waypoint> picked = new ArrayList<WaypointStore.Waypoint>();
            for (WaypointStore.Waypoint w : list) {
                if (!w.visible) continue;
                double[] co = WaypointStore.localCoords(w, dim);
                if (co == null || (!converted.on() && !w.dimension.equals(dim))) continue;
                double dx = co[0] - me.x;
                double dz = co[2] - me.z;
                double dist = Math.sqrt(dx * dx + dz * dz);
                if (maxDistance.d() > 0 && dist > maxDistance.d()) continue;
                int idx = 0;
                while (idx < rows.size() && rows.get(idx)[0] < dist) idx++;
                rows.add(idx, new double[]{dist, dx, dz});
                picked.add(idx, w);
            }
            if (rows.isEmpty()) return;
            int shown = Math.min(n, rows.size());
            int w = 0;
            List<String> lines = new ArrayList<String>();
            for (int i = 0; i < shown; i++) {
                double[] r = rows.get(i);
                String s = picked.get(i).name + "  " + Math.round(r[0]) + "m " + relativeDirection(yaw, r[1], r[2]);
                lines.add(s);
                w = Math.max(w, mc.textRenderer.getWidth(s));
            }
            int boxW = w + 12;
            int boxH = shown * 11 + 5;
            String corner = hudCorner.get();
            int x = corner.endsWith("right") ? c.getScaledWindowWidth() - boxW - 6 : 6;
            int y = corner.startsWith("Top") ? 40 : c.getScaledWindowHeight() - boxH - 40;
            ClientModules.panel(c, x, y, boxW, boxH, 0.7f);
            int ty = y + 4;
            for (int i = 0; i < shown; i++) {
                c.drawText(mc.textRenderer, lines.get(i), x + 7, ty, picked.get(i).color, true);
                ty += 11;
            }
        }
    }

    static final class AddWaypoint extends Module {
        final Setting.Text name = text("name", "Name (empty = auto)", "", 24);

        AddWaypoint() {
            super("add_waypoint", "Add Waypoint Here", ModuleCategory.BASE_FINDING,
                    "Saves a waypoint at your position when triggered (bind a key), then turns itself off.");
        }

        @Override public void onEnable() {
            ClientPlayerEntity p = mc.player;
            if (p != null && mc.world != null) {
                WaypointStore.Waypoint wp = WaypointStore.add(name.get(), p.getBlockX(), p.getBlockY(), p.getBlockZ());
                Notifier.chat("Waypoint \"" + wp.name + "\" saved at X " + wp.x + " Y " + wp.y + " Z " + wp.z);
            }
            mc.execute(() -> setEnabled(false));
        }
    }

    static final class CopyLastFind extends Module {
        CopyLastFind() {
            super("copy_last_find", "Copy Last Find", ModuleCategory.BASE_FINDING,
                    "Copies the coordinates of the most recent find to the clipboard, then turns itself off.");
        }

        @Override public void onEnable() {
            FindLog.Entry e = FindLog.lastWithPosition();
            if (e == null) Notifier.chat("No finds with coordinates yet.");
            else {
                Compat.clipboard(e.coords());
                Notifier.chat("Copied " + e.type + " coordinates: " + e.coords());
            }
            mc.execute(() -> setEnabled(false));
        }
    }

    // ================================================================== Find Log HUD
    static final class FindLogHud extends HudModule {
        final Setting.Bool file = bool("file", "Also write finds to config/phantom/logs", true);
        final Setting.Num count = num("count", "Entries shown", 5.0, 1.0, 12.0, 1.0);
        final Setting.Bool coords = bool("coords", "Show coordinates", true);
        final Setting.Num opacity = num("opacity", "Background", 0.75, 0.0, 1.0, 0.05);

        FindLogHud() {
            super("find_log", "Find Log", "Shows the latest finds from all base-hunting modules.", 6, 300);
        }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            List<FindLog.Entry> rows = FindLog.recent(count.i());
            if (rows.isEmpty()) {
                boxW = 90;
                boxH = 14;
                if (editing) {
                    ClientModules.panel(c, x(), y(), boxW, boxH, (float) opacity.d());
                    c.drawText(mc.textRenderer, "Find Log", x() + 7, y() + 3, Theme.MUTED, true);
                }
                return;
            }
            int w = 60;
            List<String> lines = new ArrayList<String>();
            for (FindLog.Entry e : rows) {
                String s = e.time.substring(0, 5) + " " + e.type + ": " + Draw.fit(mc.textRenderer, e.message, 150)
                        + (coords.on() && e.pos != null ? " (" + e.coords() + ")" : "");
                lines.add(s);
                w = Math.max(w, mc.textRenderer.getWidth(s));
            }
            boxW = w + 12;
            boxH = lines.size() * 11 + 5;
            ClientModules.panel(c, x(), y(), boxW, boxH, (float) opacity.d());
            int ty = y() + 4;
            for (String s : lines) {
                c.drawText(mc.textRenderer, s, x() + 7, ty, Theme.TEXT, true);
                ty += 11;
            }
        }
    }

    // ================================================================== Chunk Info HUD
    static final class ChunkInfo extends HudModule {
        final Setting.Bool region = bool("region", "Region file", true);
        final Setting.Bool entities = bool("entities", "Block entity counts", true);
        final Setting.Bool memory = bool("memory", "Remembered finds", true);
        final Setting.Bool nether = bool("nether", "Nether / overworld equivalent", true);
        final Setting.Num opacity = num("opacity", "Background", 0.75, 0.0, 1.0, 0.05);

        ChunkInfo() {
            super("chunk_info", "Chunk Info", "Details about the chunk you stand in: region file, block entities and remembered finds.", 6, 200);
        }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            List<String> lines = new ArrayList<String>();
            ClientPlayerEntity p = mc.player;
            if (p == null || mc.world == null) {
                if (editing) lines.add("Chunk 12, -7");
            } else {
                int cx = p.getBlockX() >> 4;
                int cz = p.getBlockZ() >> 4;
                lines.add("Chunk " + cx + ", " + cz + "  (" + (p.getBlockX() & 15) + ", " + (p.getBlockZ() & 15) + ")");
                if (region.on()) lines.add("Region r." + Math.floorDiv(cx, 32) + "." + Math.floorDiv(cz, 32));
                if (nether.on()) {
                    String dim = mc.world.getRegistryKey().getValue().getPath();
                    if (dim.equals("overworld")) lines.add("Nether " + Math.floorDiv(p.getBlockX(), 8) + ", " + Math.floorDiv(p.getBlockZ(), 8));
                    else if (dim.equals("the_nether")) lines.add("Overworld " + (p.getBlockX() * 8) + ", " + (p.getBlockZ() * 8));
                }
                if (entities.on()) {
                    Chunk chunk = mc.world.getChunkManager().getChunk(cx, cz, ChunkStatus.FULL, false);
                    if (chunk != null) {
                        int[] counts = new int[7];
                        int total = 0;
                        for (BlockEntity be : chunk.getBlockEntities().values()) {
                            int g = group(BlockScanner.idOf(be.getCachedState()));
                            if (g >= 0) counts[g]++;
                            total++;
                        }
                        lines.add("Block entities " + total);
                        lines.add("  containers " + counts[0] + "  hoppers etc " + counts[1] + "  furnaces " + counts[2]);
                        lines.add("  beds " + counts[3] + "  signs " + counts[4] + "  banners " + counts[5] + "  special " + counts[6]);
                    }
                }
                if (memory.on()) {
                    lines.add("Remembered storage " + SuspiciousChunkFinder.rememberedStorage() + "  spawners " + SpawnerTracker.known().size());
                }
            }
            if (lines.isEmpty()) {
                boxW = 40;
                boxH = 14;
                return;
            }
            int w = 40;
            for (String s : lines) w = Math.max(w, mc.textRenderer.getWidth(s));
            boxW = w + 12;
            boxH = lines.size() * 11 + 5;
            ClientModules.panel(c, x(), y(), boxW, boxH, (float) opacity.d());
            int ty = y() + 4;
            for (String s : lines) {
                c.drawText(mc.textRenderer, s, x() + 7, ty, Theme.TEXT, true);
                ty += 11;
            }
        }
    }
}
