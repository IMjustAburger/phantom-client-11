package dev.ratman.phantom.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Writes the camera entity field directly. MinecraftClient#setCameraEntity also notifies the
 * GameRenderer (which clears any active post-processing shader), so it must not be called twice per
 * frame just to retarget the crosshair.
 */
@Mixin(MinecraftClient.class)
public interface MinecraftClientAccessor {
    @Accessor("cameraEntity")
    void phantom$setCameraEntityRaw(Entity entity);
}
