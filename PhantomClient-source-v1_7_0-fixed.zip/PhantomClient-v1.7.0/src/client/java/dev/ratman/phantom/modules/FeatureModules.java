package dev.ratman.phantom.modules;

import dev.ratman.phantom.module.Module;
import dev.ratman.phantom.module.ModuleCategory;
import dev.ratman.phantom.module.ModuleManager;
import dev.ratman.phantom.setting.Setting;
import dev.ratman.phantom.mixin.GameRendererInvoker;
import dev.ratman.phantom.mixin.LivingEntityAccessor;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Formatting;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/** Client-only modules that need hooks into vanilla rendering or entity code. */
public final class FeatureModules {
    private static Xray xray;
    private static Nametags nametags;
    private static MotionBlur motionBlur;
    private static HitParticles hitParticles;
    private static HandPose handPose;
    private static TimeChanger timeChanger;
    private static NameProtect nameProtect;
    private static NoJumpDelay noJumpDelay;

    private FeatureModules() {}

    public static void register() {
        xray = new Xray();
        nametags = new Nametags();
        motionBlur = new MotionBlur();
        hitParticles = new HitParticles();
        handPose = new HandPose();
        timeChanger = new TimeChanger();
        nameProtect = new NameProtect();
        noJumpDelay = new NoJumpDelay();
        ModuleManager.register(xray);
        ModuleManager.register(nametags);
        ModuleManager.register(motionBlur);
        ModuleManager.register(hitParticles);
        ModuleManager.register(handPose);
        ModuleManager.register(timeChanger);
        ModuleManager.register(nameProtect);
        ModuleManager.register(noJumpDelay);
    }

    // -------------------------------------------------------------------- Mixin-facing state
    public static boolean xrayEnabled() { return xray != null && xray.enabled(); }

    public static boolean shouldRenderInXray(BlockState state) {
        if (!xrayEnabled() || state == null || state.isAir()) return true;
        String id = Registries.BLOCK.getId(state.getBlock()).getPath();
        if (xray.ores.on() && id.endsWith("_ore")) return true;
        if (xray.ancientDebris.on() && id.equals("ancient_debris")) return true;
        if (xray.spawners.on() && id.equals("spawner")) return true;
        if (xray.storage.on() && (id.contains("chest") || id.contains("barrel") || id.contains("shulker_box") || id.equals("hopper") || id.equals("ender_chest"))) return true;
        return false;
    }

    public static boolean nametagsEnabled() { return nametags != null && nametags.enabled(); }

    public static boolean shouldForceNametag(Entity entity, double squaredDistance) {
        if (!nametagsEnabled() || !(entity instanceof LivingEntity) || entity == MinecraftClient.getInstance().player) return false;
        if (squaredDistance > nametags.range.d() * nametags.range.d()) return false;
        if (entity instanceof PlayerEntity) return nametags.players.on();
        return nametags.mobs.on();
    }

    public static Text decorateName(Entity entity, Text original) {
        if (original == null) return null;
        Text result = original;
        MinecraftClient client = MinecraftClient.getInstance();
        if (nameProtect != null && nameProtect.enabled() && entity == client.player) {
            result = Text.literal(nameProtect.alias.get()).formatted(Formatting.LIGHT_PURPLE);
        }
        if (nametagsEnabled() && entity instanceof LivingEntity living && entity != client.player) {
            if (nametags.health.on()) {
                int hp = Math.max(0, Math.round(living.getHealth()));
                result = result.copy().append(Text.literal("  " + hp + "❤").formatted(Formatting.RED));
            }
            if (nametags.distance.on() && client.player != null) {
                int blocks = Math.round(client.player.distanceTo(entity));
                result = result.copy().append(Text.literal("  " + blocks + "m").formatted(Formatting.GRAY));
            }
        }
        return result;
    }

    public static boolean handPoseEnabled() { return handPose != null && handPose.enabled(); }
    public static double handSwingSpeed() { return handPose == null ? 1.0 : handPose.swingSpeed.d(); }

    public static void transformHand(net.minecraft.client.util.math.MatrixStack matrices) {
        if (!handPoseEnabled()) return;
        matrices.translate(handPose.x.d(), handPose.y.d(), handPose.z.d());
        matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_X.rotationDegrees((float) handPose.rotX.d()));
        matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Y.rotationDegrees((float) handPose.rotY.d()));
        matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Z.rotationDegrees((float) handPose.rotZ.d()));
        float scale = (float) handPose.scale.d();
        matrices.scale(scale, scale, scale);
    }

    public static boolean noJumpDelayEnabled() { return noJumpDelay != null && noJumpDelay.enabled(); }

    /** True while code deliberately wants the real (server) time/weather instead of the local override. */
    private static boolean bypassLocalOverrides;

    /** Real world time of day, ignoring the Time Changer override (used by HUD and notifiers). */
    public static long serverTimeOfDay(World world) {
        boolean previous = bypassLocalOverrides;
        bypassLocalOverrides = true;
        try {
            return world.getTimeOfDay();
        } finally {
            bypassLocalOverrides = previous;
        }
    }

    /** Real weather as 0 = clear, 1 = rain, 2 = thunder, ignoring the Time Changer override. */
    public static int serverWeatherState(World world) {
        boolean previous = bypassLocalOverrides;
        bypassLocalOverrides = true;
        try {
            return world.isThundering() ? 2 : (world.isRaining() ? 1 : 0);
        } finally {
            bypassLocalOverrides = previous;
        }
    }

    public static long localTimeOfDay(World world, long original) {
        if (bypassLocalOverrides) return original;
        if (timeChanger == null || !timeChanger.enabled() || MinecraftClient.getInstance().world != world || timeChanger.time.is("Server")) return original;
        long day = Math.floorDiv(original, 24000L);
        return day * 24000L + timeChanger.ticks();
    }

    public static float localRain(World world, float original) {
        if (bypassLocalOverrides) return original;
        if (timeChanger == null || !timeChanger.enabled() || MinecraftClient.getInstance().world != world) return original;
        if (timeChanger.weather.is("Clear")) return 0.0f;
        if (timeChanger.weather.is("Rain") || timeChanger.weather.is("Thunder")) return 1.0f;
        return original;
    }

    public static float localThunder(World world, float original) {
        if (bypassLocalOverrides) return original;
        if (timeChanger == null || !timeChanger.enabled() || MinecraftClient.getInstance().world != world) return original;
        if (timeChanger.weather.is("Clear") || timeChanger.weather.is("Rain")) return 0.0f;
        if (timeChanger.weather.is("Thunder")) return 1.0f;
        return original;
    }

    public static boolean localIsRaining(World world, boolean original) {
        if (bypassLocalOverrides) return original;
        if (timeChanger == null || !timeChanger.enabled() || MinecraftClient.getInstance().world != world || timeChanger.weather.is("Server")) return original;
        return timeChanger.weather.is("Rain") || timeChanger.weather.is("Thunder");
    }

    public static boolean localIsThundering(World world, boolean original) {
        if (bypassLocalOverrides) return original;
        if (timeChanger == null || !timeChanger.enabled() || MinecraftClient.getInstance().world != world || timeChanger.weather.is("Server")) return original;
        return timeChanger.weather.is("Thunder");
    }

    // -------------------------------------------------------------------- Xray
    private static final class Xray extends Module {
        final Setting.Bool ores = bool("ores", "Show ores", true);
        final Setting.Bool ancientDebris = bool("debris", "Show ancient debris", true);
        final Setting.Bool spawners = bool("spawners", "Show spawners", false);
        final Setting.Bool storage = bool("storage", "Show storage", false);

        private int lastSelection = -1;

        Xray() { super("xray", "Xray", ModuleCategory.RENDER, "Locally hides non-selected block models so selected ores and containers are visible through terrain."); }

        private int selectionHash() {
            return (ores.on() ? 1 : 0) | (ancientDebris.on() ? 2 : 0) | (spawners.on() ? 4 : 0) | (storage.on() ? 8 : 0);
        }

        /** Chunk meshes are cached, so they must be rebuilt for the new visibility rules to show. */
        private void rebuildChunks() {
            if (mc.worldRenderer != null && mc.world != null) mc.worldRenderer.reload();
        }

        @Override public void onEnable() {
            lastSelection = selectionHash();
            rebuildChunks();
        }

        @Override public void onDisable() {
            rebuildChunks();
        }

        @Override public void onTick() {
            int now = selectionHash();
            if (now != lastSelection) {
                lastSelection = now;
                rebuildChunks();
            }
        }
    }

    // -------------------------------------------------------------------- Nametags
    private static final class Nametags extends Module {
        final Setting.Bool players = bool("players", "Players", true);
        final Setting.Bool mobs = bool("mobs", "Mobs", false);
        final Setting.Bool health = bool("health", "Show health", true);
        final Setting.Bool distance = bool("distance", "Show distance", true);
        final Setting.Num range = num("range", "Range", 64.0, 8.0, 256.0, 4.0, " blocks");

        Nametags() { super("nametags", "Nametags", ModuleCategory.RENDER, "Shows local nameplates with optional health and distance for players and mobs."); }
    }

    // -------------------------------------------------------------------- Motion Blur
    private static final class MotionBlur extends Module {
        final Setting.Mode quality = mode("quality", "Trail strength", "Medium", "Low", "Medium", "High");
        private Identifier previous;
        private String applied;
        private Entity appliedCamera;

        MotionBlur() { super("motion_blur", "Motion Blur", ModuleCategory.VISUALS, "Applies a local temporal after-image post effect. It is visible only on this client."); }

        @Override public void onEnable() {
            if (mc.gameRenderer == null) return;
            GameRendererInvoker access = (GameRendererInvoker) (Object) mc.gameRenderer;
            Identifier current = access.phantom$getPostProcessorId();
            previous = (current != null && current.getNamespace().equals("phantom")) ? null : current;
            applyEffect();
        }

        /**
         * Changing the camera entity (Free Look, Freecam, respawn, spectating) makes the game renderer
         * drop its active post effect, so the effect is re-applied whenever the camera entity changes.
         */
        @Override public void onTick() {
            if (mc.gameRenderer == null) return;
            if (!quality.get().equals(applied) || mc.getCameraEntity() != appliedCamera) applyEffect();
        }

        private void applyEffect() {
            if (mc.gameRenderer == null) return;
            String next = quality.get();
            String path = next.equals("Low") ? "motion_blur_low" : next.equals("High") ? "motion_blur_high" : "motion_blur_medium";
            ((GameRendererInvoker) (Object) mc.gameRenderer).phantom$setPostProcessor(Identifier.of("phantom", path));
            applied = next;
            appliedCamera = mc.getCameraEntity();
        }

        @Override public void onDisable() {
            if (mc.gameRenderer == null) return;
            if (previous != null) ((GameRendererInvoker) (Object) mc.gameRenderer).phantom$setPostProcessor(previous);
            else mc.gameRenderer.clearPostProcessor();
            previous = null;
            applied = null;
            appliedCamera = null;
        }
    }

    // -------------------------------------------------------------------- Hit Particles
    private static final class HitParticles extends Module {
        final Setting.Num count = num("count", "Particles per hit", 8.0, 1.0, 24.0, 1.0);
        final Setting.Num range = num("range", "Detection range", 32.0, 8.0, 96.0, 4.0, " blocks");
        final Setting.Mode style = mode("style", "Particle style", "Critical", "Critical", "Damage", "Hearts");
        private final Map<Integer, Integer> hurtTicks = new HashMap<Integer, Integer>();

        HitParticles() { super("hit_particles", "Hit Particles", ModuleCategory.VISUALS, "Spawns local-only particles when nearby living entities take damage."); }

        @Override public void onTick() {
            if (mc.player == null || mc.world == null) return;
            double rangeSq = range.d() * range.d();
            for (Entity entity : mc.world.getEntities()) {
                if (!(entity instanceof LivingEntity living) || entity == mc.player || !entity.isAlive()) continue;
                if (mc.player.squaredDistanceTo(entity) > rangeSq) continue;
                int previous = hurtTicks.getOrDefault(entity.getId(), 0);
                int current = ((LivingEntityAccessor) (Object) living).phantom$getHurtTime();
                if (current > previous && current >= 8) spawn(living);
                hurtTicks.put(entity.getId(), current);
            }
            if (hurtTicks.size() > 1024) {
                Iterator<Integer> it = hurtTicks.keySet().iterator();
                while (hurtTicks.size() > 768 && it.hasNext()) { it.next(); it.remove(); }
            }
        }

        private void spawn(LivingEntity entity) {
            for (int i = 0; i < count.i(); i++) {
                java.util.concurrent.ThreadLocalRandom random = java.util.concurrent.ThreadLocalRandom.current();
                double x = entity.getX() + (random.nextDouble() - 0.5) * entity.getWidth();
                double y = entity.getY() + random.nextDouble() * entity.getHeight();
                double z = entity.getZ() + (random.nextDouble() - 0.5) * entity.getWidth();
                double vx = (random.nextDouble() - 0.5) * 0.12;
                double vy = 0.04 + random.nextDouble() * 0.12;
                double vz = (random.nextDouble() - 0.5) * 0.12;
                if (style.is("Damage")) mc.world.addImportantParticleClient(ParticleTypes.DAMAGE_INDICATOR, false, x, y, z, vx, vy, vz);
                else if (style.is("Hearts")) mc.world.addImportantParticleClient(ParticleTypes.HEART, false, x, y, z, vx, vy, vz);
                else mc.world.addImportantParticleClient(ParticleTypes.CRIT, false, x, y, z, vx, vy, vz);
            }
        }

        @Override public void onWorldReset() { hurtTicks.clear(); }
        @Override public void onDisable() { hurtTicks.clear(); }
    }

    // -------------------------------------------------------------------- Hand Pose
    private static final class HandPose extends Module {
        final Setting.Num swingSpeed = num("swing_speed", "Swing speed", 1.0, 0.25, 3.0, 0.05, "x");
        final Setting.Num x = num("x", "Horizontal", 0.0, -0.5, 0.5, 0.01);
        final Setting.Num y = num("y", "Vertical", 0.0, -0.5, 0.5, 0.01);
        final Setting.Num z = num("z", "Depth", 0.0, -0.5, 0.5, 0.01);
        final Setting.Num rotX = num("rot_x", "Rotate X", 0.0, -90.0, 90.0, 1.0, "\u00b0");
        final Setting.Num rotY = num("rot_y", "Rotate Y", 0.0, -90.0, 90.0, 1.0, "\u00b0");
        final Setting.Num rotZ = num("rot_z", "Rotate Z", 0.0, -90.0, 90.0, 1.0, "\u00b0");
        final Setting.Num scale = num("scale", "Scale", 1.0, 0.5, 1.5, 0.05, "x");

        HandPose() { super("hand_pose", "Hand Pose", ModuleCategory.VISUALS, "Adjusts your first-person hand/item pose and local swing speed. Other players see no change."); }
    }

    // -------------------------------------------------------------------- Time + Weather
    private static final class TimeChanger extends Module {
        final Setting.Mode time = mode("time", "Time of day", "Server", "Server", "Sunrise", "Day", "Noon", "Sunset", "Night", "Midnight", "Custom");
        final Setting.Num timeTicks = num("time_ticks", "Custom time (ticks)", 6000.0, 0.0, 23999.0, 100.0, " ticks");
        final Setting.Mode weather = mode("weather", "Weather", "Server", "Server", "Clear", "Rain", "Thunder");

        TimeChanger() {
            super("time_changer", "Time Changer", ModuleCategory.VISUALS, "Changes only your local view of time and weather; it never sends world changes to the server.");
            timeTicks.visibleWhen(() -> time.is("Custom"));
        }

        /** Time of day (0-23999) for the selected preset; the Custom slider is never overwritten. */
        int ticks() {
            if (time.is("Sunrise")) return 23000;
            if (time.is("Day")) return 1000;
            if (time.is("Noon")) return 6000;
            if (time.is("Sunset")) return 12000;
            if (time.is("Night")) return 14000;
            if (time.is("Midnight")) return 18000;
            return timeTicks.i();
        }

        @Override public String info() { return time.get() + " / " + weather.get(); }
    }

    // -------------------------------------------------------------------- Name Protect
    private static final class NameProtect extends Module {
        final Setting.Text alias = text("alias", "Replace your name with", "Protected", 20);
        NameProtect() { super("name_protect", "Name Protect", ModuleCategory.VISUALS, "Replaces your own rendered world nameplate with a chosen alias on this client."); }
    }

    // -------------------------------------------------------------------- No Jump Delay
    private static final class NoJumpDelay extends Module {
        NoJumpDelay() { super("no_jump_delay", "No Jump Delay", ModuleCategory.MOVEMENT, "Removes the local player's vanilla jump cooldown. Server movement rules still apply."); }
    }
}
