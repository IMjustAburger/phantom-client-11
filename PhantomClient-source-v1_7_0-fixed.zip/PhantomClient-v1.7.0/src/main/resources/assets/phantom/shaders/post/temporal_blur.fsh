#version 150

uniform sampler2D InSampler;
uniform sampler2D HistorySampler;

layout(std140) uniform MotionBlurConfig {
    float Strength;
};

in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec4 currentFrame = texture(InSampler, texCoord);
    vec4 previousFrame = texture(HistorySampler, texCoord);
    vec3 history = previousFrame.a > 0.01 ? previousFrame.rgb : currentFrame.rgb;
    float strength = clamp(Strength, 0.0, 0.75);
    fragColor = vec4(mix(currentFrame.rgb, history, strength), currentFrame.a);
}
