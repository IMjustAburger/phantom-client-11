# Phantom Client v1.7.0

A client-side Minecraft Fabric utility and visual-enhancement mod for **Minecraft Java Edition 1.21.11**. This source project builds into an installable mod JAR; the ZIP itself is not a mod.

> **Build and test status.** This 1.7.0 source tree has not yet completed a Gradle build or an in-game test in this environment (the sources were only syntax-checked and run through `javac` for non-Minecraft errors). The included launcher requires network access to download Gradle 9.8.2 and Fabric/Minecraft dependencies. The mixin targets were checked against the Yarn 1.21.11+build.1 API documentation, but that is not a substitute for a successful compile and runtime test.

## GUI restyle (1.6.2)

The ClickGUI opened too large. It is now compact by default and fully resizable:

* Smaller defaults: 124 px wide panels, 14 px rows, slimmer headers, sliders, navigation pill and a lighter backdrop.
* **Resize any panel:** drag the grip in its bottom-right corner (width and maximum height); right-click its header to reset it.
* **Theme tab -> Module panel size:** Compact / Default / Roomy presets plus Panel width, Row height and Max panel height
  sliders, and "Re-arrange panels". Sizes are saved in the active profile.
* On small screens the first layout shrinks panel heights so every panel starts on screen (they scroll internally).
* Profiles saved before this version have their panel positions re-arranged once; the Config manager itself is unchanged.

## What changed in 1.6.2 (review of 1.6.1)

Reviewed without access to the Minecraft/Fabric repositories: the sources were checked by `javac` for non-Minecraft errors
and by hand against the mixin targets, but **nothing was compiled against Minecraft and nothing was run in game**.

* **Mixin config location (build-breaking in production):** with Loom's split source sets, the mixin JSON must live in the
  same source set as the mixin classes or no refmap is produced for them and every Yarn-named target fails on a real
  (intermediary) install. The config moved to `src/client/resources/phantom.client.mixins.json`, `fabric.mod.json` points at it,
  and the hand-written `refmap` / `defaultRefmapName` entries were removed so Loom injects its own. The config is now
  non-required with `defaultRequire: 0`, so a target that drifted in a Minecraft update disables that one feature instead of
  crashing the game at launch.
* **Camera jitter / drift (Free Look and Freecam):** the detached camera entity is never ticked, so setting only its position left
  its previous-position fields at the spawn point and the view interpolated toward a stale origin. Both modules now update the
  camera every frame with `refreshPositionAndAngles` (Free Look from the interpolated player position and eye height; Freecam
  from frame-time movement), which also removes 20 Hz stepping.
* **Freecam interactions:** the crosshair ray is built from the camera, so a click while detached would have attacked or
  interacted from the camera's view. Attack, use and pick-block are now suppressed while Freecam is on.
* **Free Look targeting:** new `GameRendererMixin` + `MinecraftClientAccessor` compute the crosshair target from the real player
  during `updateCrosshairTarget`, so attacks, block highlight and the combat modules follow the character, not the camera.
  If that hook cannot apply, the game falls back to camera-based targeting (no crash).
* **Motion Blur vs cameras:** switching the camera entity makes the renderer drop its post effect; Motion Blur now re-applies
  itself whenever the camera entity changes.
* **Xray never appeared until chunks were rebuilt:** it now rebuilds chunk meshes on enable, disable and option change.
* **Nametags only affected non-living entities:** `LivingEntityRenderer` overrides `hasLabel`, so a second mixin hooks it.
* **Hidden-face hook:** both `Block.shouldDrawSide` overloads are hooked (each optional) because Minecraft builds differ in
  which one chunk meshing uses.
* **Conflicts:** Weather Notifier and the HUD clock now read the real server time/weather instead of Time Changer's local
  override; Time Changer no longer overwrites your Custom time slider when a preset is chosen; tracers and Radar use the active
  camera's facing.

## What is new in 1.6.1

* **Xray** — local chunk-render filtering for selectable ore, ancient debris, spawner and storage block groups. Selected target blocks keep their visible faces even when surrounded by solid blocks.
* **Nametags** — locally forces player/mob nameplates within a configurable range, with optional health and distance details.
* **Motion Blur** — selectable Low / Medium / High temporal after-image post effects, rendered only on this client.
* **Hit Particles** — client-only particles when nearby living entities take damage; choose Critical, Damage or Hearts and adjust particle count/range.
* **Hand Pose** — local first-person position, rotation and scale controls, plus **Swing Speed** (0.25x–3.0x). These affect only the local view; other players still see normal swing animations.
* **Time Changer + Weather** — local time-of-day presets/custom ticks and Server/Clear/Rain/Thunder weather selection. These override only the client world's visual getters and do not change world time/weather on the server.
* **Name Protect** — replaces your own rendered in-world nameplate with a configurable alias on this client. It does not rename your account or alter chat/server identity.
* **No Jump Delay** — removes the local player's vanilla jump cooldown. Server movement rules still apply.

Skin Change and a separate Swing Animation module are **not included**. Swing speed is a setting inside Hand Pose, as requested.

## Core 1.6.0 improvements retained

* **Typed module framework** — toggle, slider, mode, colour, text, keybind and block-selection settings persist with profiles; a failing module is isolated and auto-disabled rather than crashing the whole client.
* **ClickGUI** — draggable/collapsible purple-black panels, global module search, click-to-toggle, expandable settings, keyboard/mouse keybind capture (Escape clears), animations, colour pickers and Modules / HUD / Friends / Theme / Config navigation.
* **Config manager** — independent JSON profiles with create, load, save, rename, duplicate, delete and reset. Profile loading resets settings before applying the chosen profile.
* **Base Finding** — Suspicious Chunk Finder and Spawner Notifier with persistent per-world memory, cached detection results, alerts and remembered outlines.
* **Audit fixes** — flight speed applies; Entity ESP glow is reasserted after server metadata changes; armour stands and tamed pets are filtered from combat targeting; profile slider values no longer leak; search reaches all categories; save-profile UI does not overlap on smaller screens.

## Module categories

Modules are listed **alphabetically inside each panel**, the Search panel also matches module descriptions, and the **Enabled**
panel (top right) lists everything that is currently on so you can switch it off with one click. Hover a module for its description.

| Category | Modules |
|---|---|
| Combat (12) | Aim Assist, Auto City, Auto Clicker, Auto Inventory Totem, Auto Totem, Crystal Aura, Crystal Macro, Jump Reset, KillAura, Mace, Shield Breaker, Surround |
| Player (5) | Auto Armor, Auto Drop, Auto Respawn, Durability Alert, Toggle Sneak |
| Movement (19) | Auto Firework, Auto Jump, Auto Walk, Boat Fly, Click TP, Elytra Fly, Elytra Highway, Elytra Swap, Entity Speed, Flight, Go To, Jesus, No Jump Delay, Safe Walk, Speed, Spider, Sprint, Step, Trident Boost |
| Render (15) | Block ESP, Entity ESP, Free Look, Freecam, Fullbright, Hole ESP, Item ESP, Low Health Warning, Nametags, Netherite Finder, Pearl Trajectory, Storage ESP, Tracers, Trajectories, Xray |
| Base Finding (11) | Add Waypoint Here, Block Entity ESP, Copy Last Find, Entity Finder, Light Overlay, Portal ESP, Sign Finder, Spawner Notifier, Storage Finder, Sus Chunk Finder, Waypoints |
| Visuals (9) | Block Overlay, Custom Crosshair, Custom FOV, Hand Pose, Hit Particles, Jump Circles, Motion Blur, Name Protect, Time Changer |
| Misc (9) | Auto Eat, Auto Reconnect, Auto Replenish, Block Notifier, Chat Macro, Coordinate Snapper, Fast Use, Legit Auto Tool, Weather Notifier |
| Server (6) | Anti AFK, Auto Log, Chat Alerts, Chat Filter, Player Detection, Queue Notifier |
| Macros (2) | Macro 1-5, Panic |
| Phantom Client (13) | Active Modules, Armor HUD, Chunk Info, Find Log, HUD, Hotkeys, Item Counter, Nearby Players, Performance, Radar, Region Map, Target HUD, Watermark |

Friends, Waypoints, Theme & Layout and Config are GUI tabs (bottom bar). Module ids are unchanged from earlier versions, so existing
profiles keep their settings; the old "Donut" panel is now "Server" and Netherite Finder moved to Render.

## Base hunting and long-session toolkit (1.7.0)

* **Base Finding:** Sus Chunk Finder (per-type storage filters, lowest Y, clipboard copy), Spawner Notifier (disconnect delay,
  clipboard copy), Storage Finder, **Entity Finder** (item frames, armor stands, storage minecarts, chest boats, chest mounts,
  villagers, with cluster alerts), **Sign Finder** (prints sign text, keyword filter), **Block Entity ESP** (containers, hoppers,
  furnaces, beds, signs, banners, beacons/spawners/heads), **Light Overlay** (dark spawnable floor spots), **Portal ESP**,
  **Waypoints** (per server, saved to disk, nether/overworld conversion, beams, HUD list, GUI tab), Add Waypoint Here, Copy Last Find.
* **Find Log:** every find from these modules is kept in memory (Find Log HUD) and appended to
  `config/phantom/logs/finds-YYYY-MM-DD.log` with coordinates and dimension.
* **Travel:** Elytra Highway (pitch-40 style speed keeping), Auto Firework, Go To (straight-line walking to coordinates or a
  waypoint), Step, Safe Walk.
* **Server:** Queue Notifier (reads "position in queue" messages), Auto Log (low health, few totems, strangers or crystals),
  Anti AFK, Chat Alerts, Chat Filter, Player Detection.
* **Player / Combat:** Auto Drop, Durability Alert, Surround; Auto Totem can hold a safe offhand item and warns when totems run
  low; KillAura can switch to your best weapon; Entity ESP gained friend/invisible/min-range filters.
* **HUD:** Chunk Info, Find Log, Item Counter, Nearby Players, nether/overworld coordinates in the HUD.
* Nothing here sends packets or exploits server bugs; all of it reads what the client already knows or drives normal client input.
  Server rules and anti-cheat still apply to what you do with it.

## Local-only behaviour and limits

* **Time and weather:** the mixin overrides time-of-day, rain/thunder state and rain/thunder-gradient reads only when the queried world is the current client world. It does not set server world properties or send packets.
* **Hand pose / swing speed:** only the local player's first-person render matrices and local swing duration are changed. Other players do not receive these visual changes.
* **Hit particles, motion blur, nametag decorations and Name Protect:** these are local rendering effects.
* **Xray:** this filters rendered block models client-side. It does not reveal chunks the server has not sent, force-load chunks, or bypass server rules/anti-cheat.
* **Free Look:** the camera rotates independently while following your player; the player's body direction and normal movement remain unchanged. Attacks, block interaction and the targeting highlight are computed from the character's own view, not the camera. Server reach and interaction checks still apply.
* **Freecam:** the detached camera flies independently at its configured speed while the actual player remains in place. Camera movement and rotation are local. Attacking, using items and pick-block are disabled while Freecam is on.
* **No Jump Delay:** changes the local vanilla cooldown only; a server can still correct movement.
* **Combat / movement modules:** servers and anti-cheat may correct or punish actions. Nothing here guarantees bypass or undetectability.

## Requirements

- Minecraft Java Edition **1.21.11**
- Fabric Loader **0.18.1 or newer**
- Fabric API **0.141.1+1.21.11**
- Java **21 or newer**
- Gradle **9.8.2** (downloaded automatically by the included launcher)
- Internet access on the first build for Gradle and Maven dependencies

## Build the mod JAR

On macOS/Linux:

```bash
./gradlew build
```

Or run `./build.sh`.

On Windows:

```bat
gradlew.bat build
```

Or run `build.bat`.

The expected remapped mod is:

```text
build/libs/phantom-client-1.7.0.jar
```

Copy the JAR into the `mods` folder of a Minecraft 1.21.11 Fabric instance that also has Fabric API installed.

The project includes `gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.properties` and a project-local bootstrap JAR. The bootstrap downloads the pinned official Gradle 9.8.2 distribution and checks its SHA-256 before running it.

## Controls

- **Right Shift** — open or close the ClickGUI.
- **Free Look / Freecam** — assign each module its own keybind in the module's BIND control; both are local camera modes and are mutually exclusive.
- **Click a module row** — select a module; click its toggle area to enable or disable it.
- **BIND button** — click, then press a keyboard key or mouse button. Press **Escape** to clear the binding.
- **Search field** — filter modules globally.
- **Click a category** — filter the module list.
- **HUD EDIT** — enable HUD editing and drag elements in the HUD editor.

## Project layout

- `src/main/resources/` — Fabric metadata, mixin config, post-effect JSON and shader.
- `src/client/java/` — client initializer, ClickGUI, feature modules, mixins, HUD, world detection and config code.
- `gradle/wrapper/` — pinned Gradle distribution configuration and bootstrap launcher.
- `build.gradle`, `settings.gradle` and `gradle.properties` — Fabric Loom and Minecraft build configuration.

